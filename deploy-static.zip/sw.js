/**
 * Service worker for the static build.
 *
 * The previous worker was written for a server: most of its 450 lines were
 * about `/api/*` — a five-minute TTL on doctor lists, a data-saver mode that
 * rewrote request URLs to ask the origin for smaller images, event-driven cache
 * invalidation the app pushed over `postMessage`, and a push handler for a
 * backend that no longer exists. Every one of those endpoints is now gone, so
 * that code could only ever have cached 404s.
 *
 * What remains is the part that always mattered on a slow connection: keep the
 * app shell on the device so a repeat visit paints without waiting for the
 * network, and serve something useful when there is no network at all. Since
 * the data now lives in IndexedDB rather than behind an API, an offline visit
 * is not a degraded read-only view — the whole application works.
 *
 * Scope-relative throughout: a project-page deploy lives under `/<repo>/`, and
 * `self.registration.scope` is the only reliable base inside a worker.
 */

const VERSION = 'hakimm-static-v1'
const SHELL_CACHE = `${VERSION}-shell`
const RUNTIME_CACHE = `${VERSION}-runtime`
const VENDOR_CACHE = `${VERSION}-vendor`

const BASE = self.registration.scope
const url = (path) => new URL(path, BASE).toString()

/**
 * The shell. Only the modules every route needs are precached — the views are
 * dynamic imports, and caching all twenty here would make the install a large
 * download for someone who opens one page.
 */
const SHELL = [
  './',
  'index.html',
  'offline.html',
  'styles.css',
  'manifest.json',
  'favicon.ico',
  'icon-192.png',
  'assets/images/hakimm-logo.jpg',
  'data/seed.json',
  'js/app.js',
  'js/router.js',
  'js/ui.js',
  'js/i18n.js',
  'js/store.js',
  'js/auth.js',
  'js/brand.js',
  'js/views/_shared.js',
  'js/views/home.js',
].map(url)

/** Origins whose responses are worth keeping between visits. */
const VENDOR_ORIGINS = [
  'https://esm.sh',
  'https://fonts.googleapis.com',
  'https://fonts.gstatic.com',
]

/* ============================ LIFECYCLE ============================ */

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(SHELL_CACHE).then((cache) =>
      // One at a time: `addAll()` rejects the whole batch if a single URL
      // fails, which aborts the install and leaves the visitor with no worker.
      Promise.all(
        SHELL.map((entry) => cache.add(new Request(entry, { cache: 'reload' })).catch(() => undefined)),
      ),
    ),
  )
  self.skipWaiting()
})

self.addEventListener('activate', (event) => {
  const keep = [SHELL_CACHE, RUNTIME_CACHE, VENDOR_CACHE]
  event.waitUntil(
    caches
      .keys()
      // This also clears `telehealth-api-v3` and the other caches the old
      // worker filled, so an upgrading visitor is not left holding stale API
      // responses for endpoints that have been deleted.
      .then((keys) => Promise.all(keys.filter((key) => !keep.includes(key)).map((key) => caches.delete(key))))
      .then(() => self.clients.claim()),
  )
})

/* ============================ HELPERS ============================ */

/**
 * Abort a request past the deadline rather than letting the radio stay open.
 * On a stalled mobile connection an un-aborted fetch costs battery and data
 * without ever resolving.
 */
const NETWORK_TIMEOUT = 12000

function fetchWithTimeout(request, timeout = NETWORK_TIMEOUT) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeout)
  return fetch(request, { signal: controller.signal }).finally(() => clearTimeout(timer))
}

/** Cache the response, then hand back the original. */
function store(cacheName, request, response) {
  if (!response || !response.ok || response.type === 'opaque') return response
  const copy = response.clone()
  caches.open(cacheName).then((cache) => cache.put(request, copy)).catch(() => {})
  return response
}

/**
 * Serve from cache immediately, refresh in the background.
 *
 * Right for `js/*` and `styles.css`: they are not content-hashed, so they must
 * not be cached immutably, but a revalidation round-trip before first paint is
 * exactly what this worker exists to avoid. The visitor gets the previous
 * version instantly and the next visit gets the new one.
 */
async function staleWhileRevalidate(request, cacheName) {
  const cache = await caches.open(cacheName)
  const cached = await cache.match(request)

  const network = fetchWithTimeout(request)
    .then((response) => {
      if (response.ok) cache.put(request, response.clone()).catch(() => {})
      return response
    })
    .catch(() => null)

  if (cached) return cached

  const response = await network
  if (response) return response
  throw new Error('offline and not cached')
}

/* ============================ FETCH ============================ */

self.addEventListener('fetch', (event) => {
  const { request } = event
  if (request.method !== 'GET') return

  const target = new URL(request.url)
  if (target.protocol !== 'http:' && target.protocol !== 'https:') return

  // Navigations: every route is a History API path with no file behind it, so
  // the answer is always the shell. Network first, because index.html carries
  // the metadata and the module graph and a stale one strands the visitor on
  // an old build; cache second, so a dropped connection still opens the app.
  if (request.mode === 'navigate') {
    event.respondWith(
      fetchWithTimeout(request)
        .then((response) => store(SHELL_CACHE, new Request(url('index.html')), response))
        .catch(async () => {
          const cache = await caches.open(SHELL_CACHE)
          return (
            (await cache.match(url('index.html'))) ||
            (await cache.match(url('./'))) ||
            (await cache.match(url('offline.html'))) ||
            new Response('Offline', { status: 503, headers: { 'Content-Type': 'text/plain' } })
          )
        }),
    )
    return
  }

  // Vendor modules and fonts. `esm.sh` URLs pin an exact version, so a cache
  // hit is always the right file; falling back to the network on a miss is
  // what lets ethers.js load the first time.
  if (VENDOR_ORIGINS.includes(target.origin)) {
    event.respondWith(
      caches.match(request).then(
        (cached) =>
          cached ||
          fetchWithTimeout(request)
            .then((response) => store(VENDOR_CACHE, request, response))
            .catch(() => new Response('', { status: 504 })),
      ),
    )
    return
  }

  // Anything else cross-origin — RPC calls, the PeerJS broker, video embeds —
  // is left alone. Signalling and JSON-RPC must never be answered from a cache.
  if (target.origin !== self.location.origin) return

  // Same-origin assets.
  event.respondWith(
    staleWhileRevalidate(request, RUNTIME_CACHE).catch(async () => {
      const cached = await caches.match(request)
      if (cached) return cached
      // An image that was never cached should fail quietly rather than break
      // the page around it.
      if (request.destination === 'image') return new Response('', { status: 504 })
      return new Response('Offline', { status: 503, headers: { 'Content-Type': 'text/plain' } })
    }),
  )
})

/* ============================ MESSAGES ============================ */

self.addEventListener('message', (event) => {
  // Kept because the update prompt uses it. The data-saver toggle, the cache
  // invalidation patterns and the snapshot refresh went with the API they were
  // invalidating.
  if (event.data === 'skipWaiting') self.skipWaiting()
  if (event.data === 'checkForUpdates') self.registration.update()
})
