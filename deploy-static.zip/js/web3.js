/**
 * Browser-only Web3 access.
 *
 * Worth stating plainly, because the migration brief assumed otherwise: the
 * original codebase contained no Web3 at all. There is no `ethers`, `viem`,
 * `web3` or `window.ethereum` anywhere in its 67k lines, and no smart
 * contract. Its "crypto" surface (MedCoin, the USDT P2P desk) was an internal
 * ledger held in Netlify Blobs, with wallet addresses typed in by hand and
 * transfers confirmed manually by an admin. There was therefore no server-side
 * Web3 proxy to remove.
 *
 * This module is the real thing, added so the static build can settle USDT
 * on-chain without a backend: an EIP-1193 wallet (MetaMask and anything else
 * that injects a provider) for signing, and public RPC endpoints for reads, so
 * balances resolve even for a visitor with no wallet installed.
 *
 * `ethers` is loaded as an ES module from a CDN on first use only — the health
 * feed should not pay for a Web3 library it never calls.
 */

const ETHERS_URL = 'https://esm.sh/ethers@6.13.4'

/** Chains the app settles USDT on, each with a CORS-enabled public RPC. */
export const CHAINS = {
  ethereum: {
    id: 1,
    hexId: '0x1',
    name: 'Ethereum',
    rpc: 'https://ethereum-rpc.publicnode.com',
    explorer: 'https://etherscan.io',
    symbol: 'ETH',
    usdt: { address: '0xdAC17F958D2ee523a2206206994597C13D831ec7', decimals: 6 },
  },
  bsc: {
    id: 56,
    hexId: '0x38',
    name: 'BNB Smart Chain',
    rpc: 'https://bsc-rpc.publicnode.com',
    explorer: 'https://bscscan.com',
    symbol: 'BNB',
    // BSC-USD is an 18-decimal token, unlike the 6-decimal Ethereum USDT.
    // Hard-coding 6 here would overstate a balance by a factor of 10^12.
    usdt: { address: '0x55d398326f99059fF775485246999027B3197955', decimals: 18 },
  },
  polygon: {
    id: 137,
    hexId: '0x89',
    name: 'Polygon',
    rpc: 'https://polygon-bor-rpc.publicnode.com',
    explorer: 'https://polygonscan.com',
    symbol: 'POL',
    usdt: { address: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F', decimals: 6 },
  },
}

export const DEFAULT_CHAIN = 'bsc'

/** Minimal ERC-20 surface — balance, metadata and transfer. */
const ERC20_ABI = [
  'function balanceOf(address owner) view returns (uint256)',
  'function decimals() view returns (uint8)',
  'function symbol() view returns (string)',
  'function transfer(address to, uint256 amount) returns (bool)',
  'event Transfer(address indexed from, address indexed to, uint256 value)',
]

let ethersPromise = null

/** Load and cache the ethers ES module. */
export function loadEthers() {
  if (!ethersPromise) {
    ethersPromise = import(/* @vite-ignore */ ETHERS_URL).catch((err) => {
      ethersPromise = null
      throw new Error(`Could not load the Web3 library. ${err.message || err}`)
    })
  }
  return ethersPromise
}

/** True when a browser wallet has injected a provider. */
export function hasInjectedWallet() {
  return typeof window !== 'undefined' && Boolean(window.ethereum)
}

/* ============================ PROVIDERS ============================ */

/**
 * Read-only provider against the chain's public RPC. Used for balance lookups
 * so the wallet page is useful before — or entirely without — a connection.
 */
export async function readProvider(chainKey = DEFAULT_CHAIN) {
  const chain = CHAINS[chainKey]
  if (!chain) throw new Error(`Unknown chain: ${chainKey}`)
  const ethers = await loadEthers()
  return new ethers.JsonRpcProvider(chain.rpc, { chainId: chain.id, name: chain.name })
}

/** Wallet-backed provider. Throws when no wallet is installed. */
export async function walletProvider() {
  if (!hasInjectedWallet()) {
    throw new Error('No browser wallet found. Install MetaMask or open this page in a wallet browser.')
  }
  const ethers = await loadEthers()
  return new ethers.BrowserProvider(window.ethereum)
}

/* ============================ CONNECTION ============================ */

/**
 * Prompt the wallet for accounts. Must be called from a user gesture — wallets
 * reject an unprompted `eth_requestAccounts`.
 */
export async function connect() {
  const provider = await walletProvider()
  try {
    const accounts = await provider.send('eth_requestAccounts', [])
    const network = await provider.getNetwork()
    return {
      address: accounts[0],
      chainId: Number(network.chainId),
    }
  } catch (err) {
    // 4001 is the EIP-1193 "user rejected" code; it is not a failure worth
    // surfacing as an error state.
    if (err?.code === 4001) throw new Error('Connection request was rejected in your wallet.')
    throw err
  }
}

/** Currently authorised account without prompting, or `null`. */
export async function silentAccount() {
  if (!hasInjectedWallet()) return null
  try {
    const accounts = await window.ethereum.request({ method: 'eth_accounts' })
    return accounts?.[0] || null
  } catch {
    return null
  }
}

/**
 * Switch the wallet to a chain, adding it first if the wallet does not know
 * it. 4902 is the "unrecognised chain" code.
 */
export async function switchChain(chainKey) {
  const chain = CHAINS[chainKey]
  if (!chain) throw new Error(`Unknown chain: ${chainKey}`)
  if (!hasInjectedWallet()) throw new Error('No browser wallet found.')

  try {
    await window.ethereum.request({
      method: 'wallet_switchEthereumChain',
      params: [{ chainId: chain.hexId }],
    })
  } catch (err) {
    if (err?.code !== 4902) throw err
    await window.ethereum.request({
      method: 'wallet_addEthereumChain',
      params: [
        {
          chainId: chain.hexId,
          chainName: chain.name,
          rpcUrls: [chain.rpc],
          blockExplorerUrls: [chain.explorer],
          nativeCurrency: { name: chain.symbol, symbol: chain.symbol, decimals: 18 },
        },
      ],
    })
  }
}

/** Wallet account/chain change events, so the UI can follow the wallet. */
export function onWalletChange({ onAccounts, onChain } = {}) {
  if (!hasInjectedWallet()) return () => {}

  const accountsHandler = (accounts) => onAccounts?.(accounts?.[0] || null)
  const chainHandler = (hexId) => onChain?.(parseInt(hexId, 16))

  window.ethereum.on?.('accountsChanged', accountsHandler)
  window.ethereum.on?.('chainChanged', chainHandler)

  return () => {
    window.ethereum.removeListener?.('accountsChanged', accountsHandler)
    window.ethereum.removeListener?.('chainChanged', chainHandler)
  }
}

/* ============================ BALANCES ============================ */

/** Native coin balance (ETH / BNB / POL), formatted. */
export async function nativeBalance(address, chainKey = DEFAULT_CHAIN) {
  const ethers = await loadEthers()
  const provider = await readProvider(chainKey)
  const raw = await provider.getBalance(address)
  return {
    raw,
    formatted: ethers.formatEther(raw),
    symbol: CHAINS[chainKey].symbol,
  }
}

/**
 * USDT balance, read over the public RPC so it works with no wallet connected.
 * Decimals come from the contract rather than the table, so a chain whose
 * token differs from the constant above still reports the right number.
 */
export async function usdtBalance(address, chainKey = DEFAULT_CHAIN) {
  const ethers = await loadEthers()
  const chain = CHAINS[chainKey]
  const provider = await readProvider(chainKey)
  const contract = new ethers.Contract(chain.usdt.address, ERC20_ABI, provider)

  const [raw, decimals] = await Promise.all([
    contract.balanceOf(address),
    contract.decimals().catch(() => chain.usdt.decimals),
  ])

  return {
    raw,
    decimals: Number(decimals),
    formatted: ethers.formatUnits(raw, decimals),
    symbol: 'USDT',
  }
}

/* ============================ TRANSFERS ============================ */

export async function isAddress(value) {
  const ethers = await loadEthers()
  return ethers.isAddress(value)
}

/**
 * Send USDT from the connected wallet.
 *
 * The wallet must already be on `chainKey` — sending on the wrong chain is the
 * single most expensive mistake available here, so this verifies the network
 * before building the transaction rather than trusting the UI's idea of it.
 * Returns once the transaction is broadcast; `wait()` is left to the caller so
 * the UI can show a pending state.
 */
export async function sendUsdt({ to, amount, chainKey = DEFAULT_CHAIN }) {
  const ethers = await loadEthers()
  const chain = CHAINS[chainKey]

  if (!ethers.isAddress(to)) throw new Error('That recipient address is not valid.')
  if (!(Number(amount) > 0)) throw new Error('Enter an amount greater than zero.')

  const provider = await walletProvider()
  const network = await provider.getNetwork()
  if (Number(network.chainId) !== chain.id) {
    throw new Error(`Your wallet is on the wrong network. Switch to ${chain.name} and try again.`)
  }

  const signer = await provider.getSigner()
  const contract = new ethers.Contract(chain.usdt.address, ERC20_ABI, signer)
  const decimals = Number(await contract.decimals().catch(() => chain.usdt.decimals))
  const value = ethers.parseUnits(String(amount), decimals)

  const balance = await contract.balanceOf(await signer.getAddress())
  if (balance < value) throw new Error('Not enough USDT in this wallet for that transfer.')

  const tx = await contract.transfer(to, value)
  return { hash: tx.hash, wait: () => tx.wait(), explorer: `${chain.explorer}/tx/${tx.hash}` }
}

/** `0x1234…abcd` for display. */
export function shortAddress(address, lead = 6, tail = 4) {
  if (!address) return ''
  return `${address.slice(0, lead)}…${address.slice(-tail)}`
}
