/**
 * Client-side router.
 *
 * Uses the History API rather than hash fragments so the URLs the old
 * TanStack Router served (`/doctors`, `/booking`) keep working — inbound links,
 * the sitemap and the installed PWA's start_url all point at real paths. The
 * cost is that the host must serve `index.html` for unknown paths; that is
 * handled by the SPA rewrite in `netlify.toml`, and by `404.html` booting the
 * same bundle on GitHub Pages and Cloudflare Pages, which serve it for misses.
 *
 * Views are dynamic `import()`s, so a visitor who only reads the health feed
 * never downloads the wallet or the WebRTC room. That preserves the code
 * splitting the Vite build was doing, without a bundler.
 */

import { el } from './ui.js'

/**
 * Route table. `load` resolves to a module exporting `render(context)`.
 * `:param` segments are captured into `context.params`.
 */
const ROUTES = [
  { path: '/', load: () => import('./views/home.js'), title: 'Hakimm.com | ሓኪም — Digital Medical Consultation' },
  { path: '/doctors', load: () => import('./views/doctors.js'), title: 'Health Professionals | Hakimm.com' },
  { path: '/doctor/:id', load: () => import('./views/doctor.js'), title: 'Doctor Profile | Hakimm.com' },
  { path: '/booking', load: () => import('./views/booking.js'), title: 'Book a Consultation | Hakimm.com' },
  { path: '/appointments', load: () => import('./views/appointments.js'), title: 'My Appointments | Hakimm.com' },
  { path: '/consultation', load: () => import('./views/consultation.js'), title: 'Consultation Room | Hakimm.com' },
  { path: '/room/:id', load: () => import('./views/room.js'), title: 'Live Consultation | Hakimm.com' },
  { path: '/messaging', load: () => import('./views/messaging.js'), title: 'Chat & Messages | Hakimm.com' },
  { path: '/health-feed', load: () => import('./views/feed.js'), title: 'Health Feed | Hakimm.com' },
  { path: '/post/:id', load: () => import('./views/post.js'), title: 'Health Article | Hakimm.com' },
  { path: '/videos', load: () => import('./views/videos.js'), title: 'Health Videos | Hakimm.com' },
  { path: '/wallet', load: () => import('./views/wallet.js'), title: 'MedCoin Wallet | Hakimm.com' },
  { path: '/web3', load: () => import('./views/web3.js'), title: 'Crypto Wallet | Hakimm.com' },
  { path: '/p2p', load: () => import('./views/p2p.js'), title: 'P2P Marketplace | Hakimm.com' },
  // The sitemap has advertised `/p2p-marketplace` since launch, so the old URL
  // keeps working rather than becoming a 404 for anyone who bookmarked it.
  { path: '/p2p-marketplace', load: () => import('./views/p2p.js'), title: 'P2P Marketplace | Hakimm.com' },
  { path: '/apply-doctor', load: () => import('./views/apply-doctor.js'), title: 'Join as a Professional | Hakimm.com' },
  { path: '/profile', load: () => import('./views/profile.js'), title: 'My Profile | Hakimm.com' },
  { path: '/login', load: () => import('./views/login.js'), title: 'Sign In | Hakimm.com' },
  { path: '/register', load: () => import('./views/register.js'), title: 'Create Account | Hakimm.com' },
  { path: '/about', load: () => import('./views/content.js'), title: 'About | Hakimm.com', props: { doc: 'about' } },
  { path: '/privacy', load: () => import('./views/content.js'), title: 'Privacy Policy | Hakimm.com', props: { doc: 'privacy' } },
  { path: '/terms', load: () => import('./views/content.js'), title: 'Terms of Service | Hakimm.com', props: { doc: 'terms' } },
  { path: '/support', load: () => import('./views/content.js'), title: 'Support | Hakimm.com', props: { doc: 'support' } },
]

/**
 * Base path the app is mounted at. A project-page deploy on GitHub Pages lives
 * under `/<repo>/`, so paths are resolved relative to the document's <base>
 * instead of assuming the site owns the origin root.
 */
export const BASE = (() => {
  const href = document.querySelector('base')?.getAttribute('href') || '/'
  return href.endsWith('/') ? href : `${href}/`
})()

function stripBase(pathname) {
  if (BASE !== '/' && pathname.startsWith(BASE)) return `/${pathname.slice(BASE.length)}`
  return pathname || '/'
}

/** Turn an app path into a real href (`/doctors` → `/repo/doctors`). */
export function href(path) {
  if (/^(https?:|mailto:|tel:)/.test(path)) return path
  return BASE === '/' ? path : `${BASE}${path.replace(/^\//, '')}`
}

function match(pathname) {
  const parts = pathname.replace(/\/+$/, '').split('/').filter(Boolean)

  for (const route of ROUTES) {
    const routeParts = route.path.split('/').filter(Boolean)
    if (routeParts.length !== parts.length) continue

    const params = {}
    const ok = routeParts.every((segment, index) => {
      if (segment.startsWith(':')) {
        params[segment.slice(1)] = decodeURIComponent(parts[index])
        return true
      }
      return segment === parts[index]
    })

    if (ok) return { route, params }
  }
  return null
}

/* ============================ PROGRESS BAR ============================ */

/**
 * Thin top progress bar. The React build had a `PageProgressBar` component for
 * the same reason: a dynamic import on a slow Ethiopian mobile connection can
 * take a second, and without feedback a tap looks ignored.
 */
const progress = el('div.route-progress')

function startProgress() {
  document.body.append(progress)
  progress.style.opacity = '1'
  progress.style.width = '30%'
  setTimeout(() => {
    progress.style.width = '70%'
  }, 180)
}

function endProgress() {
  progress.style.width = '100%'
  setTimeout(() => {
    progress.style.opacity = '0'
    progress.style.width = '0'
  }, 220)
}

/* ============================ NAVIGATION ============================ */

const listeners = new Set()
let outlet = null
let currentPath = null
/** Guards against a slow import resolving after the user has moved on. */
let renderToken = 0

/** Subscribe to route changes (the header uses this to move `aria-current`). */
export function onRouteChange(fn) {
  listeners.add(fn)
  return () => listeners.delete(fn)
}

export function currentRoute() {
  return currentPath
}

/** Programmatic navigation. `replace` avoids stacking history entries. */
export function navigate(to, { replace = false } = {}) {
  const url = new URL(href(to), location.origin)
  if (url.pathname + url.search === location.pathname + location.search) return
  history[replace ? 'replaceState' : 'pushState']({}, '', url)
  render()
}

/** `<a>` builder that keeps navigation in-app. */
export function link(to, attrs, children = null) {
  // Callers that want children but no attributes pass `null`, which a default
  // parameter would not catch — and the click handler below reads `attrs`.
  attrs = attrs || {}

  return el(
    'a',
    {
      href: href(to),
      ...attrs,
      onclick: (event) => {
        // Let the browser handle modified clicks so "open in new tab" works.
        if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0) return
        event.preventDefault()
        navigate(to)
        attrs.onclick?.(event)
      },
    },
    children,
  )
}

async function render() {
  const token = ++renderToken
  const pathname = stripBase(location.pathname)
  const search = new URLSearchParams(location.search)
  const matched = match(pathname)
  // A re-render of the same URL (a language switch) must not throw the reader
  // back to the top of the article they were part-way through.
  const samePath = currentPath === pathname

  currentPath = pathname
  for (const fn of listeners) fn(pathname)

  startProgress()

  let module
  let params = {}
  let props = {}

  try {
    if (matched) {
      module = await matched.route.load()
      params = matched.params
      props = matched.route.props || {}
      document.title = matched.route.title || 'Hakimm.com'
    } else {
      module = await import('./views/notfound.js')
      document.title = 'Page not found | Hakimm.com'
    }
  } catch (err) {
    console.error('[router] failed to load view', err)
    module = { render: () => el('div.container.section', null, el('div.notice.notice--danger', null, 'This page could not be loaded. Check your connection and try again.')) }
  }

  // A newer navigation started while this import was in flight.
  if (token !== renderToken) return

  try {
    const view = await module.render({ params, search, props, navigate })
    if (token !== renderToken) return
    outlet.replaceChildren(view)
  } catch (err) {
    console.error('[router] view crashed', err)
    outlet.replaceChildren(
      el('div.container.section', null, el('div.notice.notice--danger', null, 'Something went wrong rendering this page.')),
    )
  } finally {
    endProgress()
  }

  // Restore scroll for a fresh navigation; the browser handles back/forward.
  if (!samePath && !history.state?.restore) window.scrollTo(0, 0)
}

/** Re-render the current route in place — used when the language changes. */
export function refresh() {
  if (outlet) render()
}

/** Mount the router into an outlet element and render the current URL. */
export function start(outletElement) {
  outlet = outletElement

  window.addEventListener('popstate', render)

  // Catch clicks on links that were not built with `link()` — content pages
  // render plain anchors, and they should still route in-app.
  document.addEventListener('click', (event) => {
    if (event.defaultPrevented || event.metaKey || event.ctrlKey || event.shiftKey || event.button !== 0) return
    const anchor = event.target.closest?.('a[href]')
    if (!anchor || anchor.target === '_blank' || anchor.hasAttribute('download')) return

    const url = new URL(anchor.href, location.href)
    if (url.origin !== location.origin) return
    if (!match(stripBase(url.pathname))) return

    event.preventDefault()
    navigate(stripBase(url.pathname) + url.search)
  })

  render()
}
