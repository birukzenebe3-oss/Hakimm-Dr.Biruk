/**
 * Application entry point.
 *
 * Replaces `src/routes/__root.tsx` from the React build: it owns the parts of
 * the page that persist across navigations — header, primary navigation,
 * language toggle, mobile tab bar and footer — then hands the outlet to the
 * router. Everything below this file is loaded on demand.
 *
 * There is no framework runtime and no hydration step. The shell is built once
 * from real DOM nodes and mutated in place when auth, language or route
 * changes; views are replaced wholesale by the router.
 */

import { seedOnce } from './store.js'
import { getLang, onLangChange, t, toggleLang } from './i18n.js'
import { telegramLink } from './brand.js'
import { currentUser, onAuthChange, signOut } from './auth.js'
import { avatar, el, fill, icon, toast } from './ui.js'
import { currentRoute, href, link, navigate, onRouteChange, refresh, start } from './router.js'

/* ============================ NAVIGATION MODEL ============================ */

/**
 * Desktop header links. The mobile equivalent is the five-item tab bar below;
 * everything not in it is reachable from the home tile grid and the footer,
 * which is how the React build handled the same overflow.
 */
const NAV = [
  { path: '/doctors', en: 'Doctors', am: 'ዶክተሮች' },
  { path: '/health-feed', en: 'Health Feed', am: 'የጤና መረጃ' },
  { path: '/videos', en: 'Videos', am: 'ቪዲዮዎች' },
  { path: '/wallet', en: 'MedCoin', am: 'ሜድኮይን' },
  { path: '/web3', en: 'Crypto', am: 'ክሪፕቶ' },
  { path: '/p2p', en: 'P2P', am: 'ግብይት' },
]

/**
 * Bottom tab bar. Exactly five entries — the grid is `repeat(5, 1fr)`, and a
 * conditional item would leave a gap. `/appointments` is shown to signed-out
 * visitors too; that view prompts for sign-in rather than disappearing.
 */
const TABS = [
  { path: '/', icon: 'home', en: 'Home', am: 'መነሻ' },
  { path: '/doctors', icon: 'stethoscope', en: 'Doctors', am: 'ዶክተሮች' },
  { path: '/appointments', icon: 'calendar', en: 'Bookings', am: 'ቀጠሮ' },
  { path: '/messaging', icon: 'message', en: 'Chat', am: 'ውይይት' },
  { path: '/profile', icon: 'user', en: 'Profile', am: 'መገለጫ' },
]

const headerHost = document.getElementById('app-header')
const tabbarHost = document.getElementById('app-tabbar')
const footerHost = document.getElementById('app-footer')
const outlet = document.getElementById('main')

/* ============================ HEADER ============================ */

function buildHeader() {
  const brand = link('/', { class: 'brand', 'aria-label': 'Hakimm.com — home' }, [
    el('img.brand__mark', {
      src: href('assets/images/hakimm-logo.jpg'),
      alt: '',
      width: 32,
      height: 32,
      fetchpriority: 'high',
    }),
    el('span', null, 'Hakimm'),
    el('span.brand__am', { lang: 'am' }, 'ሓኪም'),
  ])

  const nav = el(
    'nav.app-nav',
    { 'aria-label': t('Main navigation', 'ዋና ዝርዝር') },
    NAV.map((item) => link(item.path, null, t(item.en, item.am))),
  )

  const langToggle = el(
    'button.lang-toggle',
    {
      type: 'button',
      title: getLang() === 'am' ? 'Switch to English' : 'ወደ አማርኛ ቀይር',
      onclick: () => {
        toggleLang()
        toast(getLang() === 'am' ? 'ቋንቋ ወደ አማርኛ ተቀይሯል' : 'Language set to English', 'success')
      },
    },
    getLang() === 'am' ? 'EN' : 'አማ',
  )

  fill(headerHost, [
    el('div.container.app-header__inner', null, [
      brand,
      nav,
      el('div.header-actions', null, [langToggle, ...accountControls()]),
    ]),
  ])
}

function accountControls() {
  const user = currentUser()

  if (!user) {
    return [
      link('/login', { class: 'ds-btn ds-btn-quiet' }, t('Sign in', 'ግባ')),
      link('/register', { class: 'ds-btn ds-btn-primary' }, t('Get started', 'ጀምር')),
    ]
  }

  return [
    link('/profile', { class: 'row', title: user.name }, avatar(user, { size: 'sm' })),
    el(
      'button.icon-btn',
      {
        type: 'button',
        title: t('Sign out', 'ውጣ'),
        'aria-label': t('Sign out', 'ውጣ'),
        onclick: () => {
          signOut()
          toast(t('Signed out', 'ወጥተዋል'), 'info')
          navigate('/')
        },
      },
      icon('logout', { size: 18 }),
    ),
  ]
}

/* ============================ TAB BAR ============================ */

/**
 * Mobile bottom navigation. The React build used a fixed bar for the same
 * reason: nearly all traffic is on a phone, where the header nav is hidden.
 */
function buildTabbar() {
  fill(
    tabbarHost,
    TABS.map((item) =>
      link(item.path, { 'aria-current': currentRoute() === item.path ? 'page' : null }, [
        icon(item.icon, { size: 20 }),
        el('span', null, t(item.en, item.am)),
      ]),
    ),
  )
}

/* ============================ FOOTER ============================ */

function buildFooter() {
  const column = (heading, links) =>
    el('div', null, [
      el('h4', null, heading),
      el('ul', null, links.map(([to, label]) => el('li', null, link(to, null, label)))),
    ])

  fill(footerHost, [
    el('div.container', null, [
      el('div.app-footer__cols', null, [
        el('div', null, [
          el('h4', null, 'Hakimm.com'),
          el('p', null, t(
            'Multi-specialty telehealth for Ethiopia — consultations by video, audio and chat.',
            'ለኢትዮጵያ የተዘጋጀ የቴሌሄልዝ አገልግሎት — በቪዲዮ፣ በድምፅ እና በጽሑፍ ምክክር።',
          )),
        ]),

        column(t('Care', 'እንክብካቤ'), [
          ['/doctors', t('Find a doctor', 'ዶክተር ያግኙ')],
          ['/booking', t('Book a consultation', 'ቀጠሮ ይያዙ')],
          ['/appointments', t('My appointments', 'ቀጠሮዎቼ')],
          ['/messaging', t('Messages', 'መልዕክቶች')],
        ]),

        column(t('Learn', 'ይማሩ'), [
          ['/health-feed', t('Health feed', 'የጤና መረጃ')],
          ['/videos', t('Videos', 'ቪዲዮዎች')],
          ['/about', t('About us', 'ስለ እኛ')],
          ['/support', t('Support', 'ድጋፍ')],
        ]),

        el('div', null, [
          el('h4', null, t('Legal', 'ሕጋዊ')),
          el('ul', null, [
            el('li', null, link('/privacy', null, t('Privacy policy', 'የግላዊነት ፖሊሲ'))),
            el('li', null, link('/terms', null, t('Terms of service', 'የአገልግሎት ውሎች'))),
            el('li', null, el('a', {
              href: telegramLink(),
              target: '_blank',
              rel: 'noopener noreferrer',
            }, 'Telegram')),
          ]),
        ]),
      ]),

      el('div.app-footer__legal', null, [
        el('p', null, `© ${new Date().getFullYear()} Hakimm.com`),
        el('p', null, t(
          'General health education — not a substitute for in-person examination. In an emergency, go to the nearest health facility.',
          'አጠቃላይ የጤና ትምህርት — በአካል የሚደረግ ምርመራን አይተካም። በአስቸኳይ ጊዜ ወደ ቅርብ የጤና ተቋም ይሂዱ።',
        )),
      ]),
    ]),
  ])
}

/* ============================ REACTIVITY ============================ */

/** Move `aria-current` to whichever header/tab link matches the new route. */
function markActive(path) {
  for (const anchor of document.querySelectorAll('.app-nav a, .tabbar a')) {
    const target = new URL(anchor.href, location.href).pathname
    if (target === href(path)) anchor.setAttribute('aria-current', 'page')
    else anchor.removeAttribute('aria-current')
  }
}

function rebuildShell() {
  buildHeader()
  buildTabbar()
  buildFooter()
  markActive(currentRoute() || '/')
}

/* ============================ BOOT ============================ */

async function boot() {
  document.documentElement.lang = getLang()

  rebuildShell()

  onAuthChange(rebuildShell)
  onRouteChange(markActive)

  // A language switch re-labels the whole page. Views carry both translations
  // inline via `t()`, so the cheapest correct response is to rebuild the shell
  // and re-render the current route rather than thread a locale through every
  // component.
  onLangChange(() => {
    document.documentElement.lang = getLang()
    rebuildShell()
    refresh()
  })

  // Loads the sample directory and articles into IndexedDB on first visit.
  // A failure here is not fatal — the app runs empty rather than not at all.
  try {
    await seedOnce()
  } catch (err) {
    console.error('[app] seeding failed', err)
  }

  start(outlet)

  registerServiceWorker()
}

/**
 * The service worker is what makes an offline visit useful — an article
 * already read should still open on a dropped connection. Registered after
 * the first render so it never competes with it.
 */
function registerServiceWorker() {
  if (!('serviceWorker' in navigator) || location.protocol === 'file:') return
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register(href('sw.js'), { scope: href('/') })
      .catch((err) => console.warn('[app] service worker registration failed', err))
  })
}

boot()
