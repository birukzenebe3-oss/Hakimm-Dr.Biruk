/**
 * DOM kit: element construction, the icon set, toasts and modals.
 *
 * No virtual DOM and no template compiler — views build real nodes and hand
 * them back to the router. `el()` covers the ergonomics JSX was providing
 * (nested children, event handlers, conditional attributes) in about forty
 * lines, and because it sets text through `textContent` rather than
 * `innerHTML`, values coming out of IndexedDB cannot inject markup. That
 * matters more here than it did in the React build: user-authored chat
 * messages and profile fields are rendered on the same page as the wallet.
 */

/* ============================ ELEMENTS ============================ */

/**
 * `el('div.card', { onclick }, [child, 'text'])`
 *
 * The tag accepts a CSS-ish shorthand: `tag.class.class#id`. Attributes are
 * applied as properties when the property exists (so `onclick`, `value` and
 * `checked` behave), otherwise as attributes.
 */
export function el(spec, attrs = null, children = null) {
  const [tagAndClasses, id] = String(spec).split('#')
  const [tag, ...classes] = tagAndClasses.split('.')
  const node = document.createElement(tag || 'div')

  if (classes.length) node.className = classes.join(' ')
  if (id) node.id = id

  if (attrs) {
    for (const [key, value] of Object.entries(attrs)) {
      if (value === null || value === undefined || value === false) continue

      if (key === 'class' || key === 'className') {
        node.className = [node.className, value].filter(Boolean).join(' ')
      } else if (key === 'style' && typeof value === 'object') {
        Object.assign(node.style, value)
      } else if (key === 'dataset' && typeof value === 'object') {
        Object.assign(node.dataset, value)
      } else if (key === 'html') {
        // Only ever used with markup this module builds itself.
        node.innerHTML = value
      } else if (key.startsWith('on') && typeof value === 'function') {
        node.addEventListener(key.slice(2), value)
      } else if (key in node && key !== 'list' && key !== 'form') {
        node[key] = value
      } else {
        node.setAttribute(key, value === true ? '' : value)
      }
    }
  }

  append(node, children)
  return node
}

/** Append anything view code might return: nodes, strings, arrays, nullish. */
export function append(parent, children) {
  if (children === null || children === undefined || children === false) return parent
  if (Array.isArray(children)) {
    for (const child of children) append(parent, child)
    return parent
  }
  parent.append(children instanceof Node ? children : document.createTextNode(String(children)))
  return parent
}

/** Replace a node's contents in one shot. */
export function fill(parent, children) {
  parent.replaceChildren()
  return append(parent, children)
}

export const frag = (children) => append(document.createDocumentFragment(), children)

/* ============================ ICONS ============================ */

/**
 * Inline SVG replacements for the `lucide-react` icons the components used.
 * Shipping the paths inline avoids a 200 KB icon dependency and a render-
 * blocking request for what amounts to thirty small shapes.
 */
const ICON_PATHS = {
  stethoscope:
    '<path d="M4 2v6a4 4 0 0 0 8 0V2"/><path d="M8 12v3a6 6 0 0 0 12 0v-2"/><circle cx="20" cy="10" r="2"/><path d="M4 2H2M12 2h-2"/>',
  calendar:
    '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
  message:
    '<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/>',
  video:
    '<path d="m22 8-6 4 6 4V8Z"/><rect x="2" y="6" width="14" height="12" rx="2"/>',
  videoOff:
    '<path d="M10.66 6H14a2 2 0 0 1 2 2v2.34l1 1L22 8v8"/><path d="M16 16a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h2"/><path d="m2 2 20 20"/>',
  phone:
    '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92Z"/>',
  mic:
    '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M19 10v1a7 7 0 0 1-14 0v-1M12 18v4"/>',
  micOff:
    '<path d="m2 2 20 20"/><path d="M9 9v3a3 3 0 0 0 5.12 2.12M15 9.34V5a3 3 0 0 0-5.94-.6"/><path d="M19 10v1a7 7 0 0 1-.11 1.23M5 10v1a7 7 0 0 0 10.7 5.95M12 18v4"/>',
  phoneOff:
    '<path d="M10.68 13.31a16 16 0 0 0 3.41 2.6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.4 19.4 0 0 1-3.33-2.67"/><path d="M22 2 2 22"/><path d="M5.09 5.09A19.8 19.8 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91"/>',
  star: '<path d="m12 2 3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01Z"/>',
  badgeCheck:
    '<path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z"/><path d="m9 12 2 2 4-4"/>',
  home: '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z"/><path d="M9 22V12h6v10"/>',
  user: '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  users:
    '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
  wallet:
    '<path d="M19 7V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-2"/><path d="M21 11h-6a2 2 0 0 0 0 4h6Z"/>',
  news:
    '<path d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-4 0v-9h4"/><path d="M18 14h-8M15 18h-5M10 6h8v4h-8Z"/>',
  play: '<circle cx="12" cy="12" r="10"/><path d="m10 8 6 4-6 4Z"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  close: '<path d="M18 6 6 18M6 6l12 12"/>',
  chevronRight: '<path d="m9 18 6-6-6-6"/>',
  chevronLeft: '<path d="m15 18-6-6 6-6"/>',
  arrowLeft: '<path d="M19 12H5M12 19l-7-7 7-7"/>',
  send: '<path d="M14.54 3.53a1 1 0 0 1 1.7-.7l4.93 4.93a1 1 0 0 1-.7 1.7L3 11 21 3Z"/><path d="m11 13 10-10"/>',
  heart:
    '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>',
  shield: '<path d="M20 13c0 5-3.5 7.5-8 9-4.5-1.5-8-4-8-9V6l8-3 8 3Z"/><path d="m9 12 2 2 4-4"/>',
  clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
  bell: '<path d="M10.27 21a2 2 0 0 0 3.46 0"/><path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/>',
  globe: '<circle cx="12" cy="12" r="10"/><path d="M12 2a15 15 0 0 1 0 20M12 2a15 15 0 0 0 0 20M2 12h20"/>',
  copy: '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5M21 12H9"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  alert: '<path d="M12 9v4M12 17h.01"/><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0Z"/>',
  info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5M12 15V3"/>',
  upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m17 8-5-5-5 5M12 3v12"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
  coins: '<circle cx="8" cy="8" r="6"/><path d="M18.09 10.37A6 6 0 1 1 10.34 18M7 6h1v4M16.71 13.88l.7.71-2.82 2.82"/>',
  refresh: '<path d="M3 12a9 9 0 0 1 15-6.7L21 8M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15 6.7L3 16M3 21v-5h5"/>',
  file: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v5h6"/>',
  activity: '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
}

/**
 * `icon('star', { size: 16, class: 'x' })` → an `<svg>` node.
 * Stroke-based to match lucide's default look; `currentColor` so it inherits.
 */
export function icon(name, { size = 18, className = '', fill = 'none' } = {}) {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
  svg.setAttribute('viewBox', '0 0 24 24')
  svg.setAttribute('width', size)
  svg.setAttribute('height', size)
  svg.setAttribute('fill', fill)
  svg.setAttribute('stroke', 'currentColor')
  svg.setAttribute('stroke-width', '2')
  svg.setAttribute('stroke-linecap', 'round')
  svg.setAttribute('stroke-linejoin', 'round')
  svg.setAttribute('aria-hidden', 'true')
  if (className) svg.setAttribute('class', className)
  svg.innerHTML = ICON_PATHS[name] || ICON_PATHS.info
  return svg
}

/* ============================ TOASTS ============================ */

let toastHost = null

function ensureToastHost() {
  if (!toastHost || !toastHost.isConnected) {
    toastHost = el('div.toast-host', { role: 'status', 'aria-live': 'polite' })
    document.body.append(toastHost)
  }
  return toastHost
}

/** Transient confirmation. `variant` is 'info' | 'success' | 'error'. */
export function toast(message, variant = 'info', ms = 3200) {
  const host = ensureToastHost()
  const node = el(`div.toast.toast--${variant}`, null, [
    icon(variant === 'error' ? 'alert' : variant === 'success' ? 'check' : 'info', { size: 16 }),
    el('span', null, message),
  ])
  host.append(node)

  setTimeout(() => {
    node.style.opacity = '0'
    node.style.transition = 'opacity 200ms ease'
    setTimeout(() => node.remove(), 220)
  }, ms)

  return node
}

/* ============================ MODAL ============================ */

/**
 * Open a modal. Resolves with whatever `close(value)` is called with, or
 * `null` when dismissed via backdrop / Escape.
 *
 * Focus is moved into the dialog and restored to the trigger on close, and
 * Tab is trapped inside — without that, a keyboard user tabs straight out of
 * the dialog into the page behind it.
 */
export function modal({ title, description, body, actions }) {
  return new Promise((resolve) => {
    const previouslyFocused = document.activeElement

    const dialog = el('div.modal', {
      role: 'dialog',
      'aria-modal': 'true',
      'aria-label': title || 'Dialog',
    })

    const host = el('div.modal-host', {
      onclick: (event) => {
        if (event.target === host) close(null)
      },
    }, dialog)

    function close(value) {
      document.removeEventListener('keydown', onKeydown, true)
      host.remove()
      if (previouslyFocused instanceof HTMLElement) previouslyFocused.focus()
      resolve(value)
    }

    function onKeydown(event) {
      if (event.key === 'Escape') {
        event.preventDefault()
        close(null)
        return
      }
      if (event.key !== 'Tab') return

      const focusable = dialog.querySelectorAll(
        'a[href], button:not([disabled]), input:not([disabled]), select, textarea, [tabindex]:not([tabindex="-1"])',
      )
      if (!focusable.length) return
      const first = focusable[0]
      const last = focusable[focusable.length - 1]
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault()
        last.focus()
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault()
        first.focus()
      }
    }

    append(dialog, [
      title ? el('h2.modal__title', null, title) : null,
      description ? el('p.modal__desc', null, description) : null,
      typeof body === 'function' ? body(close) : body,
      actions ? el('div.form-actions', null, actions(close)) : null,
    ])

    document.addEventListener('keydown', onKeydown, true)
    document.body.append(host)

    const target = dialog.querySelector('input, select, textarea, button')
    if (target instanceof HTMLElement) target.focus()
    else dialog.focus()
  })
}

/* ============================ BUILDING BLOCKS ============================ */

export function empty(message, iconName = 'info') {
  return el('div.empty', null, [
    el('div.empty__icon', null, icon(iconName, { size: 22 })),
    el('p', null, message),
  ])
}

/** Placeholder rows shown while a collection is read out of IndexedDB. */
export function skeletonCards(count = 4, height = '7rem') {
  return el(
    'div.card-grid',
    null,
    Array.from({ length: count }, () => el('div.skeleton', { style: { height } })),
  )
}

export function pill(text, variant = '') {
  return el(`span.pill${variant ? `.pill--${variant}` : ''}`, null, text)
}

export function field({ label, hint, input }) {
  return el('label.field', null, [
    el('span.field__label', null, label),
    input,
    hint ? el('span.field__hint', null, hint) : null,
  ])
}

/** Copy text and confirm. `navigator.clipboard` needs a secure context. */
export async function copyText(text, message = 'Copied') {
  try {
    await navigator.clipboard.writeText(text)
    toast(message, 'success', 1800)
    return true
  } catch {
    toast('Could not copy — select the text and copy manually', 'error')
    return false
  }
}

export function initials(name) {
  return (
    String(name || '')
      .replace(/^(ዶ\/ር|ዶክተር|Dr\.?)\s*/i, '')
      .trim()
      .charAt(0)
      .toUpperCase() || '?'
  )
}

/** Avatar with photo, initial fallback and an optional presence dot. */
export function avatar(person, { size = '', online = false } = {}) {
  const node = el(`span.avatar${size ? `.avatar--${size}` : ''}`)
  if (person?.profilePicture) {
    node.append(el('img', { src: person.profilePicture, alt: '', loading: 'lazy', decoding: 'async' }))
  } else {
    node.append(document.createTextNode(initials(person?.name)))
  }
  if (online) node.append(el('span.online-dot', { title: 'Online' }))
  return node
}
