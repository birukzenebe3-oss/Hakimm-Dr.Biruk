/**
 * Home.
 *
 * Rebuilds `src/routes/index.tsx`: the gradient hero with the 3D card stack,
 * the quick-action tile grid, a horizontal rail of available professionals and
 * a preview of the health feed. The depth effects are the original `.d3-*`
 * classes, which respect `prefers-reduced-motion` in the stylesheet.
 */

import { all } from '../store.js'
import { t } from '../i18n.js'
import { el, empty, icon, skeletonCards } from '../ui.js'
import { link } from '../router.js'
import { doctorCard, sectionHead } from './_shared.js'

/** Quick actions. Mirrors the tile menu the React home page opened with. */
const TILES = [
  { path: '/doctors', icon: 'stethoscope', en: 'Find a doctor', am: 'ዶክተር ያግኙ', tint: 'var(--ds-brand-600)' },
  { path: '/booking', icon: 'calendar', en: 'Book a consultation', am: 'ቀጠሮ ይያዙ', tint: 'var(--ds-accent-500)' },
  { path: '/messaging', icon: 'message', en: 'Chat with a doctor', am: 'ከዶክተር ጋር ይወያዩ', tint: '#7c3aed' },
  { path: '/health-feed', icon: 'news', en: 'Health feed', am: 'የጤና መረጃ', tint: '#0891b2' },
  { path: '/videos', icon: 'play', en: 'Health videos', am: 'የጤና ቪዲዮዎች', tint: '#db2777' },
  { path: '/wallet', icon: 'coins', en: 'MedCoin wallet', am: 'ሜድኮይን ቦርሳ', tint: '#ca8a04' },
  { path: '/web3', icon: 'wallet', en: 'Crypto wallet', am: 'ክሪፕቶ ቦርሳ', tint: '#0f766e' },
  { path: '/p2p', icon: 'refresh', en: 'P2P marketplace', am: 'የP2P ገበያ', tint: '#475569' },
]

const HOW_IT_WORKS = [
  {
    icon: 'search',
    en: 'Choose a professional',
    am: 'ባለሙያ ይምረጡ',
    enBody: 'Browse by specialty, language and fee. Availability is shown on each card.',
    amBody: 'በሙያ፣ በቋንቋ እና በክፍያ ይምረጡ። የሚገኙበት ሁኔታ በእያንዳንዱ ካርድ ላይ ይታያል።',
  },
  {
    icon: 'calendar',
    en: 'Pick a time',
    am: 'ሰዓት ይምረጡ',
    enBody: 'Book a slot and choose video, audio or chat. The booking is kept on your device.',
    amBody: 'ሰዓት ይያዙ እና ቪዲዮ፣ ድምፅ ወይም ጽሑፍ ይምረጡ። ቀጠሮው በመሣሪያዎ ላይ ይቀመጣል።',
  },
  {
    icon: 'video',
    en: 'Join the room',
    am: 'ወደ ክፍሉ ይግቡ',
    enBody: 'The call connects browser to browser — the media never passes through a server.',
    amBody: 'ጥሪው በቀጥታ ከአሳሽ ወደ አሳሽ ይገናኛል — መረጃው በአገልጋይ አያልፍም።',
  },
]

export async function render() {
  const root = el('div')

  root.append(hero(), tiles(), doctorsRail(), howItWorks())
  return root
}

/* ============================ HERO ============================ */

function hero() {
  return el('section.hero.ds-brand-gradient.ds-grid-overlay', null, [
    el('div.container.hero__inner', null, [
      el('div', null, [
        el('p.ds-eyebrow', null, t('Telehealth for Ethiopia', 'ለኢትዮጵያ የተዘጋጀ ቴሌሄልዝ')),

        el('h1.ds-display', null, t(
          'Talk to a doctor without leaving home',
          'ከቤትዎ ሳይወጡ ከዶክተር ጋር ይነጋገሩ',
        )),

        el('p', null, t(
          'Verified health professionals across internal medicine, paediatrics, gynaecology, dermatology, psychiatry and more — by video, audio or chat.',
          'በውስጥ ደዌ፣ በሕፃናት፣ በማህፀን፣ በቆዳ፣ በአእምሮ ሕክምና እና በሌሎችም የተረጋገጡ ባለሙያዎች — በቪዲዮ፣ በድምፅ ወይም በጽሑፍ።',
        )),

        el('div.hero__cta', null, [
          link('/doctors', { class: 'ds-btn ds-btn-accent' }, [
            icon('stethoscope', { size: 16 }),
            el('span', null, t('Find a doctor', 'ዶክተር ያግኙ')),
          ]),
          link('/booking', { class: 'ds-btn ds-btn-ghost-light' }, [
            icon('calendar', { size: 16 }),
            el('span', null, t('Book now', 'አሁን ይያዙ')),
          ]),
        ]),

        el('div.hero__stats', null, [
          stat('8+', t('Specialties', 'ሙያዎች')),
          stat('3', t('Ways to consult', 'የምክክር መንገዶች')),
          stat('24/7', t('Health library', 'የጤና ቤተ-መጻሕፍት')),
        ]),
      ]),

      // Decorative card stack. Hidden below 900px by the stylesheet, so the
      // phone layout never pays for it.
      el('div.hero__art.d3-scene', { 'aria-hidden': 'true' }, [
        el('div.hero__card.ds-glass-strong.d3.d3-sheen.d3-layer-front.d3-float', null, [
          el('div.row', null, [
            el('span.avatar', null, 'A'),
            el('div', null, [
              el('div.doc-card__name', null, 'Dr. Almaz Tesfaye'),
              el('div.text-xs', null, t('Internal Medicine · Online', 'የውስጥ ደዌ · በመስመር ላይ')),
            ]),
          ]),
          el('div.stat-row.mt-2', null, [
            el('div.stat.ds-glass', null, [el('div.stat__value', null, '4.9'), el('div.stat__label', null, t('Rating', 'ደረጃ'))]),
            el('div.stat.ds-glass', null, [el('div.stat__value', null, '218'), el('div.stat__label', null, t('Consults', 'ምክክሮች'))]),
          ]),
        ]),

        el('div.hero__card.ds-glass.d3.d3-layer-back.d3-float-lag.mt-2', null, [
          el('div.row', null, [icon('video', { size: 18 }), el('strong', null, t('Video consultation', 'የቪዲዮ ምክክር'))]),
          el('p.text-xs.mt-1', null, t('Direct browser-to-browser call', 'በቀጥታ ከአሳሽ ወደ አሳሽ ጥሪ')),
        ]),
      ]),
    ]),
  ])
}

function stat(value, label) {
  return el('div.hero__stat.ds-glass', null, [el('b', null, value), el('span', null, label)])
}

/* ============================ TILES ============================ */

function tiles() {
  return el('section.container.section', null, [
    sectionHead(t('What would you like to do?', 'ምን ማድረግ ይፈልጋሉ?')),
    el(
      'div.tile-grid',
      null,
      TILES.map((tile) =>
        link(tile.path, { class: 'tile d3-tile' }, [
          el('span.tile__icon', { style: { background: tile.tint } }, icon(tile.icon, { size: 18 })),
          el('span', null, [
            el('span.tile__label', null, t(tile.en, tile.am)),
            el('span.tile__label-am', { lang: 'am' }, tile.am),
          ]),
        ]),
      ),
    ),
  ])
}

/* ============================ DOCTORS RAIL ============================ */

function doctorsRail() {
  const section = el('section.container.section', null, [
    sectionHead(t('Available professionals', 'የሚገኙ ባለሙያዎች'), {
      sub: t('Verified doctors accepting consultations', 'ምክክር የሚቀበሉ የተረጋገጡ ዶክተሮች'),
      more: '/doctors',
    }),
  ])

  const rail = el('div.ds-rail', null, skeletonCards(3, '10rem'))
  section.append(rail)

  all('doctors')
    .then((doctors) => {
      const available = doctors.sort((a, b) => Number(b.isOnline) - Number(a.isOnline)).slice(0, 8)
      rail.replaceChildren(
        ...(available.length
          ? available.map((doctor) => doctorCard(doctor, { rail: true }))
          : [empty(t('No professionals listed yet.', 'እስካሁን የተዘረዘሩ ባለሙያዎች የሉም።'), 'users')]),
      )
    })
    .catch(() => {
      rail.replaceChildren(empty(t('Could not load the directory.', 'ዝርዝሩን መጫን አልተቻለም።'), 'alert'))
    })

  return section
}

/* ============================ HOW IT WORKS ============================ */

function howItWorks() {
  return el('section.container.section', null, [
    sectionHead(t('How it works', 'እንዴት ይሠራል')),
    el(
      'div.card-grid',
      null,
      HOW_IT_WORKS.map((step, index) =>
        el('div.card.stack-sm', null, [
          el('div.row', null, [
            el('span.steps__dot', { style: { background: 'var(--ds-brand-600)', color: '#fff' } }, String(index + 1)),
            icon(step.icon, { size: 18 }),
          ]),
          el('h3.doc-card__name', null, t(step.en, step.am)),
          el('p.text-sm.text-muted', null, t(step.enBody, step.amBody)),
        ]),
      ),
    ),
  ])
}
