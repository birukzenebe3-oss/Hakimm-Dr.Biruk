/**
 * Health videos.
 *
 * Replaces `src/routes/videos.tsx` and the `/api/gallery-media/*` endpoint,
 * which proxied Cloudinary through a signed server request (the signature came
 * from `netlify/functions/generate-signature.mts`). A static build cannot sign
 * anything without publishing the secret, so playback sources are plain public
 * URLs held in the record: a `videoUrl` for a direct file, or an `embedUrl`
 * for a hosted player.
 *
 * Seed entries deliberately ship without a source. Rather than fake a player,
 * a card with no source says so and offers the written article instead — see
 * the note in `results.md` about restoring the media library.
 */

import { all } from '../store.js'
import { formatDate, t } from '../i18n.js'
import { el, empty, icon, modal, skeletonCards } from '../ui.js'
import { link } from '../router.js'
import { pageHead } from './_shared.js'

export async function render() {
  const root = el('div')
  const grid = el('div.video-grid', null, skeletonCards(6, '11rem'))
  const chipRow = el('div.chips', { role: 'group', 'aria-label': t('Filter by category', 'በምድብ አጣራ') })

  let videos = []
  let category = ''

  root.append(
    pageHead(
      t('Health videos', 'የጤና ቪዲዮዎች'),
      t(
        'Short demonstrations of the techniques that are hard to describe in text.',
        'በጽሑፍ ለመግለጽ አስቸጋሪ የሆኑ ዘዴዎችን የሚያሳዩ አጫጭር ማሳያዎች።',
      ),
    ),
    el('div.container.stack', null, [chipRow, grid]),
  )

  function apply() {
    const filtered = category ? videos.filter((video) => video.category === category) : videos

    grid.replaceChildren(
      ...(filtered.length
        ? filtered.map(card)
        : [empty(t('No videos in this category yet.', 'በዚህ ምድብ ውስጥ እስካሁን ቪዲዮ የለም።'), 'play')]),
    )
  }

  function buildChips() {
    const categories = [...new Set(videos.map((video) => video.category).filter(Boolean))].sort()

    const chip = (value, label) =>
      el(
        'button.chip',
        {
          type: 'button',
          'aria-pressed': category === value ? 'true' : 'false',
          onclick: () => {
            category = category === value ? '' : value
            buildChips()
            apply()
          },
        },
        label,
      )

    chipRow.replaceChildren(chip('', t('All', 'ሁሉም')), ...categories.map((value) => chip(value, value)))
  }

  function card(video) {
    const playable = Boolean(video.videoUrl || video.embedUrl)

    const thumb = el(
      'button.video-embed',
      {
        type: 'button',
        'aria-label': t(`Play ${video.title}`, `${video.title} አጫውት`),
        onclick: () => (playable ? play(video) : unavailable(video)),
      },
      [
        el('span.room__placeholder', null, [
          icon(playable ? 'play' : 'file', { size: 28 }),
          el('span', null, video.durationLabel || ''),
        ]),
      ],
    )

    return el('div.card.stack-sm', null, [
      thumb,
      el('h2.doc-card__name', null, t(video.title, video.titleAm || video.title)),
      el('p.text-sm.text-muted', null, video.description || ''),
      el('div.doc-card__meta', null, [
        video.category ? el('span.pill.pill--muted', null, video.category) : null,
        el('span', null, formatDate(video.createdAt)),
      ]),
    ])
  }

  function play(video) {
    return modal({
      title: t(video.title, video.titleAm || video.title),
      body: () =>
        el('div.video-embed', null, [
          video.embedUrl
            ? el('iframe', {
                src: video.embedUrl,
                title: video.title,
                allow: 'accelerometer; autoplay; encrypted-media; picture-in-picture; fullscreen',
                referrerpolicy: 'strict-origin-when-cross-origin',
                loading: 'lazy',
              })
            : el('video', { src: video.videoUrl, controls: true, playsinline: true, preload: 'metadata' }),
        ]),
      actions: (close) => [el('button.ds-btn.ds-btn-quiet', { type: 'button', onclick: () => close(null) }, t('Close', 'ዝጋ'))],
    })
  }

  function unavailable(video) {
    return modal({
      title: t(video.title, video.titleAm || video.title),
      description: t(
        'This video has no public source in the static build. The written guidance covers the same technique.',
        'ይህ ቪዲዮ በዚህ ስሪት ውስጥ ይፋዊ ምንጭ የለውም። የተጻፈው መመሪያ ተመሳሳዩን ዘዴ ይሸፍናል።',
      ),
      actions: (close) => [
        link('/health-feed', { class: 'ds-btn ds-btn-primary', onclick: () => close(null) }, t('Read instead', 'በምትኩ ያንብቡ')),
        el('button.ds-btn.ds-btn-quiet', { type: 'button', onclick: () => close(null) }, t('Close', 'ዝጋ')),
      ],
    })
  }

  try {
    videos = (await all('videos')).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))
    buildChips()
    apply()
  } catch (err) {
    console.error('[videos] load failed', err)
    grid.replaceChildren(empty(t('Could not load the video library.', 'የቪዲዮ ቤተ-መጻሕፍቱን መጫን አልተቻለም።'), 'alert'))
  }

  return root
}
