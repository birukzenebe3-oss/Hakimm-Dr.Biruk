/**
 * Live consultation room.
 *
 * This is the view the original `src/lib/webrtc.ts` never finished: it built an
 * `RTCPeerConnection`, produced an offer, and then left a comment saying the
 * offer should be sent to a signalling server that did not exist. Real calls
 * fell back to an embedded Jitsi iframe.
 *
 * Here the offer actually goes somewhere. PeerJS Cloud brokers the SDP and ICE
 * exchange; the media itself flows browser to browser. Roles are claimed by
 * convention rather than assigned: the first participant to reach the room
 * takes the `a` peer id, and whoever finds it taken becomes `b` and dials `a`.
 * That is what removes the need for a server to decide who is the caller.
 *
 * Jitsi remains as the fallback for peers behind symmetric NATs, where no
 * direct path forms and a TURN relay — which would need infrastructure we do
 * not run — is the only option.
 */

import { get } from '../store.js'
import { t } from '../i18n.js'
import { el, icon, toast } from '../ui.js'
import { actorName } from '../auth.js'
import { link, navigate, onRouteChange } from '../router.js'
import { createSession, getLocalMedia, jitsiEmbed, peerIdFor, stopStream, toggleTrack } from '../rtc.js'

export async function render({ params, search }) {
  const roomId = params.id
  const wantsVideo = (search.get('mode') || 'video') !== 'audio'

  // The room may have been reached from an appointment id rather than a
  // derived room id; either resolves to a stable string, which is all PeerJS
  // needs. Looking the appointment up only affects what we show in the header.
  const appointment = await get('appointments', roomId).catch(() => null)

  let session = null
  let localStream = null
  let remoteStream = null
  let disposed = false

  const remoteVideo = el('video', { autoplay: true, playsinline: true })
  const selfVideo = el('video', { autoplay: true, playsinline: true, muted: true })

  const placeholder = el('div.room__placeholder', null, [
    el('div.skeleton', { style: { width: '3rem', height: '3rem', borderRadius: '999px' } }),
    el('p', null, t('Setting up the connection…', 'ግንኙነቱ እየተዘጋጀ ነው…')),
  ])

  const stage = el('div.room__stage', null, [remoteVideo, placeholder, el('div.room__self', null, selfVideo)])
  const status = el('p.text-sm.text-muted.center')
  const sidebar = el('div.stack')

  const micButton = controlButton('mic', t('Mute microphone', 'ማይክ ዝጋ'), () => {
    const on = toggleTrack(localStream, 'audio')
    micButton.classList.toggle('is-off', !on)
    micButton.replaceChildren(icon(on ? 'mic' : 'micOff', { size: 20 }))
  })

  const camButton = controlButton('video', t('Turn camera off', 'ካሜራ አጥፋ'), () => {
    const on = toggleTrack(localStream, 'video')
    camButton.classList.toggle('is-off', !on)
    camButton.replaceChildren(icon(on ? 'video' : 'videoOff', { size: 20 }))
  })

  const endButton = el(
    'button.room-btn.room-btn--end',
    { type: 'button', 'aria-label': t('End call', 'ጥሪ ጨርስ'), onclick: leave },
    icon('phoneOff', { size: 20 }),
  )

  const bar = el('div.room__bar', null, [micButton, wantsVideo ? camButton : null, endButton])

  const root = el('div.container.section.stack', null, [
    el('div.row-wrap', null, [
      link('/appointments', { class: 'action-icon', 'aria-label': t('Back', 'ተመለስ') }, icon('arrowLeft', { size: 16 })),
      el('div', null, [
        el('h1.section-title', null, appointment?.doctorName || t('Consultation room', 'የምክክር ክፍል')),
        el('p.text-xs.text-muted.mono', null, roomId),
      ]),
    ]),

    el('div.room', null, [el('div', null, [stage, bar]), sidebar]),
    status,
  ])

  function controlButton(iconName, label, onclick) {
    return el('button.room-btn', { type: 'button', 'aria-label': label, onclick }, icon(iconName, { size: 20 }))
  }

  function setStatus(message) {
    status.textContent = message
  }

  function showRemote(stream) {
    remoteStream = stream
    remoteVideo.srcObject = stream
    placeholder.remove()
    setStatus(t('Connected.', 'ተገናኝቷል።'))
  }

  /* ---------- teardown ---------- */

  function dispose() {
    if (disposed) return
    disposed = true
    session?.destroy()
    stopStream(localStream)
    remoteVideo.srcObject = null
    selfVideo.srcObject = null
  }

  function leave() {
    dispose()
    navigate('/appointments')
  }

  // Navigating away must stop the camera. Without this the indicator light
  // stays on after the user has moved to another page — the single most
  // alarming bug a telehealth app can ship.
  const unsubscribe = onRouteChange(() => {
    dispose()
    unsubscribe()
  })
  window.addEventListener('pagehide', dispose, { once: true })

  /* ---------- fallback ---------- */

  function offerJitsi(reason) {
    sidebar.replaceChildren(
      el('div.card.stack-sm', null, [
        el('div.row', null, [icon('alert', { size: 16 }), el('strong.text-sm', null, t('Direct call unavailable', 'ቀጥታ ጥሪ አልተቻለም'))]),
        el('p.text-sm.text-muted', null, reason),
        el(
          'button.ds-btn.ds-btn-primary.ds-btn--block',
          {
            type: 'button',
            onclick: () => {
              dispose()
              const frame = jitsiEmbed(roomId, actorName())
              stage.replaceChildren(frame)
              bar.remove()
              setStatus(t('Using the hosted fallback room.', 'የተስተናጋጅ ክፍልን በመጠቀም ላይ።'))
            },
          },
          t('Switch to hosted room', 'ወደ ተስተናጋጅ ክፍል ቀይር'),
        ),
      ]),
    )
  }

  /* ---------- connect ---------- */

  /** Attach handlers to whichever session object is current. */
  function wire() {
    session.on('stream', showRemote)

    session.on('call', (incoming) => {
      session.answer(incoming, localStream)
      setStatus(t('Answering…', 'በመመለስ ላይ…'))
    })

    session.on('close', ({ reason }) => {
      if (disposed || reason !== 'peer-hung-up') return
      setStatus(t('The other participant left the call.', 'ሌላኛው ተሳታፊ ጥሪውን ለቋል።'))
      placeholder.replaceChildren(el('p', null, t('Call ended', 'ጥሪው ተጠናቋል')))
      stage.append(placeholder)
    })

    session.on('error', (err) => {
      // `unavailable-id` is the role handshake working as designed, not a
      // failure — the caller path handles it.
      if (err?.type === 'unavailable-id') return
      console.error('[room] peer error', err)
      if (!remoteStream) offerJitsi(err.message || t('The connection failed.', 'ግንኙነቱ አልተሳካም።'))
    })
  }

  try {
    localStream = await getLocalMedia({ video: wantsVideo, audio: true })
    selfVideo.srcObject = localStream
    if (!wantsVideo) selfVideo.closest('.room__self')?.remove()
  } catch (err) {
    setStatus(err.message)
    offerJitsi(t(
      'The browser would not give this page a camera or microphone.',
      'አሳሹ ለዚህ ገጽ ካሜራ ወይም ማይክሮፎን አልፈቀደም።',
    ))
    return root
  }

  setStatus(t('Waiting for the other participant…', 'ሌላውን ተሳታፊ በመጠበቅ ላይ…'))

  try {
    // Claim the first role. `createSession` resolves as soon as the peer object
    // exists; whether the id was actually granted is only known once `ready`
    // settles, so the `unavailable-id` rejection is caught there. That
    // rejection is the signal that someone is already in the room, and we
    // become the caller instead of the callee.
    let role = 'a'
    session = await createSession(peerIdFor(roomId, 'a'))
    wire()

    try {
      await session.ready
    } catch (err) {
      if (err?.type !== 'unavailable-id') throw err
      session.destroy()
      role = 'b'
      session = await createSession(peerIdFor(roomId, 'b'))
      wire()
      await session.ready
    }

    if (disposed) return root

    if (role === 'b') {
      setStatus(t('Calling…', 'በመደወል ላይ…'))
      await session.call(peerIdFor(roomId, 'a'), localStream)
    } else {
      sidebar.replaceChildren(
        el('div.card.stack-sm', null, [
          el('div.row', null, [icon('link', { size: 16 }), el('strong.text-sm', null, t('Invite the other side', 'ሌላኛውን ወገን ይጋብዙ'))]),
          el('p.text-sm.text-muted', null, t(
            'Send them this page link. The call starts as soon as they open it.',
            'የዚህን ገጽ ማገናኛ ይላኩላቸው። እንደከፈቱት ወዲያውኑ ጥሪው ይጀምራል።',
          )),
          el(
            'button.ds-btn.ds-btn-quiet.ds-btn--block',
            {
              type: 'button',
              onclick: async () => {
                const url = location.href
                if (navigator.share) {
                  try {
                    await navigator.share({ title: 'Hakimm consultation', url })
                    return
                  } catch {
                    /* dismissed */
                  }
                }
                await navigator.clipboard?.writeText(url)
                toast(t('Link copied', 'ማገናኛው ተቀድቷል'), 'success')
              },
            },
            t('Share room link', 'የክፍል ማገናኛ አጋራ'),
          ),
        ]),
      )
    }

    // If nothing has connected after 30 seconds the direct path is not going
    // to form on its own; surface the fallback rather than spinning forever.
    setTimeout(() => {
      if (!disposed && !remoteStream) {
        offerJitsi(t(
          'No direct connection formed. This usually means one of the networks blocks peer-to-peer traffic.',
          'ቀጥታ ግንኙነት አልተፈጠረም። ብዙውን ጊዜ አንዱ አውታረ መረብ ቀጥታ ግንኙነትን ስለሚከለክል ነው።',
        ))
      }
    }, 30000)
  } catch (err) {
    console.error('[room] session failed', err)
    setStatus(err.message)
    offerJitsi(err.message)
  }

  return root
}
