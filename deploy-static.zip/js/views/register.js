/**
 * Create account.
 *
 * Replaces `src/routes/register.tsx` and the `patients` blob-store writes
 * behind it. The password is stretched with PBKDF2-SHA-256 through the Web
 * Crypto API before anything is written — Node's `crypto` module is not
 * available in a browser and is not needed.
 */

import { t } from '../i18n.js'
import { el, field, icon, toast } from '../ui.js'
import { isSignedIn, register } from '../auth.js'
import { link, navigate } from '../router.js'

export async function render({ search }) {
  const next = search.get('next') || '/profile'

  if (isSignedIn()) {
    navigate(next)
    return el('div')
  }

  const nameInput = el('input.input', { type: 'text', required: true, autocomplete: 'name' })
  const emailInput = el('input.input', {
    type: 'email',
    required: true,
    autocomplete: 'email',
    autocapitalize: 'off',
    spellcheck: false,
  })
  const phoneInput = el('input.input', { type: 'tel', autocomplete: 'tel', placeholder: '+251…' })
  const passwordInput = el('input.input', { type: 'password', required: true, autocomplete: 'new-password', minlength: '8' })
  const confirmInput = el('input.input', { type: 'password', required: true, autocomplete: 'new-password' })
  const error = el('div')

  const form = el(
    'form.card.stack',
    {
      novalidate: true,
      onsubmit: async (event) => {
        event.preventDefault()
        const button = form.querySelector('button[type=submit]')
        error.replaceChildren()

        if (passwordInput.value !== confirmInput.value) {
          error.replaceChildren(
            el('div.notice.notice--danger', null, [
              icon('alert', { size: 16 }),
              el('span', null, t('The two passwords do not match.', 'ሁለቱ የይለፍ ቃላት አይመሳሰሉም።')),
            ]),
          )
          confirmInput.focus()
          return
        }

        button.disabled = true

        try {
          await register({
            name: nameInput.value,
            email: emailInput.value,
            password: passwordInput.value,
            phone: phoneInput.value,
          })
          toast(t('Account created', 'መለያ ተፈጥሯል'), 'success')
          navigate(next)
        } catch (err) {
          error.replaceChildren(
            el('div.notice.notice--danger', null, [icon('alert', { size: 16 }), el('span', null, err.message || String(err))]),
          )
          button.disabled = false
        }
      },
    },
    [
      field({ label: t('Full name', 'ሙሉ ስም'), input: nameInput }),
      field({ label: t('Email', 'ኢሜይል'), input: emailInput }),
      field({
        label: t('Phone (optional)', 'ስልክ (አማራጭ)'),
        hint: t('Used only to prefill your booking forms.', 'የቀጠሮ ቅጾችዎን አስቀድሞ ለመሙላት ብቻ ይጠቅማል።'),
        input: phoneInput,
      }),
      field({
        label: t('Password', 'የይለፍ ቃል'),
        hint: t('At least 8 characters.', 'ቢያንስ 8 ቁምፊዎች።'),
        input: passwordInput,
      }),
      field({ label: t('Confirm password', 'የይለፍ ቃል ያረጋግጡ'), input: confirmInput }),
      error,
      el('div.form-actions', null, [
        el('button.ds-btn.ds-btn-primary.ds-btn--block', { type: 'submit' }, t('Create account', 'መለያ ፍጠር')),
      ]),
    ],
  )

  return el('div.container.container-narrow.section.stack', null, [
    el('div.stack-sm', null, [
      el('h1.page-title', null, t('Create your account', 'መለያዎን ይፍጠሩ')),
      el('p.page-lede', null, t(
        'It takes a moment and keeps your bookings, messages and notes in one place.',
        'ጥቂት ጊዜ ብቻ ይወስዳል፤ ቀጠሮዎችዎን፣ መልእክቶችዎን እና ማስታወሻዎችዎን በአንድ ቦታ ያስቀምጣል።',
      )),
    ]),

    form,

    el('div.notice', null, [
      icon('shield', { size: 16 }),
      el('span', null, t(
        'Everything you enter stays in this browser. It is never sent anywhere, which also means nobody can recover it for you — keep a note of your password.',
        'የሚያስገቡት ሁሉ በዚህ አሳሽ ውስጥ ይቆያል። ወደ ማንም አይላክም፤ ይህ ማለት ደግሞ ማንም ሊመልስልዎ አይችልም — የይለፍ ቃልዎን ይያዙ።',
      )),
    ]),

    el('p.center.text-sm', null, [
      el('span', null, t('Already registered? ', 'አስቀድመው ተመዝግበዋል? ')),
      link(`/login?next=${encodeURIComponent(next)}`, null, t('Sign in', 'ይግቡ')),
    ]),

    el('p.center.text-xs.text-muted', null, [
      el('span', null, t('By continuing you accept the ', 'በመቀጠል ')),
      link('/terms', null, t('terms of service', 'የአገልግሎት ውሎችን')),
      el('span', null, t(' and ', ' እና ')),
      link('/privacy', null, t('privacy policy', 'የግላዊነት መመሪያን')),
      el('span', null, t('.', ' ይቀበላሉ።')),
    ]),
  ])
}
