/**
 * Doctor profile.
 *
 * Replaces `src/routes/doctor.$doctorId.tsx`. The React version issued three
 * server calls on mount — profile, reviews, availability. All three now read
 * from IndexedDB, so the page renders in one frame with no loading cascade.
 */

import { get, query } from '../store.js'
import { formatRelative, t } from '../i18n.js'
import { avatar, el, empty, icon, pill } from '../ui.js'
import { link } from '../router.js'
import { doctorName, doctorSpecialty, presencePill } from './_shared.js'

export async function render({ params }) {
  const doctor = await get('doctors', params.id)

  if (!doctor) {
    return el('div.container.section', null, [
      empty(t('That profile is no longer listed.', 'ይህ መገለጫ አልተገኘም።'), 'user'),
      el('div.center', null, link('/doctors', { class: 'ds-btn ds-btn-quiet' }, t('Back to directory', 'ወደ ዝርዝሩ ተመለስ'))),
    ])
  }

  const reviews = await query('reviews', (row) => row.doctorId === doctor.id)

  return el('div.container.section.stack-lg', null, [
    el('div.card.stack', null, [
      el('div.doc-card__top', null, [
        avatar(doctor, { size: 'lg', online: Boolean(doctor.isOnline) }),
        el('div', null, [
          el('h1.page-title', null, doctorName(doctor)),
          el('p.doc-card__spec', null, doctorSpecialty(doctor)),
          el('div.row-wrap.mt-1', null, [
            presencePill(doctor.isOnline),
            pill(`★ ${doctor.rating ?? '—'} (${doctor.reviewCount ?? reviews.length})`),
            doctor.yearsOfExperience
              ? pill(t(`${doctor.yearsOfExperience} years experience`, `${doctor.yearsOfExperience} ዓመት ልምድ`), 'muted')
              : null,
          ]),
        ]),
      ]),

      el('p.text-sm', null, t(doctor.bio || '', doctor.bioAm || doctor.bio || '')),

      doctor.languages?.length
        ? el('div.row-wrap', null, [
            el('span.text-xs.text-muted', null, t('Speaks', 'ቋንቋዎች')),
            ...doctor.languages.map((language) => pill(language, 'muted')),
          ])
        : null,

      el('div.stat-row', null, [
        el('div.stat', null, [
          el('div.stat__value', null, doctor.consultationFee ? `${doctor.consultationFee} ETB` : '—'),
          el('div.stat__label', null, t('Consultation fee', 'የምክክር ክፍያ')),
        ]),
        el('div.stat', null, [
          el('div.stat__value', null, doctor.acceptsVideo ? t('Yes', 'አዎ') : t('No', 'የለም')),
          el('div.stat__label', null, t('Video consultations', 'የቪዲዮ ምክክር')),
        ]),
        el('div.stat', null, [
          el('div.stat__value', null, String(doctor.reviewCount ?? reviews.length)),
          el('div.stat__label', null, t('Consultations', 'ምክክሮች')),
        ]),
      ]),

      el('div.form-actions', null, [
        link(`/booking?doctor=${encodeURIComponent(doctor.id)}`, { class: 'ds-btn ds-btn-primary' }, [
          icon('calendar', { size: 16 }),
          el('span', null, t('Book a consultation', 'ቀጠሮ ይያዙ')),
        ]),
        link(`/messaging?doctor=${encodeURIComponent(doctor.id)}`, { class: 'ds-btn ds-btn-quiet' }, [
          icon('message', { size: 16 }),
          el('span', null, t('Send a message', 'መልዕክት ላክ')),
        ]),
        doctor.acceptsVideo
          ? link(`/consultation?doctor=${encodeURIComponent(doctor.id)}`, { class: 'ds-btn ds-btn-quiet' }, [
              icon('video', { size: 16 }),
              el('span', null, t('Start a call', 'ጥሪ ጀምር')),
            ])
          : null,
      ]),
    ]),

    el('section.stack', null, [
      el('h2.section-title', null, t('Patient reviews', 'የታካሚ አስተያየቶች')),
      reviews.length
        ? el(
            'div.stack-sm',
            null,
            reviews
              .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))
              .map((review) =>
                el('div.card.stack-sm', null, [
                  el('div.row', null, [
                    el('strong.text-sm', null, review.authorName || t('Patient', 'ታካሚ')),
                    el('span.spacer'),
                    el('span.text-xs.text-muted', null, formatRelative(review.createdAt)),
                  ]),
                  el('div.text-xs', null, '★'.repeat(Math.max(1, Math.min(5, review.rating || 5)))),
                  el('p.text-sm', null, review.comment || ''),
                ]),
              ),
          )
        : empty(
            t('No reviews yet — be the first after your consultation.', 'እስካሁን አስተያየት የለም — ከምክክርዎ በኋላ የመጀመሪያው ይሁኑ።'),
            'star',
          ),
    ]),
  ])
}
