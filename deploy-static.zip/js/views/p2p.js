/**
 * MedCoin P2P marketplace.
 *
 * Replaces `src/routes/p2p.tsx` and the `medcoin-p2p` blob store. The original
 * was a shared order book: every browser posted into one store and read every
 * other trader's open orders back out.
 *
 * A static bundle has no shared store, and pretending otherwise would show an
 * empty market that never fills. So the model changes rather than the promise:
 * an order is composed here, encoded into the link, and sent to a counterparty
 * over whatever channel the two already use — Telegram, SMS, a QR photo. Opening
 * that link renders the order on the other side, where it can be accepted and
 * saved. The offer travels in the URL; nothing is stored on anyone's server.
 *
 * Settlement is off-platform, exactly as it was before: the two parties agree,
 * transfer birr directly, and the clinic credits the ledger.
 */

import { all, newId, patch, put, remove } from '../store.js'
import { formatDate, formatRelative, t } from '../i18n.js'
import { copyText, el, empty, field, icon, modal, pill, toast } from '../ui.js'
import { actorId, actorName } from '../auth.js'
import { link } from '../router.js'
import { telegramLink } from '../brand.js'
import { pageHead, sectionHead } from './_shared.js'

/* ---------- link encoding ----------
 * `btoa` is byte-oriented, so Amharic notes have to go through UTF-8 first.
 * The `+/=` alphabet is swapped for the URL-safe one so the order survives
 * being pasted into a chat window unescaped.
 */

function encodeOffer(order) {
  const json = JSON.stringify(order)
  const bytes = new TextEncoder().encode(json)
  let binary = ''
  for (const byte of bytes) binary += String.fromCharCode(byte)
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}

function decodeOffer(token) {
  try {
    const base64 = token.replace(/-/g, '+').replace(/_/g, '/')
    const binary = atob(base64.padEnd(Math.ceil(base64.length / 4) * 4, '='))
    const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0))
    const parsed = JSON.parse(new TextDecoder().decode(bytes))

    // The token arrives from outside, so treat it as a claim to be checked
    // rather than a record to be trusted.
    if (!parsed || typeof parsed !== 'object') return null
    if (parsed.side !== 'buy' && parsed.side !== 'sell') return null
    if (!Number.isFinite(Number(parsed.amount)) || !Number.isFinite(Number(parsed.price))) return null

    return {
      id: String(parsed.id || newId()),
      side: parsed.side,
      amount: Math.abs(Number(parsed.amount)),
      price: Math.abs(Number(parsed.price)),
      note: String(parsed.note || '').slice(0, 240),
      contact: String(parsed.contact || '').slice(0, 120),
      trader: String(parsed.trader || '').slice(0, 80),
      createdAt: String(parsed.createdAt || ''),
    }
  } catch {
    return null
  }
}

/**
 * Only the fields the counterparty needs travel in the link. `ownerId` and
 * `status` are local bookkeeping and stay on this device.
 */
function offerUrl(order) {
  const url = new URL(location.href)
  url.search = `?offer=${encodeOffer({
    id: order.id,
    side: order.side,
    amount: order.amount,
    price: order.price,
    note: order.note,
    contact: order.contact,
    trader: order.trader,
    createdAt: order.createdAt,
  })}`
  url.hash = ''
  return url.toString()
}

/* ---------- view ---------- */

export async function render({ search }) {
  const root = el('div')
  const body = el('div.container.stack-lg')
  const incoming = search.get('offer') ? decodeOffer(search.get('offer')) : null

  root.append(
    pageHead(
      t('MedCoin P2P', 'የሜድኮይን P2P'),
      t(
        'Trade MedCoin with another member. Compose an order, share the link, settle in birr directly.',
        'ከሌላ አባል ጋር ሜድኮይን ይለውጡ። ትዕዛዝ ይፍጠሩ፣ ማገናኛውን ያጋሩ፣ በብር በቀጥታ ይጠናቀቁ።',
      ),
    ),
    body,
  )

  async function draw() {
    const me = actorId()
    const orders = (await all('p2p-orders'))
      .filter((order) => order.ownerId === me)
      .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))

    const open = orders.filter((order) => order.status !== 'closed')
    const closed = orders.filter((order) => order.status === 'closed')

    body.replaceChildren(
      incoming ? incomingCard(incoming) : null,

      el('div.form-actions', null, [
        el('button.ds-btn.ds-btn-primary', { type: 'button', onclick: () => compose('sell') }, [
          icon('upload', { size: 16 }),
          el('span', null, t('Sell MedCoin', 'ሜድኮይን ሽጥ')),
        ]),
        el('button.ds-btn.ds-btn-quiet', { type: 'button', onclick: () => compose('buy') }, [
          icon('download', { size: 16 }),
          el('span', null, t('Buy MedCoin', 'ሜድኮይን ግዛ')),
        ]),
        link('/wallet', { class: 'ds-btn ds-btn-quiet' }, t('My balance', 'ሂሳቤ')),
      ]),

      el('div.notice', null, [
        icon('info', { size: 16 }),
        el('span', null, t(
          'There is no shared order book. Orders live on your device until you send the link — anyone who opens it sees the order and can reply to you directly.',
          'የጋራ የትዕዛዝ መዝገብ የለም። ትዕዛዞች ማገናኛውን እስኪልኩ ድረስ በመሣሪያዎ ላይ ይቆያሉ — የከፈተው ሰው ትዕዛዙን አይቶ በቀጥታ ሊመልስልዎ ይችላል።',
        )),
      ]),

      el('section.stack', null, [
        sectionHead(t('My open orders', 'ክፍት ትዕዛዞቼ')),
        open.length
          ? el('div.stack-sm', null, open.map(orderCard))
          : empty(t('No open orders. Compose one above.', 'ክፍት ትዕዛዝ የለም። ከላይ ይፍጠሩ።'), 'coins'),
      ]),

      closed.length
        ? el('section.stack', null, [
            sectionHead(t('Settled', 'የተጠናቀቁ')),
            el('div.stack-sm', null, closed.map(orderCard)),
          ])
        : null,

      el('div.notice.notice--warn', null, [
        icon('shield', { size: 16 }),
        el('span', null, t(
          'Trade with people you can hold to it. Hakimm.com does not hold funds, does not escrow, and cannot reverse a transfer between two members.',
          'ሊያምኗቸው ከሚችሉ ሰዎች ጋር ብቻ ይገበያዩ። ሓኪም ዶት ኮም ገንዘብ አይይዝም፣ ዋስትና አይሰጥም፣ በአባላት መካከል የተደረገ ዝውውርንም መመለስ አይችልም።',
        )),
      ]),
    )
  }

  /* ---------- an order that arrived by link ---------- */

  function incomingCard(order) {
    // The link author's side is stated from their point of view; the reader is
    // on the other side of it, and saying so avoids an expensive misreading.
    const yourSide = order.side === 'sell' ? t('You would buy', 'እርስዎ ይገዛሉ') : t('You would sell', 'እርስዎ ይሸጣሉ')

    return el('div.card.stack.d3-tile', null, [
      el('div.row-wrap', null, [
        pill(t('Shared order', 'የተጋራ ትዕዛዝ'), 'warn'),
        order.trader ? el('span.text-sm.text-muted', null, order.trader) : null,
      ]),

      el('h2.section-title', null, `${yourSide} ${order.amount.toLocaleString()} MedCoin`),

      el('div.stat-row', null, [
        el('div.stat', null, [
          el('div.stat__value', null, order.price.toLocaleString()),
          el('div.stat__label', null, t('Birr per coin', 'ብር በአንድ ኮይን')),
        ]),
        el('div.stat', null, [
          el('div.stat__value', null, (order.amount * order.price).toLocaleString()),
          el('div.stat__label', null, t('Total birr', 'ጠቅላላ ብር')),
        ]),
      ]),

      order.note ? el('p.text-sm', null, order.note) : null,
      order.contact ? el('p.text-sm.text-muted', null, t(`Contact: ${order.contact}`, `አድራሻ: ${order.contact}`)) : null,

      el('div.form-actions', null, [
        el(
          'button.ds-btn.ds-btn-primary',
          {
            type: 'button',
            onclick: async () => {
              await put('p2p-orders', {
                ...order,
                id: newId(),
                ownerId: actorId(),
                status: 'accepted',
                receivedFrom: order.trader || '',
              })
              toast(t('Saved to your orders', 'ወደ ትዕዛዞችዎ ተቀምጧል'), 'success')
              draw()
            },
          },
          t('Save this order', 'ይህን ትዕዛዝ አስቀምጥ'),
        ),
        el(
          'a.ds-btn.ds-btn-quiet',
          {
            href: telegramLink(
              `MedCoin P2P: ${order.side === 'sell' ? 'buying' : 'selling'} ${order.amount} @ ${order.price} ETB`,
            ),
            target: '_blank',
            rel: 'noopener noreferrer',
          },
          [icon('send', { size: 16 }), el('span', null, t('Reply on Telegram', 'በቴሌግራም መልስ'))],
        ),
      ]),
    ])
  }

  /* ---------- own orders ---------- */

  function orderCard(order) {
    const isSell = order.side === 'sell'

    return el('article.card.stack-sm', null, [
      el('div.row-wrap', null, [
        pill(isSell ? t('Selling', 'ሽያጭ') : t('Buying', 'ግዢ'), isSell ? 'success' : 'muted'),
        order.status === 'closed' ? pill(t('Settled', 'ተጠናቋል'), 'muted') : null,
        order.status === 'accepted' ? pill(t('Accepted', 'ተቀባይነት አግኝቷል'), 'success') : null,
        el('span.spacer'),
        el('span.text-xs.text-muted', null, formatRelative(order.createdAt)),
      ]),

      el('div.doc-card__name', null, `${Number(order.amount).toLocaleString()} MedCoin · ${Number(order.price).toLocaleString()} ETB`),
      el('div.text-sm.text-muted', null, t(
        `Total ${(Number(order.amount) * Number(order.price)).toLocaleString()} ETB · ${formatDate(order.createdAt)}`,
        `ጠቅላላ ${(Number(order.amount) * Number(order.price)).toLocaleString()} ብር · ${formatDate(order.createdAt)}`,
      )),
      order.note ? el('p.text-sm', null, order.note) : null,

      el('div.form-actions', null, [
        el(
          'button.ds-btn.ds-btn-quiet',
          { type: 'button', onclick: () => copyText(offerUrl(order), t('Order link copied', 'የትዕዛዝ ማገናኛ ተቀድቷል')) },
          [icon('link', { size: 16 }), el('span', null, t('Copy link', 'ማገናኛ ቅዳ'))],
        ),
        el(
          'a.ds-btn.ds-btn-quiet',
          {
            href: telegramLink(offerUrl(order)),
            target: '_blank',
            rel: 'noopener noreferrer',
          },
          [icon('send', { size: 16 }), el('span', null, t('Share', 'አጋራ'))],
        ),
        order.status !== 'closed'
          ? el(
              'button.ds-btn.ds-btn-quiet',
              {
                type: 'button',
                onclick: async () => {
                  await patch('p2p-orders', order.id, { status: 'closed' })
                  toast(t('Marked as settled', 'እንደተጠናቀቀ ተመዝግቧል'), 'success')
                  draw()
                },
              },
              [icon('check', { size: 16 }), el('span', null, t('Mark settled', 'ተጠናቋል ብለህ ምልክት አድርግ'))],
            )
          : null,
        el(
          'button.action-icon',
          {
            type: 'button',
            'aria-label': t('Delete order', 'ትዕዛዝ ሰርዝ'),
            onclick: async () => {
              const confirmed = await modal({
                title: t('Delete this order?', 'ይህ ትዕዛዝ ይሰረዝ?'),
                description: t(
                  'Links you have already shared will still open. Deleting only removes it from this device.',
                  'አስቀድመው ያጋሩዋቸው ማገናኛዎች አሁንም ይሰራሉ። መሰረዝ ከዚህ መሣሪያ ላይ ብቻ ያስወግደዋል።',
                ),
                actions: (close) => [
                  el('button.ds-btn.ds-btn-quiet', { type: 'button', onclick: () => close(false) }, t('Keep', 'ተወው')),
                  el('button.ds-btn.ds-btn-primary', { type: 'button', onclick: () => close(true) }, t('Delete', 'ሰርዝ')),
                ],
              })
              if (!confirmed) return
              await remove('p2p-orders', order.id)
              draw()
            },
          },
          icon('close', { size: 16 }),
        ),
      ]),
    ])
  }

  /* ---------- compose ---------- */

  async function compose(side) {
    const amountInput = el('input.input', { type: 'number', min: '1', step: '1', inputmode: 'numeric' })
    const priceInput = el('input.input', { type: 'number', min: '0.1', step: '0.1', value: '1', inputmode: 'decimal' })
    const contactInput = el('input.input', { type: 'text', placeholder: '@telegram / +251…', value: '' })
    const noteInput = el('input.input', {
      type: 'text',
      placeholder: t('e.g. Telebirr only, evenings', 'ለምሳሌ ቴሌብር ብቻ፣ ምሽት ላይ'),
    })

    const confirmed = await modal({
      title: side === 'sell' ? t('Sell MedCoin', 'ሜድኮይን ሽጥ') : t('Buy MedCoin', 'ሜድኮይን ግዛ'),
      description: t(
        'This creates a link you can send. Include a way for the other person to reach you.',
        'ይህ ሊልኩት የሚችሉት ማገናኛ ይፈጥራል። ሌላው ሰው የሚያገኝዎትን መንገድ ያካትቱ።',
      ),
      body: () => el('div', null, [
        field({ label: t('MedCoin amount', 'የሜድኮይን መጠን'), input: amountInput }),
        field({
          label: t('Price per coin (ETB)', 'የአንድ ኮይን ዋጋ (ብር)'),
          input: priceInput,
        }),
        field({ label: t('How to reach you', 'እንዴት ሊያገኙዎት ይችላሉ'), input: contactInput }),
        field({ label: t('Note (optional)', 'ማስታወሻ (አማራጭ)'), input: noteInput }),
      ]),
      actions: (close) => [
        el('button.ds-btn.ds-btn-quiet', { type: 'button', onclick: () => close(false) }, t('Cancel', 'ተወው')),
        el('button.ds-btn.ds-btn-primary', { type: 'button', onclick: () => close(true) }, t('Create link', 'ማገናኛ ፍጠር')),
      ],
    })

    if (!confirmed) return

    const amount = Math.abs(Math.round(Number(amountInput.value)))
    const price = Math.abs(Number(priceInput.value))

    if (!amount || !Number.isFinite(price) || price <= 0) {
      toast(t('Enter an amount and a price greater than zero.', 'ከዜሮ በላይ መጠን እና ዋጋ ያስገቡ።'), 'error')
      return
    }

    const order = {
      id: newId(),
      ownerId: actorId(),
      side,
      amount,
      price,
      contact: contactInput.value.trim(),
      note: noteInput.value.trim(),
      trader: actorName(),
      status: 'open',
    }

    const saved = await put('p2p-orders', order)
    await draw()
    shareSheet(saved)
  }

  /** Shown once, immediately after creating an order — the link is the point. */
  function shareSheet(order) {
    const url = offerUrl(order)

    return modal({
      title: t('Send this to your counterparty', 'ይህን ለተጋባዡ ይላኩ'),
      description: t(
        'Anyone who opens the link sees the order and your contact detail. Send it only to people you mean to trade with.',
        'ማገናኛውን የከፈተ ማንኛውም ሰው ትዕዛዙን እና የእርስዎን አድራሻ ያያል። ሊገበያዩ ላሰቡት ሰው ብቻ ይላኩ።',
      ),
      body: () => el('div.stack-sm', null, [el('p.mono.text-xs', null, url)]),
      actions: (close) => [
        el(
          'button.ds-btn.ds-btn-quiet',
          { type: 'button', onclick: () => copyText(url, t('Order link copied', 'የትዕዛዝ ማገናኛ ተቀድቷል')) },
          t('Copy link', 'ማገናኛ ቅዳ'),
        ),
        el(
          'a.ds-btn.ds-btn-primary',
          { href: telegramLink(url), target: '_blank', rel: 'noopener noreferrer', onclick: () => close(null) },
          t('Send on Telegram', 'በቴሌግራም ላክ'),
        ),
        el('button.ds-btn.ds-btn-quiet', { type: 'button', onclick: () => close(null) }, t('Done', 'ተጠናቋል')),
      ],
    })
  }

  await draw()
  return root
}
