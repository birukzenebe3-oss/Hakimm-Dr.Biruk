/**
 * Professional application.
 *
 * Replaces `src/routes/apply-doctor.tsx`, which posted the form — including a
 * base64 licence scan and a chosen password — to a server function that wrote a
 * pending record into the `doctors` blob store for an administrator to review.
 *
 * None of that survives a static build: there is no store to write to and no
 * reviewer to notify. Writing a medical licence into a browser database that
 * only the applicant can read would be worse than useless — it would look like
 * a submission while going nowhere.
 *
 * So the form does what it can honestly do. It collects the same details,
 * formats them into a message, and hands the applicant a Telegram or email
 * draft to send, with the licence photo attached by them. The answers are kept
 * in `prefs` as a single draft, so a half-finished form survives a reload and
 * the same text can be resent if the first message goes astray. The password
 * field is gone along with the server that would have hashed it.
 */

import { t } from '../i18n.js'
import { copyText, el, field, icon, toast } from '../ui.js'
import { prefs } from '../store.js'
import { link } from '../router.js'
import { BRAND, telegramLink } from '../brand.js'
import { pageHead } from './_shared.js'

/* The department and field lists are the originals, verbatim — an applicant
 * picking "Obstetrics & Gynecology" lands in the same bucket as before. */

const SPECIALTIES = [
  { value: 'pediatrics', en: 'Pediatrics', am: 'የህፃናት ህክምና' },
  { value: 'internal-medicine', en: 'Internal Medicine', am: 'የውስጥ ህክምና' },
  { value: 'surgery', en: 'Surgery', am: 'ቀዶ ጥገና' },
  { value: 'obstetrics-gynecology', en: 'Obstetrics & Gynecology', am: 'ማህፀን እና ፅንስ' },
  { value: 'dermatology', en: 'Dermatology', am: 'የቆዳ ህክምና' },
  { value: 'cardiology', en: 'Cardiology', am: 'የልብ ህክምና' },
  { value: 'neurology', en: 'Neurology', am: 'የነርቭ ህክምና' },
  { value: 'orthopedics', en: 'Orthopedics', am: 'የአጥንት ህክምና' },
  { value: 'psychiatry', en: 'Psychiatry', am: 'የአእምሮ ህክምና' },
  { value: 'ent', en: 'ENT', am: 'ጆሮ አፍንጫ ጉሮሮ' },
  { value: 'ophthalmology', en: 'Ophthalmology', am: 'የዓይን ህክምና' },
  { value: 'general-practice', en: 'General Practice', am: 'ጠቅላላ ህክምና' },
  { value: 'public-health', en: 'Public Health', am: 'የህዝብ ጤና' },
  { value: 'environmental-health', en: 'Environmental Health', am: 'የአካባቢ ጤና' },
  { value: 'nutrition', en: 'Nutrition / Dietetics', am: 'የአመጋገብ ሳይንስ' },
  { value: 'physiotherapy', en: 'Physiotherapy', am: 'ፊዚዮቴራፒ' },
  { value: 'psychology', en: 'Psychology / Counseling', am: 'ሳይኮሎጂ / ምክር' },
  { value: 'pharmacy', en: 'Pharmacy', am: 'ፋርማሲ' },
  { value: 'nursing', en: 'Nursing', am: 'ነርሲንግ' },
  { value: 'laboratory', en: 'Medical Laboratory', am: 'የላቦራቶሪ ሳይንስ' },
  { value: 'radiology', en: 'Radiology', am: 'ራዲዮሎጂ' },
  { value: 'dental', en: 'Dental / Oral Health', am: 'የጥርስ ህክምና' },
  { value: 'other', en: 'Other', am: 'ሌላ' },
]

const HEALTH_FIELDS = [
  { value: 'doctor', en: 'Doctor / Physician', am: 'ዶክተር / ሀኪም' },
  { value: 'public-health', en: 'Public Health', am: 'የህዝብ ጤና' },
  { value: 'environmental', en: 'Environmental Health', am: 'የአካባቢ ጤና' },
  { value: 'nutritionist', en: 'Nutritionist / Dietitian', am: 'የአመጋገብ ባለሙያ' },
  { value: 'physiotherapy', en: 'Physiotherapy', am: 'ፊዚዮቴራፒ' },
  { value: 'psychology', en: 'Psychology / Counseling', am: 'ሳይኮሎጂ / ምክር' },
  { value: 'pharmacy', en: 'Pharmacy', am: 'ፋርማሲ' },
  { value: 'other', en: 'Other Health Field', am: 'ሌላ የጤና መስክ' },
]

const DRAFT_KEY = 'apply-draft'

/** Options are built per render so a language switch relabels them. */
function options(list, placeholder) {
  return [
    el('option', { value: '' }, placeholder),
    ...list.map((entry) => el('option', { value: entry.value }, t(entry.en, entry.am))),
  ]
}

/** The message goes to a person who reads English, so labels are not localised. */
function labelFor(list, value) {
  return list.find((entry) => entry.value === value)?.en || ''
}

export async function render() {
  const draft = prefs.get(DRAFT_KEY, {}) || {}

  const nameInput = el('input.input', { type: 'text', required: true, autocomplete: 'name', value: draft.name || '' })
  const phoneInput = el('input.input', { type: 'tel', autocomplete: 'tel', placeholder: '+251…', value: draft.phone || '' })
  const emailInput = el('input.input', {
    type: 'email',
    autocomplete: 'email',
    autocapitalize: 'off',
    spellcheck: 'false',
    value: draft.email || '',
  })
  const fieldSelect = el('select.select', null, options(HEALTH_FIELDS, t('Choose a field', 'መስክ ይምረጡ')))
  const specialtySelect = el('select.select', null, options(SPECIALTIES, t('Choose a department', 'ክፍል ይምረጡ')))
  const customSpecialty = el('input.input', {
    type: 'text',
    placeholder: t('Your specialty', 'የእርስዎ ስፔሻሊቲ'),
    value: draft.customSpecialty || '',
  })
  const licenceInput = el('input.input', {
    type: 'text',
    placeholder: t('Licence or registration number', 'የፍቃድ ወይም የምዝገባ ቁጥር'),
    value: draft.licence || '',
  })
  const experienceInput = el('input.input', {
    type: 'text',
    placeholder: t('e.g. 6 years, Ayder Hospital', 'ለምሳሌ 6 ዓመት፣ አይደር ሆስፒታል'),
    value: draft.experience || '',
  })
  const bioInput = el('textarea.input', {
    rows: '4',
    placeholder: t('A short professional summary', 'አጭር የሙያ ማጠቃለያ'),
    value: draft.bio || '',
  })

  fieldSelect.value = draft.healthField || ''
  specialtySelect.value = draft.specialty || ''

  // Shown only when "Other" is picked, as the original form behaved.
  const customRow = field({ label: t('Specify your specialty', 'ስፔሻሊቲዎን ይግለጹ'), input: customSpecialty })
  const syncCustomRow = () => {
    customRow.hidden = specialtySelect.value !== 'other'
  }
  specialtySelect.addEventListener('change', syncCustomRow)
  syncCustomRow()

  const preview = el('div')

  function collect() {
    return {
      name: nameInput.value.trim(),
      phone: phoneInput.value.trim(),
      email: emailInput.value.trim(),
      healthField: fieldSelect.value,
      specialty: specialtySelect.value,
      customSpecialty: customSpecialty.value.trim(),
      licence: licenceInput.value.trim(),
      experience: experienceInput.value.trim(),
      bio: bioInput.value.trim(),
    }
  }

  /** Plain text, so it reads the same in Telegram, in email, or pasted anywhere. */
  function compose(values) {
    const specialty = values.specialty === 'other' ? values.customSpecialty : labelFor(SPECIALTIES, values.specialty)

    return [
      'Hakimm.com — professional application',
      '',
      `Name: ${values.name}`,
      `Phone: ${values.phone || '—'}`,
      `Email: ${values.email || '—'}`,
      `Field: ${labelFor(HEALTH_FIELDS, values.healthField) || '—'}`,
      `Department: ${specialty || '—'}`,
      `Licence no.: ${values.licence || '—'}`,
      `Experience: ${values.experience || '—'}`,
      '',
      values.bio || '(no summary given)',
    ].join('\n')
  }

  const form = el(
    'form.card.stack',
    {
      novalidate: true,
      onsubmit: (event) => {
        event.preventDefault()
        const values = collect()

        if (!values.name) {
          toast(t('Please enter your full name', 'እባክዎ ሙሉ ስም ያስገቡ'), 'error')
          nameInput.focus()
          return
        }
        if (!values.phone && !values.email) {
          toast(t('Add a phone number or an email so we can reply', 'መልስ እንድንሰጥዎ ስልክ ወይም ኢሜይል ያስገቡ'), 'error')
          phoneInput.focus()
          return
        }
        if (!values.specialty) {
          toast(t('Please choose a department', 'እባክዎ ክፍል ይምረጡ'), 'error')
          specialtySelect.focus()
          return
        }

        prefs.set(DRAFT_KEY, values)
        showPreview(compose(values))
      },
    },
    [
      field({ label: t('Full name', 'ሙሉ ስም'), input: nameInput }),
      field({ label: t('Phone', 'ስልክ'), input: phoneInput }),
      field({ label: t('Email', 'ኢሜይል'), input: emailInput }),
      field({ label: t('Health field', 'የጤና መስክ'), input: fieldSelect }),
      field({ label: t('Department', 'ክፍል'), input: specialtySelect }),
      customRow,
      field({
        label: t('Licence number', 'የፍቃድ ቁጥር'),
        hint: t(
          'Attach a photo of the licence to the message you send — nothing is uploaded from this page.',
          'የፍቃድዎን ፎቶ በሚልኩት መልእክት ላይ ያያይዙ — ከዚህ ገጽ ምንም አይላክም።',
        ),
        input: licenceInput,
      }),
      field({ label: t('Experience', 'ልምድ'), input: experienceInput }),
      field({ label: t('About you', 'ስለ እርስዎ'), input: bioInput }),

      el('div.form-actions', null, [
        el(
          'button.ds-btn.ds-btn-primary.ds-btn--block',
          { type: 'submit' },
          t('Prepare my application', 'ማመልከቻዬን አዘጋጅ'),
        ),
      ]),
    ],
  )

  function showPreview(message) {
    preview.replaceChildren(
      el('div.card.stack', null, [
        el('h2.section-title', null, t('Ready to send', 'ለመላክ ዝግጁ')),
        el('p.text-sm.text-muted', null, t(
          'This is the whole message. Attach your licence photo in the chat or email before you send it.',
          'መልእክቱ ይህ ብቻ ነው። ከመላክዎ በፊት የፍቃድዎን ፎቶ በውይይቱ ወይም በኢሜይሉ ላይ ያያይዙ።',
        )),

        el('pre.mono.text-xs', { style: { whiteSpace: 'pre-wrap', margin: '0' } }, message),

        el('div.form-actions', null, [
          el(
            'a.ds-btn.ds-btn-primary',
            { href: telegramLink(message), target: '_blank', rel: 'noopener noreferrer' },
            [icon('send', { size: 16 }), el('span', null, t('Send on Telegram', 'በቴሌግራም ላክ'))],
          ),
          el(
            'a.ds-btn.ds-btn-quiet',
            {
              href: `mailto:${BRAND.email}?subject=${encodeURIComponent('Professional application')}&body=${encodeURIComponent(message)}`,
            },
            t('Send by email', 'በኢሜይል ላክ'),
          ),
          el(
            'button.ds-btn.ds-btn-quiet',
            { type: 'button', onclick: () => copyText(message, t('Application copied', 'ማመልከቻው ተቀድቷል')) },
            [icon('copy', { size: 16 }), el('span', null, t('Copy text', 'ጽሑፉን ቅዳ'))],
          ),
        ]),
      ]),
    )

    preview.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  return el('div', null, [
    pageHead(
      t('Join as a health professional', 'እንደ ጤና ባለሙያ ይቀላቀሉ'),
      t(
        'Licensed doctors and allied health professionals are welcome to consult on Hakimm.com.',
        'ፍቃድ ያላቸው ሐኪሞችና ተያያዥ የጤና ባለሙያዎች በሓኪም ዶት ኮም ላይ እንዲያማክሩ እንጋብዛለን።',
      ),
    ),

    el('div.container.container-narrow.stack-lg', null, [
      el('div.notice', null, [
        icon('info', { size: 16 }),
        el('span', null, t(
          'Applications are read by a person, not by this page. The form below prepares the message; you send it, and we reply on the same channel.',
          'ማመልከቻዎች በዚህ ገጽ ሳይሆን በሰው ይነበባሉ። ከታች ያለው ቅጽ መልእክቱን ያዘጋጃል፤ እርስዎ ይልኩታል፣ እኛም በዚያው መንገድ እንመልሳለን።',
        )),
      ]),

      form,
      preview,

      el('p.center.text-sm.text-muted', null, [
        el('span', null, t('Questions first? ', 'መጀመሪያ ጥያቄ አለዎት? ')),
        link('/support', null, t('Contact us', 'ያግኙን')),
      ]),
    ]),
  ])
}
