/**
 * My appointments.
 *
 * Replaces `src/routes/appointments.tsx`, which listed bookings from a server
 * function scoped by the JWT subject. Here the scope is the local actor id —
 * the signed-in account, or the per-device id for a guest — so a booking made
 * before signing up is not orphaned by signing up afterwards.
 */

import { patch, query, remove } from '../store.js'
import { formatDate, formatRelative, formatTime, t } from '../i18n.js'
import { copyText, el, empty, icon, modal, toast } from '../ui.js'
import { actorId } from '../auth.js'
import { link } from '../router.js'
import { pageHead, statusPill } from './_shared.js'

const MODE_ICON = { video: 'video', audio: 'phone', chat: 'message' }

export async function render() {
  const root = el('div')
  const list = el('div.stack')

  root.append(
    pageHead(
      t('My appointments', 'ቀጠሮዎቼ'),
      t(
        'Bookings saved on this device. Clearing browser data removes them, so keep the reference number.',
        'በዚህ መሣሪያ ላይ የተቀመጡ ቀጠሮዎች። የአሳሽ መረጃ ሲጸዳ ይጠፋሉ፣ ስለዚህ የማጣቀሻ ቁጥሩን ይያዙ።',
      ),
      link('/booking', { class: 'ds-btn ds-btn-primary' }, [
        icon('plus', { size: 16 }),
        el('span', null, t('New booking', 'አዲስ ቀጠሮ')),
      ]),
    ),
    el('div.container.stack', null, [list]),
  )

  async function draw() {
    const me = actorId()
    const rows = (await query('appointments', (row) => row.patientId === me)).sort((a, b) =>
      String(b.preferredAt).localeCompare(String(a.preferredAt)),
    )

    if (!rows.length) {
      list.replaceChildren(
        empty(t('No appointments yet.', 'እስካሁን ቀጠሮ የለም።'), 'calendar'),
        el('div.center', null, link('/doctors', { class: 'ds-btn ds-btn-primary' }, t('Find a doctor', 'ዶክተር ያግኙ'))),
      )
      return
    }

    list.replaceChildren(...rows.map(card))
  }

  function card(row) {
    const when = row.preferredAt ? new Date(row.preferredAt) : null
    const isPast = when && when.getTime() < Date.now()

    return el('div.card.stack-sm', null, [
      el('div.row-wrap', null, [
        icon(MODE_ICON[row.serviceType] || 'calendar', { size: 18 }),
        el('strong.text-sm', null, row.doctorName || t('Consultation', 'ምክክር')),
        el('span.spacer'),
        statusPill(row.status),
      ]),

      el('div.doc-card__meta', null, [
        el('span', null, when ? `${formatDate(when)} · ${formatTime(when)}` : '—'),
        el('span.mono', null, row.reference),
        row.amountEtb ? el('span', null, `${row.amountEtb} ETB`) : null,
      ]),

      row.topic ? el('p.text-sm.text-muted', null, row.topic) : null,

      el('div.doc-card__actions', null, [
        row.status !== 'cancelled' && !isPast && row.serviceType !== 'chat'
          ? link(`/room/${encodeURIComponent(row.id)}`, { class: 'ds-btn ds-btn-primary' }, t('Join', 'ተቀላቀል'))
          : null,

        row.doctorId
          ? link(`/messaging?doctor=${encodeURIComponent(row.doctorId)}`, { class: 'ds-btn ds-btn-quiet' }, t('Message', 'መልዕክት'))
          : null,

        el('span.spacer'),

        el(
          'button.action-icon',
          {
            type: 'button',
            'aria-label': t('Copy reference', 'ማጣቀሻ ቅዳ'),
            onclick: () => copyText(row.reference, t('Reference copied', 'ማጣቀሻው ተቀድቷል')),
          },
          icon('copy', { size: 16 }),
        ),

        row.status === 'pending'
          ? el(
              'button.action-icon',
              {
                type: 'button',
                'aria-label': t('Cancel booking', 'ቀጠሮ ሰርዝ'),
                onclick: () => cancel(row),
              },
              icon('close', { size: 16 }),
            )
          : null,

        el(
          'button.action-icon',
          {
            type: 'button',
            'aria-label': t('Delete', 'አጥፋ'),
            onclick: () => destroy(row),
          },
          icon('alert', { size: 16 }),
        ),
      ]),

      el('p.text-xs.text-muted', null, t(`Created ${formatRelative(row.createdAt)}`, `የተፈጠረው ${formatRelative(row.createdAt)}`)),
    ])
  }

  async function cancel(row) {
    const confirmed = await modal({
      title: t('Cancel this booking?', 'ይህን ቀጠሮ ይሰርዙ?'),
      description: t(
        'The record stays in your list marked cancelled. Tell the clinic too if it was already confirmed.',
        'መዝገቡ በዝርዝርዎ ውስጥ እንደተሰረዘ ሆኖ ይቆያል። አስቀድሞ ተረጋግጦ ከነበረ ለክሊኒኩም ያሳውቁ።',
      ),
      actions: (close) => [
        el('button.ds-btn.ds-btn-quiet', { type: 'button', onclick: () => close(false) }, t('Keep it', 'ይቆይ')),
        el('button.ds-btn.ds-btn-primary', { type: 'button', onclick: () => close(true) }, t('Cancel booking', 'ሰርዝ')),
      ],
    })

    if (!confirmed) return
    await patch('appointments', row.id, { status: 'cancelled' })
    toast(t('Booking cancelled', 'ቀጠሮው ተሰርዟል'), 'info')
    draw()
  }

  async function destroy(row) {
    const confirmed = await modal({
      title: t('Delete permanently?', 'ለዘላቂው ይጥፋ?'),
      description: t(
        'This removes the record from this device. It cannot be undone.',
        'ይህ መዝገቡን ከዚህ መሣሪያ ያስወግዳል። መመለስ አይቻልም።',
      ),
      actions: (close) => [
        el('button.ds-btn.ds-btn-quiet', { type: 'button', onclick: () => close(false) }, t('Keep it', 'ይቆይ')),
        el('button.ds-btn.ds-btn-primary', { type: 'button', onclick: () => close(true) }, t('Delete', 'አጥፋ')),
      ],
    })

    if (!confirmed) return
    await remove('appointments', row.id)
    toast(t('Deleted', 'ጠፍቷል'), 'info')
    draw()
  }

  await draw()
  return root
}
