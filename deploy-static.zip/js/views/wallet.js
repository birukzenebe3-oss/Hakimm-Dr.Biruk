/**
 * MedCoin wallet.
 *
 * Replaces `src/routes/wallet.tsx` and `src/server/medcoin.ts` — 42 server
 * functions over the `medcoin` and `medcoin-p2p` blob stores.
 *
 * An important correction to how this feature is often described: MedCoin was
 * never a blockchain token. It was an internal loyalty ledger held in Netlify
 * Blobs, credited and debited by an administrator. A balance is only meaningful
 * if one authority holds it, and this build has no authority — so what is shown
 * here is a local record of what the clinic has confirmed, not a live balance,
 * and the page says so rather than implying otherwise. On-chain settlement is a
 * separate page (`/web3`) where the ledger is the chain itself.
 */

import { all, newId, put } from '../store.js'
import { formatDate, formatRelative, t } from '../i18n.js'
import { el, empty, field, icon, modal, toast } from '../ui.js'
import { actorId } from '../auth.js'
import { link } from '../router.js'
import { pageHead } from './_shared.js'

const RATE_ETB_PER_COIN = 1

export async function render() {
  const root = el('div')
  const body = el('div.container.stack-lg')

  root.append(
    pageHead(
      t('MedCoin wallet', 'ሜድኮይን ቦርሳ'),
      t(
        'Your record of confirmed MedCoin credits and what you spent them on.',
        'የተረጋገጡ የሜድኮይን ክሬዲቶችዎ እና ያወጡበት መዝገብ።',
      ),
    ),
    body,
  )

  async function draw() {
    const me = actorId()
    const entries = (await all('medcoin-tx'))
      .filter((row) => row.ownerId === me)
      .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))

    const balance = entries.reduce((total, row) => total + Number(row.amount || 0), 0)
    const earned = entries.filter((row) => row.amount > 0).reduce((total, row) => total + row.amount, 0)
    const spent = entries.filter((row) => row.amount < 0).reduce((total, row) => total - row.amount, 0)

    body.replaceChildren(
      el('div.balance-card.ds-brand-gradient', null, [
        el('div.balance-card__label', null, t('MedCoin balance', 'የሜድኮይን ሂሳብ')),
        el('div.balance-card__value', null, balance.toLocaleString()),
        el('div.balance-card__sub', null, t(
          `≈ ${(balance * RATE_ETB_PER_COIN).toLocaleString()} ETB toward consultation fees`,
          `≈ ${(balance * RATE_ETB_PER_COIN).toLocaleString()} ብር ለምክክር ክፍያ`,
        )),
      ]),

      el('div.stat-row', null, [
        el('div.stat', null, [el('div.stat__value', null, earned.toLocaleString()), el('div.stat__label', null, t('Earned', 'የተገኘ'))]),
        el('div.stat', null, [el('div.stat__value', null, spent.toLocaleString()), el('div.stat__label', null, t('Spent', 'የወጣ'))]),
        el('div.stat', null, [el('div.stat__value', null, String(entries.length)), el('div.stat__label', null, t('Entries', 'መዝገቦች'))]),
      ]),

      el('div.notice', null, [
        icon('info', { size: 16 }),
        el('span', null, t(
          'This is a local copy kept on your device. The clinic holds the authoritative balance — record a credit here after it has been confirmed with them.',
          'ይህ በመሣሪያዎ ላይ የተቀመጠ ቅጂ ነው። ትክክለኛውን ሂሳብ ክሊኒኩ ይይዛል — ከእነሱ ጋር ከተረጋገጠ በኋላ እዚህ ይመዝግቡ።',
        )),
      ]),

      el('div.form-actions', null, [
        el('button.ds-btn.ds-btn-primary', { type: 'button', onclick: () => recordEntry(1) }, [
          icon('plus', { size: 16 }),
          el('span', null, t('Record a credit', 'ክሬዲት መዝግብ')),
        ]),
        el('button.ds-btn.ds-btn-quiet', { type: 'button', onclick: () => recordEntry(-1) }, [
          icon('coins', { size: 16 }),
          el('span', null, t('Record a payment', 'ክፍያ መዝግብ')),
        ]),
        link('/p2p', { class: 'ds-btn ds-btn-quiet' }, t('P2P marketplace', 'የP2P ገበያ')),
      ]),

      el('section.stack', null, [
        el('h2.section-title', null, t('History', 'ታሪክ')),
        entries.length ? table(entries) : empty(t('No entries yet.', 'እስካሁን መዝገብ የለም።'), 'coins'),
      ]),
    )
  }

  function table(entries) {
    return el('div.table-wrap', null, [
      el('table.table', null, [
        el('thead', null, el('tr', null, [
          el('th', null, t('Date', 'ቀን')),
          el('th', null, t('Description', 'መግለጫ')),
          el('th', null, t('Amount', 'መጠን')),
        ])),
        el(
          'tbody',
          null,
          entries.map((entry) =>
            el('tr', null, [
              el('td', null, [
                el('div.text-sm', null, formatDate(entry.createdAt)),
                el('div.text-xs.text-muted', null, formatRelative(entry.createdAt)),
              ]),
              el('td', null, entry.note || (entry.amount > 0 ? t('Credit', 'ክሬዲት') : t('Payment', 'ክፍያ'))),
              el(
                'td.text-end',
                { style: { color: entry.amount > 0 ? 'var(--ds-success-600)' : 'var(--ds-danger-600)', fontWeight: '700' } },
                `${entry.amount > 0 ? '+' : ''}${entry.amount}`,
              ),
            ]),
          ),
        ),
      ]),
    ])
  }

  /** `sign` is +1 for a credit, -1 for a payment. */
  async function recordEntry(sign) {
    const amountInput = el('input.input', { type: 'number', min: '1', step: '1', value: '', inputmode: 'numeric' })
    const noteInput = el('input.input', { type: 'text', placeholder: t('e.g. consultation with Dr. Almaz', 'ለምሳሌ ከዶ/ር አልማዝ ጋር ምክክር') })

    const confirmed = await modal({
      title: sign > 0 ? t('Record a credit', 'ክሬዲት መዝግብ') : t('Record a payment', 'ክፍያ መዝግብ'),
      description: t(
        'Enter what the clinic has already confirmed. This does not move any money.',
        'ክሊኒኩ አስቀድሞ ያረጋገጠውን ያስገቡ። ይህ ገንዘብ አያንቀሳቅስም።',
      ),
      body: () => el('div', null, [
        field({ label: t('MedCoin amount', 'የሜድኮይን መጠን'), input: amountInput }),
        field({ label: t('Note', 'ማስታወሻ'), input: noteInput }),
      ]),
      actions: (close) => [
        el('button.ds-btn.ds-btn-quiet', { type: 'button', onclick: () => close(false) }, t('Cancel', 'ተወው')),
        el('button.ds-btn.ds-btn-primary', { type: 'button', onclick: () => close(true) }, t('Save', 'አስቀምጥ')),
      ],
    })

    if (!confirmed) return

    const amount = Math.abs(Math.round(Number(amountInput.value)))
    if (!Number.isFinite(amount) || amount <= 0) {
      toast(t('Enter a whole number greater than zero.', 'ከዜሮ በላይ ሙሉ ቁጥር ያስገቡ።'), 'error')
      return
    }

    await put('medcoin-tx', {
      id: newId(),
      ownerId: actorId(),
      amount: amount * sign,
      note: noteInput.value.trim(),
    })

    toast(t('Entry saved', 'መዝገቡ ተቀምጧል'), 'success')
    draw()
  }

  await draw()
  return root
}
