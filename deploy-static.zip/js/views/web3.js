/**
 * Crypto wallet — the on-chain half of payments.
 *
 * There was no equivalent page in the React build. The old USDT flow was a
 * form: the patient typed a transaction hash and a wallet address, and an
 * administrator checked it by hand against a block explorer and then credited
 * the blob-store ledger. No code in the original 67k lines ever spoke to a
 * chain.
 *
 * This page does. Balances are read over public RPC — no wallet needed — and
 * transfers are signed by an injected EIP-1193 wallet. Nothing here needs a
 * backend: the chain is the ledger, and the user's wallet is the authority.
 */

import { t } from '../i18n.js'
import { copyText, el, field, icon, toast } from '../ui.js'
import { prefs } from '../store.js'
import {
  CHAINS,
  DEFAULT_CHAIN,
  connect,
  hasInjectedWallet,
  isAddress,
  nativeBalance,
  onWalletChange,
  sendUsdt,
  shortAddress,
  silentAccount,
  switchChain,
  usdtBalance,
} from '../web3.js'
import { pageHead } from './_shared.js'

export async function render() {
  let chainKey = prefs.get('web3-chain', DEFAULT_CHAIN)
  if (!CHAINS[chainKey]) chainKey = DEFAULT_CHAIN

  let address = await silentAccount()

  const root = el('div')
  const body = el('div.container.stack-lg')

  root.append(
    pageHead(
      t('Crypto wallet', 'ክሪፕቶ ቦርሳ'),
      t(
        'Check a USDT balance or settle a consultation fee on-chain. Your keys never leave your wallet.',
        'የUSDT ሂሳብ ይመልከቱ ወይም የምክክር ክፍያን በሰንሰለት ላይ ይክፈሉ። ቁልፎችዎ ከቦርሳዎ አይወጡም።',
      ),
    ),
    body,
  )

  // Follow the wallet rather than fighting it: if the user switches account or
  // network in MetaMask, the page should already agree with them.
  const unsubscribe = onWalletChange({
    onAccounts: (next) => {
      address = next
      draw()
    },
    onChain: (id) => {
      const match = Object.entries(CHAINS).find(([, chain]) => chain.id === id)
      if (match) {
        chainKey = match[0]
        prefs.set('web3-chain', chainKey)
      }
      draw()
    },
  })
  window.addEventListener('pagehide', unsubscribe, { once: true })

  function chainSelect() {
    return el(
      'select.select',
      {
        value: chainKey,
        onchange: async (event) => {
          chainKey = event.target.value
          prefs.set('web3-chain', chainKey)
          draw()
          if (address) {
            try {
              await switchChain(chainKey)
            } catch (err) {
              if (err?.code !== 4001) toast(err.message || String(err), 'error')
            }
          }
        },
      },
      Object.entries(CHAINS).map(([key, chain]) => el('option', { value: key }, chain.name)),
    )
  }

  function draw() {
    const chain = CHAINS[chainKey]

    const balanceCard = el('div.balance-card.ds-brand-gradient', null, [
      el('div.balance-card__label', null, `USDT · ${chain.name}`),
      el('div.balance-card__value', null, address ? '…' : '—'),
      el('div.balance-card__sub', null, address ? shortAddress(address) : t('No wallet connected', 'ቦርሳ አልተገናኘም')),
    ])

    body.replaceChildren(
      balanceCard,

      !hasInjectedWallet()
        ? el('div.notice.notice--warn', null, [
            icon('alert', { size: 16 }),
            el('span', null, t(
              'No browser wallet detected. Install MetaMask, or open this page inside a wallet app to connect. Balances below still work by pasting an address.',
              'የአሳሽ ቦርሳ አልተገኘም። MetaMask ይጫኑ ወይም ይህን ገጽ በቦርሳ መተግበሪያ ውስጥ ይክፈቱ። አድራሻ በመለጠፍ ሂሳብ ማየት ግን ይቻላል።',
            )),
          ])
        : null,

      el('div.card.stack', null, [
        field({ label: t('Network', 'አውታረ መረብ'), input: chainSelect() }),

        el('div.form-actions', null, [
          address
            ? el(
                'button.ds-btn.ds-btn-quiet',
                { type: 'button', onclick: () => copyText(address, t('Address copied', 'አድራሻው ተቀድቷል')) },
                [icon('copy', { size: 16 }), el('span', null, shortAddress(address))],
              )
            : el(
                'button.ds-btn.ds-btn-primary',
                {
                  type: 'button',
                  onclick: async (event) => {
                    const button = event.currentTarget
                    button.disabled = true
                    try {
                      const result = await connect()
                      address = result.address
                      const match = Object.entries(CHAINS).find(([, c]) => c.id === result.chainId)
                      if (match) chainKey = match[0]
                      toast(t('Wallet connected', 'ቦርሳው ተገናኝቷል'), 'success')
                      draw()
                    } catch (err) {
                      toast(err.message || String(err), 'error')
                      button.disabled = false
                    }
                  },
                },
                [icon('wallet', { size: 16 }), el('span', null, t('Connect wallet', 'ቦርሳ አገናኝ'))],
              ),

          el(
            'a.ds-btn.ds-btn-quiet',
            {
              href: address ? `${chain.explorer}/address/${address}` : chain.explorer,
              target: '_blank',
              rel: 'noopener noreferrer',
            },
            [icon('link', { size: 16 }), el('span', null, t('View on explorer', 'በኤክስፕሎረር ይመልከቱ'))],
          ),
        ]),
      ]),

      lookupCard(),
      address ? sendCard() : null,

      el('div.notice', null, [
        icon('shield', { size: 16 }),
        el('span', null, t(
          'Transactions are irreversible and are settled by the network, not by Hakimm.com. Check the address and the network before you confirm.',
          'ግብይቶች የማይመለሱ ሲሆኑ በአውታረ መረቡ እንጂ በሓኪም ዶት ኮም አይከናወኑም። ከማረጋገጥዎ በፊት አድራሻውን እና አውታረ መረቡን ያረጋግጡ።',
        )),
      ]),
    )

    if (address) refreshBalance(balanceCard)
  }

  /** Fill in the balance card once the RPC round-trip returns. */
  async function refreshBalance(card) {
    const forAddress = address
    const forChain = chainKey

    try {
      const [usdt, native] = await Promise.all([
        usdtBalance(forAddress, forChain),
        nativeBalance(forAddress, forChain).catch(() => null),
      ])

      // A slow RPC can resolve after the user has changed wallet or network.
      if (forAddress !== address || forChain !== chainKey || !card.isConnected) return

      card.querySelector('.balance-card__value').textContent = Number(usdt.formatted).toLocaleString(undefined, {
        maximumFractionDigits: 2,
      })
      card.querySelector('.balance-card__sub').textContent = native
        ? `${shortAddress(forAddress)} · ${Number(native.formatted).toFixed(4)} ${native.symbol}`
        : shortAddress(forAddress)
    } catch (err) {
      console.error('[web3] balance lookup failed', err)
      if (card.isConnected) card.querySelector('.balance-card__value').textContent = '—'
      toast(t('Could not reach the network. Try again.', 'አውታረ መረቡን ማግኘት አልተቻለም። እንደገና ይሞክሩ።'), 'error')
    }
  }

  /* ---------- balance lookup for any address ---------- */

  function lookupCard() {
    const input = el('input.input', { type: 'text', placeholder: '0x…', spellcheck: false, autocapitalize: 'off' })
    const result = el('p.text-sm.text-muted')

    return el('div.card.stack', null, [
      el('h2.section-title', null, t('Check any address', 'ማንኛውንም አድራሻ ይመልከቱ')),
      field({
        label: t('Wallet address', 'የቦርሳ አድራሻ'),
        hint: t('Read-only, over a public node — no wallet required.', 'በአደባባይ ኖድ በኩል ንባብ ብቻ — ቦርሳ አያስፈልግም።'),
        input,
      }),
      el('div.form-actions', null, [
        el(
          'button.ds-btn.ds-btn-quiet',
          {
            type: 'button',
            onclick: async (event) => {
              const value = input.value.trim()
              const button = event.currentTarget
              result.textContent = ''

              if (!(await isAddress(value))) {
                result.textContent = t('That is not a valid address.', 'ይህ ትክክለኛ አድራሻ አይደለም።')
                return
              }

              button.disabled = true
              try {
                const balance = await usdtBalance(value, chainKey)
                result.textContent = `${Number(balance.formatted).toLocaleString()} USDT · ${CHAINS[chainKey].name}`
              } catch (err) {
                result.textContent = err.message || String(err)
              } finally {
                button.disabled = false
              }
            },
          },
          t('Check balance', 'ሂሳብ ይመልከቱ'),
        ),
      ]),
      result,
    ])
  }

  /* ---------- transfer ---------- */

  function sendCard() {
    const toInput = el('input.input', { type: 'text', placeholder: '0x…', spellcheck: false, autocapitalize: 'off' })
    const amountInput = el('input.input', { type: 'number', min: '0', step: '0.01', inputmode: 'decimal' })
    const receipt = el('div.stack-sm')

    return el('div.card.stack', null, [
      el('h2.section-title', null, t('Send USDT', 'USDT ላክ')),
      field({ label: t('Recipient address', 'የተቀባይ አድራሻ'), input: toInput }),
      field({
        label: t('Amount (USDT)', 'መጠን (USDT)'),
        hint: t(
          `Sent on ${CHAINS[chainKey].name}. Sending to an address on a different network loses the funds.`,
          `በ${CHAINS[chainKey].name} ላይ ይላካል። ወደ ሌላ አውታረ መረብ አድራሻ መላክ ገንዘቡን ያጠፋል።`,
        ),
        input: amountInput,
      }),

      el('div.form-actions', null, [
        el(
          'button.ds-btn.ds-btn-primary',
          {
            type: 'button',
            onclick: async (event) => {
              const button = event.currentTarget
              button.disabled = true
              receipt.replaceChildren(el('p.text-sm.text-muted', null, t('Confirm in your wallet…', 'በቦርሳዎ ያረጋግጡ…')))

              try {
                const tx = await sendUsdt({
                  to: toInput.value.trim(),
                  amount: amountInput.value,
                  chainKey,
                })

                receipt.replaceChildren(
                  el('p.text-sm', null, t('Broadcast — waiting for confirmation.', 'ተልኳል — ማረጋገጫ በመጠበቅ ላይ።')),
                  el('a.mono', { href: tx.explorer, target: '_blank', rel: 'noopener noreferrer' }, tx.hash),
                )

                await tx.wait()
                receipt.replaceChildren(
                  el('div.notice', null, [icon('check', { size: 16 }), el('span', null, t('Transfer confirmed.', 'ዝውውሩ ተረጋግጧል።'))]),
                  el('a.mono', { href: tx.explorer, target: '_blank', rel: 'noopener noreferrer' }, tx.hash),
                )
                toast(t('Transfer confirmed', 'ዝውውሩ ተረጋግጧል'), 'success')
              } catch (err) {
                const message = err?.code === 4001 ? t('You rejected the transaction.', 'ግብይቱን ውድቅ አድርገዋል።') : err.message || String(err)
                receipt.replaceChildren(el('div.notice.notice--danger', null, [icon('alert', { size: 16 }), el('span', null, message)]))
              } finally {
                button.disabled = false
              }
            },
          },
          [icon('send', { size: 16 }), el('span', null, t('Review and send', 'ገምግም እና ላክ'))],
        ),
      ]),

      receipt,
    ])
  }

  draw()
  return root
}
