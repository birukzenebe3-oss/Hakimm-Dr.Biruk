/**
 * Booking wizard.
 *
 * Replaces `src/routes/booking.tsx` plus the `public/gate.html` intake form,
 * which POSTed to `/gate-api/submit` → the `consultations` Postgres table via
 * a Netlify Function. Neither the function nor the database is reachable from
 * a static bundle, so the booking is written to IndexedDB and handed to the
 * patient as a reference they can send on — see `results.md` for what that
 * changes operationally.
 *
 * The field set deliberately matches the old `consultations` schema (service
 * type, amount, patient name, phone, preferred time, topic, payment method) so
 * a record exported from here still maps onto the clinic's existing process.
 */

import { all, get, newId, put } from '../store.js'
import { formatBirr, t } from '../i18n.js'
import { copyText, el, field, icon, toast } from '../ui.js'
import { actorId, currentUser } from '../auth.js'
import { link, navigate } from '../router.js'
import { telegramLink } from '../brand.js'
import { doctorName, doctorSpecialty, pageHead } from './_shared.js'

const MODES = [
  { id: 'video', icon: 'video', en: 'Video call', am: 'የቪዲዮ ጥሪ', enDesc: 'Face to face, browser to browser.', amDesc: 'ፊት ለፊት፣ ከአሳሽ ወደ አሳሽ።' },
  { id: 'audio', icon: 'phone', en: 'Audio call', am: 'የድምፅ ጥሪ', enDesc: 'Lower bandwidth — works on a weak connection.', amDesc: 'አነስተኛ ኢንተርኔት — በደካማ ግንኙነት ይሠራል።' },
  { id: 'chat', icon: 'message', en: 'Text chat', am: 'የጽሑፍ ውይይት', enDesc: 'Write when speaking is difficult or private.', amDesc: 'መናገር ሲከብድ ወይም ሲስጥር ሲፈለግ።' },
]

// Labels are resolved at render time, not at module scope — a module constant
// would freeze whichever language was active when the chunk first loaded.
const PAYMENT_METHODS = [
  { id: 'telebirr', en: 'Telebirr', am: 'ቴሌብር' },
  { id: 'cbe', en: 'CBE Birr / bank transfer', am: 'ሲቢኢ ብር / የባንክ ዝውውር' },
  { id: 'medcoin', en: 'MedCoin balance', am: 'ሜድኮይን ሂሳብ' },
  { id: 'usdt', en: 'USDT (crypto)', am: 'USDT (ክሪፕቶ)' },
]

export async function render({ search }) {
  const user = currentUser()
  const doctors = await all('doctors')

  const draft = {
    doctorId: search.get('doctor') || '',
    mode: search.get('mode') || 'video',
    patientName: user?.name || '',
    phone: user?.phone || '',
    preferredAt: '',
    topic: '',
    paymentMethod: 'telebirr',
  }

  let step = draft.doctorId ? 1 : 0

  const root = el('div')
  const body = el('div.container.container-narrow.stack')

  root.append(
    pageHead(
      t('Book a consultation', 'ቀጠሮ ይያዙ'),
      t(
        'Three short steps. Nothing is sent anywhere until you choose to share the reference.',
        'ሦስት አጭር ደረጃዎች። ማጣቀሻውን እስኪያጋሩ ድረስ የትም አይላክም።',
      ),
    ),
    body,
  )

  function stepper() {
    const labels = [t('Doctor', 'ዶክተር'), t('Details', 'ዝርዝር'), t('Confirm', 'አረጋግጥ')]
    return el(
      'div.steps',
      null,
      labels.flatMap((label, index) => {
        const state = index < step ? '.is-done' : index === step ? '.is-active' : ''
        const item = el(`div.steps__item${state}`, null, [
          el('span.steps__dot', null, index < step ? icon('check', { size: 12 }) : String(index + 1)),
          el('span', null, label),
        ])
        return index < labels.length - 1 ? [item, el('span.steps__bar')] : [item]
      }),
    )
  }

  function draw() {
    const screens = [chooseDoctor, chooseDetails, confirm]
    body.replaceChildren(stepper(), screens[step]())
  }

  /* ---------- step 1: doctor ---------- */

  function chooseDoctor() {
    const list = el(
      'div.stack-sm',
      null,
      doctors.map((doctor) =>
        el('label.choice', null, [
          el('input', {
            type: 'radio',
            name: 'doctor',
            value: doctor.id,
            checked: draft.doctorId === doctor.id,
            onchange: () => {
              draft.doctorId = doctor.id
            },
          }),
          el('span', null, [
            el('span.choice__title', null, doctorName(doctor)),
            el('span.choice__desc', null, [
              doctorSpecialty(doctor),
              doctor.consultationFee ? ` · ${formatBirr(doctor.consultationFee)}` : '',
            ].join('')),
          ]),
        ]),
      ),
    )

    return el('div.stack', null, [
      el('h2.section-title', null, t('Choose a professional', 'ባለሙያ ይምረጡ')),
      doctors.length ? list : el('p.text-sm.text-muted', null, t('No professionals are listed yet.', 'እስካሁን ባለሙያዎች የሉም።')),
      el('div.form-actions', null, [
        el(
          'button.ds-btn.ds-btn-primary',
          {
            type: 'button',
            onclick: () => {
              if (!draft.doctorId) return toast(t('Select a professional first.', 'መጀመሪያ ባለሙያ ይምረጡ።'), 'error')
              step = 1
              draw()
            },
          },
          t('Continue', 'ቀጥል'),
        ),
        link('/doctors', { class: 'ds-btn ds-btn-quiet' }, t('Browse profiles', 'መገለጫዎችን ይመልከቱ')),
      ]),
    ])
  }

  /* ---------- step 2: details ---------- */

  function chooseDetails() {
    const nameInput = el('input.input', {
      type: 'text',
      value: draft.patientName,
      autocomplete: 'name',
      required: true,
      oninput: (event) => {
        draft.patientName = event.target.value
      },
    })

    const phoneInput = el('input.input', {
      type: 'tel',
      value: draft.phone,
      autocomplete: 'tel',
      placeholder: '+251…',
      oninput: (event) => {
        draft.phone = event.target.value
      },
    })

    // `datetime-local` degrades to a plain text box on old Android WebViews,
    // which is why the hint spells the expected format out.
    const whenInput = el('input.input', {
      type: 'datetime-local',
      value: draft.preferredAt,
      min: new Date(Date.now() + 60 * 60 * 1000).toISOString().slice(0, 16),
      oninput: (event) => {
        draft.preferredAt = event.target.value
      },
    })

    const topicInput = el('textarea.textarea', {
      value: draft.topic,
      placeholder: t('Briefly, what would you like to discuss?', 'በአጭሩ ስለ ምን መወያየት ይፈልጋሉ?'),
      oninput: (event) => {
        draft.topic = event.target.value
      },
    })

    const paymentSelect = el(
      'select.select',
      {
        value: draft.paymentMethod,
        onchange: (event) => {
          draft.paymentMethod = event.target.value
        },
      },
      PAYMENT_METHODS.map((method) => el('option', { value: method.id }, t(method.en, method.am))),
    )

    return el('div.stack', null, [
      el('h2.section-title', null, t('Consultation details', 'የምክክር ዝርዝር')),

      el('div.stack-sm', null, [
        el('span.field__label', null, t('How would you like to consult?', 'እንዴት መማከር ይፈልጋሉ?')),
        ...MODES.map((mode) =>
          el('label.choice', null, [
            el('input', {
              type: 'radio',
              name: 'mode',
              value: mode.id,
              checked: draft.mode === mode.id,
              onchange: () => {
                draft.mode = mode.id
              },
            }),
            el('span', null, [
              el('span.choice__title', null, t(mode.en, mode.am)),
              el('span.choice__desc', null, t(mode.enDesc, mode.amDesc)),
            ]),
          ]),
        ),
      ]),

      el('div.form-row.form-row--2', null, [
        field({ label: t('Full name', 'ሙሉ ስም'), input: nameInput }),
        field({ label: t('Phone number', 'ስልክ ቁጥር'), input: phoneInput }),
      ]),

      field({
        label: t('Preferred date and time', 'የሚመርጡት ቀን እና ሰዓት'),
        hint: t('Local time. The doctor confirms or proposes another slot.', 'የአካባቢ ሰዓት። ዶክተሩ ያረጋግጣል ወይም ሌላ ሰዓት ይጠቁማል።'),
        input: whenInput,
      }),

      field({ label: t('Reason for the consultation', 'የምክክሩ ምክንያት'), input: topicInput }),
      field({ label: t('Payment method', 'የክፍያ መንገድ'), input: paymentSelect }),

      el('div.form-actions', null, [
        el('button.ds-btn.ds-btn-quiet', { type: 'button', onclick: () => { step = 0; draw() } }, t('Back', 'ተመለስ')),
        el(
          'button.ds-btn.ds-btn-primary',
          {
            type: 'button',
            onclick: () => {
              if (!draft.patientName.trim()) return toast(t('Enter your name.', 'ስምዎን ያስገቡ።'), 'error')
              if (!draft.phone.trim()) return toast(t('Enter a phone number.', 'ስልክ ቁጥር ያስገቡ።'), 'error')
              if (!draft.preferredAt) return toast(t('Choose a date and time.', 'ቀን እና ሰዓት ይምረጡ።'), 'error')
              step = 2
              draw()
            },
          },
          t('Review', 'ገምግም'),
        ),
      ]),
    ])
  }

  /* ---------- step 3: confirm ---------- */

  function confirm() {
    const doctor = doctors.find((row) => row.id === draft.doctorId)
    const mode = MODES.find((row) => row.id === draft.mode)
    const payment = PAYMENT_METHODS.find((row) => row.id === draft.paymentMethod)

    const line = (label, value) =>
      el('div.row', null, [el('span.text-xs.text-muted', null, label), el('span.spacer'), el('strong.text-sm', null, value)])

    return el('div.stack', null, [
      el('h2.section-title', null, t('Confirm your booking', 'ቀጠሮዎን ያረጋግጡ')),

      el('div.card.stack-sm', null, [
        line(t('Professional', 'ባለሙያ'), doctor ? doctorName(doctor) : '—'),
        line(t('Type', 'ዓይነት'), t(mode.en, mode.am)),
        line(t('Patient', 'ታካሚ'), draft.patientName),
        line(t('Phone', 'ስልክ'), draft.phone),
        line(t('Preferred time', 'የሚመረጥ ሰዓት'), new Date(draft.preferredAt).toLocaleString()),
        line(t('Payment', 'ክፍያ'), t(payment.en, payment.am)),
        line(t('Fee', 'ክፍያ'), doctor?.consultationFee ? formatBirr(doctor.consultationFee) : '—'),
      ]),

      el('div.notice', null, [
        icon('info', { size: 16 }),
        el('span', null, t(
          'This booking is stored on this device. Share the reference with the clinic on Telegram or by phone to have it confirmed.',
          'ይህ ቀጠሮ በዚህ መሣሪያ ላይ ይቀመጣል። እንዲረጋገጥ ማጣቀሻውን በቴሌግራም ወይም በስልክ ለክሊኒኩ ያጋሩ።',
        )),
      ]),

      el('div.form-actions', null, [
        el('button.ds-btn.ds-btn-quiet', { type: 'button', onclick: () => { step = 1; draw() } }, t('Back', 'ተመለስ')),
        el('button.ds-btn.ds-btn-primary', { type: 'button', onclick: () => save(doctor) }, t('Confirm booking', 'ቀጠሮውን አረጋግጥ')),
      ]),
    ])
  }

  /**
   * Reference format kept short enough to read down a phone line, and derived
   * from the record id rather than a counter — there is no server to hand out
   * sequential numbers.
   */
  function reference(id) {
    return `HK-${String(id).replace(/[^a-zA-Z0-9]/g, '').slice(-8).toUpperCase()}`
  }

  async function save(doctor) {
    const id = newId()

    const record = await put('appointments', {
      id,
      reference: reference(id),
      patientId: actorId(),
      doctorId: draft.doctorId,
      doctorName: doctor ? doctor.name : '',
      serviceType: draft.mode,
      patientName: draft.patientName.trim(),
      phone: draft.phone.trim(),
      preferredAt: new Date(draft.preferredAt).toISOString(),
      topic: draft.topic.trim(),
      paymentMethod: draft.paymentMethod,
      amountEtb: doctor?.consultationFee ?? null,
      status: 'pending',
    })

    await put('notifications', {
      id: newId(),
      type: 'appointment',
      title: t('Booking created', 'ቀጠሮ ተፈጥሯል'),
      body: `${record.reference} · ${doctor ? doctor.name : ''}`,
      read: false,
    })

    toast(t('Booking saved', 'ቀጠሮው ተቀምጧል'), 'success')

    body.replaceChildren(
      el('div.stack', null, [
        el('div.card.center.stack', null, [
          el('div.empty__icon', { style: { margin: '0 auto' } }, icon('check', { size: 22 })),
          el('h2.section-title', null, t('Booking confirmed', 'ቀጠሮው ተረጋግጧል')),
          el('p.text-sm.text-muted', null, t('Your reference number is', 'የማጣቀሻ ቁጥርዎ')),
          el('p.balance-card__value', null, record.reference),
          el('div.form-actions', { style: { justifyContent: 'center' } }, [
            el(
              'button.ds-btn.ds-btn-quiet',
              { type: 'button', onclick: () => copyText(record.reference, t('Reference copied', 'ማጣቀሻው ተቀድቷል')) },
              [icon('copy', { size: 16 }), el('span', null, t('Copy reference', 'ማጣቀሻ ቅዳ'))],
            ),
            el(
              'a.ds-btn.ds-btn-primary',
              {
                href: telegramLink(
                  `Booking ${record.reference} — ${record.patientName}, ${record.serviceType}, ${new Date(record.preferredAt).toLocaleString()}`,
                ),
                target: '_blank',
                rel: 'noopener noreferrer',
              },
              t('Send on Telegram', 'በቴሌግራም ላክ'),
            ),
          ]),
        ]),

        el('div.form-actions', { style: { justifyContent: 'center' } }, [
          el(
            'button.ds-btn.ds-btn-quiet',
            { type: 'button', onclick: () => navigate('/appointments') },
            t('View my appointments', 'ቀጠሮዎቼን ይመልከቱ'),
          ),
        ]),
      ]),
    )
  }

  // A `?doctor=` link from a profile card should not silently fall through to
  // step one if that doctor has since been removed from the directory.
  if (draft.doctorId && !(await get('doctors', draft.doctorId))) {
    draft.doctorId = ''
    step = 0
  }

  draw()
  return root
}
