/**
 * Pieces shared by more than one view.
 *
 * Kept deliberately small. The React build accumulated 90 components, many of
 * them one-use wrappers; here a view builds its own markup with `el()` and only
 * genuinely repeated structures — the doctor card, the page header, the
 * sign-in gate — live in this module.
 */

import { t } from '../i18n.js'
import { avatar, el, icon, pill } from '../ui.js'
import { link } from '../router.js'
import { isSignedIn } from '../auth.js'

/** `<header>` block at the top of a full-page view. */
export function pageHead(title, lede, aside = null) {
  return el('div.container.page-head', null, [
    el('div.section-head', null, [
      el('div', null, [el('h1.page-title', null, title), lede ? el('p.page-lede', null, lede) : null]),
      aside,
    ]),
  ])
}

/** Section heading with an optional "see all" link on the right. */
export function sectionHead(title, { sub = null, more = null, moreLabel = null } = {}) {
  return el('div.section-head', null, [
    el('div', null, [el('h2.section-title', null, title), sub ? el('p.section-sub', null, sub) : null]),
    more ? link(more, { class: 'link-more' }, moreLabel || t('See all', 'ሁሉንም ይመልከቱ')) : null,
  ])
}

/** Localised doctor name / specialisation, falling back to the English field. */
export function doctorName(doctor) {
  return t(doctor.name, doctor.nameAm || doctor.name)
}

export function doctorSpecialty(doctor) {
  return t(doctor.specialization, doctor.specializationAm || doctor.specialization)
}

/**
 * Directory card. `rail` narrows it for the horizontal scroller on the home
 * page; the grid version fills its column.
 */
export function doctorCard(doctor, { rail = false } = {}) {
  return el(`div.doc-card${rail ? '.doc-card--rail' : ''}`, null, [
    el('div.doc-card__top', null, [
      avatar(doctor, { online: Boolean(doctor.isOnline) }),
      el('div.truncate', null, [
        el('div.doc-card__name', null, [
          el('span.truncate', null, doctorName(doctor)),
          icon('badgeCheck', { size: 14 }),
        ]),
        el('div.doc-card__spec', null, doctorSpecialty(doctor)),
        el('div.doc-card__meta', null, [
          el('span.row', null, [icon('star', { size: 12, fill: 'currentColor' }), el('span', null, String(doctor.rating ?? '—'))]),
          el('span', null, t(`${doctor.yearsOfExperience || 0} yrs`, `${doctor.yearsOfExperience || 0} ዓመት`)),
          doctor.consultationFee ? el('span', null, `${doctor.consultationFee} ETB`) : null,
        ]),
      ]),
    ]),

    el('div.doc-card__actions', null, [
      link(`/booking?doctor=${encodeURIComponent(doctor.id)}`, { class: 'ds-btn ds-btn-primary' }, t('Book', 'ቀጠሮ')),
      link(`/doctor/${encodeURIComponent(doctor.id)}`, { class: 'ds-btn ds-btn-quiet' }, t('Profile', 'መገለጫ')),
      el('span.spacer'),
      link(
        `/messaging?doctor=${encodeURIComponent(doctor.id)}`,
        { class: 'action-icon', 'aria-label': t('Message', 'መልዕክት') },
        icon('message', { size: 16 }),
      ),
    ]),
  ])
}

/** Presence badge used on profile and room views. */
export function presencePill(isOnline) {
  return isOnline
    ? pill(t('Available now', 'አሁን ይገኛሉ'), 'success')
    : pill(t('Offline', 'ከመስመር ውጭ'), 'muted')
}

/**
 * Gate for views that need an account. Returns a prompt node when signed out,
 * or `null` when the caller should render normally.
 *
 * This is a UX gate, not an authorisation boundary — see the note at the top
 * of `js/auth.js`. Nothing another party owns is behind it.
 */
export function signInGate(reason) {
  if (isSignedIn()) return null

  return el('div.container.section', null, [
    el('div.card.center.stack', null, [
      el('div.empty__icon', { style: { margin: '0 auto' } }, icon('user', { size: 22 })),
      el('h2.section-title', null, t('Sign in to continue', 'ለመቀጠል ይግቡ')),
      el('p.text-sm.text-muted', null, reason),
      el('div.form-actions', { style: { justifyContent: 'center' } }, [
        link('/login', { class: 'ds-btn ds-btn-primary' }, t('Sign in', 'ግባ')),
        link('/register', { class: 'ds-btn ds-btn-quiet' }, t('Create account', 'መለያ ይክፈቱ')),
      ]),
    ]),
  ])
}

/** Status pill for an appointment or order record. */
export function statusPill(status) {
  const map = {
    pending: ['warn', t('Pending', 'በመጠባበቅ ላይ')],
    confirmed: ['success', t('Confirmed', 'ተረጋግጧል')],
    completed: ['muted', t('Completed', 'ተጠናቋል')],
    cancelled: ['danger', t('Cancelled', 'ተሰርዟል')],
    open: ['success', t('Open', 'ክፍት')],
    filled: ['muted', t('Filled', 'ተጠናቋል')],
  }
  const [variant, label] = map[status] || ['muted', status]
  return pill(label, variant)
}
