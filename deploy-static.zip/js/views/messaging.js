/**
 * Messaging.
 *
 * Replaces `src/routes/messaging.tsx` and the `chat-enhanced` server module
 * (15 server functions over the `chats` and `messages` blob stores). Threads
 * and history now live in IndexedDB.
 *
 * Two honest limits, stated in the UI rather than hidden: history is per
 * device, and delivery only happens while both people have the thread open.
 * A store-and-forward inbox needs a server to hold the message until the
 * recipient comes back, and there is no server. What a static build can do is
 * a direct data channel, which is what the "Go live" control opens.
 */

import { all, get, newId, put, query } from '../store.js'
import { formatTime, t } from '../i18n.js'
import { avatar, el, empty, icon, toast } from '../ui.js'
import { actorId, actorName } from '../auth.js'
import { navigate, onRouteChange } from '../router.js'
import { consultationRoomId, createSession, peerIdFor } from '../rtc.js'
import { doctorName, doctorSpecialty, pageHead } from './_shared.js'

export async function render({ search }) {
  const doctors = await all('doctors')
  let activeId = search.get('doctor') || doctors[0]?.id || null

  let session = null
  let connection = null
  let disposed = false

  const threadList = el('div.thread-list')
  const panel = el('div.chat-panel')

  const root = el('div')
  root.append(
    pageHead(
      t('Messages', 'መልዕክቶች'),
      t(
        'Conversations are stored on this device. Live delivery works while both people have the thread open.',
        'ውይይቶች በዚህ መሣሪያ ላይ ይቀመጣሉ። ቀጥታ መላላክ የሚሠራው ሁለቱም ሰዎች ውይይቱን ሲከፍቱ ነው።',
      ),
    ),
    el('div.container', null, el('div.chat', null, [threadList, panel])),
  )

  if (!doctors.length) {
    panel.replaceChildren(empty(t('No professionals are listed yet.', 'እስካሁን ባለሙያዎች የሉም።'), 'users'))
    return root
  }

  /* ---------- teardown ---------- */

  function dispose() {
    disposed = true
    connection?.close?.()
    session?.destroy()
    session = null
    connection = null
  }

  const unsubscribe = onRouteChange(() => {
    dispose()
    unsubscribe()
  })
  window.addEventListener('pagehide', dispose, { once: true })

  /* ---------- threads ---------- */

  async function drawThreads() {
    const rows = await Promise.all(
      doctors.map(async (doctor) => {
        const messages = await query('messages', (row) => row.threadId === threadIdFor(doctor.id))
        const last = messages.sort((a, b) => String(a.createdAt).localeCompare(String(b.createdAt))).at(-1)
        return { doctor, last }
      }),
    )

    threadList.replaceChildren(
      ...rows.map(({ doctor, last }) =>
        el(
          'button.thread',
          {
            type: 'button',
            'aria-current': doctor.id === activeId ? 'true' : 'false',
            onclick: () => {
              activeId = doctor.id
              history.replaceState(history.state, '', `?doctor=${encodeURIComponent(doctor.id)}`)
              dispose()
              disposed = false
              drawThreads()
              openThread()
            },
          },
          [
            avatar(doctor, { size: 'sm', online: Boolean(doctor.isOnline) }),
            el('span', null, [
              el('span.thread__name', null, doctorName(doctor)),
              el('span.thread__last', null, last ? last.body : doctorSpecialty(doctor)),
            ]),
          ],
        ),
      ),
    )
  }

  /** Stable thread key shared by both participants, as `connect.ts` derived it. */
  function threadIdFor(doctorId) {
    return consultationRoomId(doctorId, actorId())
  }

  /* ---------- conversation ---------- */

  async function openThread() {
    const doctor = await get('doctors', activeId)
    if (!doctor) return

    const threadId = threadIdFor(doctor.id)
    const log = el('div.chat-log')

    const input = el('input.input', {
      type: 'text',
      placeholder: t('Write a message…', 'መልዕክት ይጻፉ…'),
      'aria-label': t('Message', 'መልዕክት'),
      onkeydown: (event) => {
        if (event.key === 'Enter') send()
      },
    })

    const liveButton = el(
      'button.action-icon',
      {
        type: 'button',
        title: t('Connect live', 'በቀጥታ ተገናኝ'),
        'aria-label': t('Connect live', 'በቀጥታ ተገናኝ'),
        onclick: goLive,
      },
      icon('link', { size: 16 }),
    )

    panel.replaceChildren(
      el('div.chat-panel__head', null, [
        avatar(doctor, { size: 'sm', online: Boolean(doctor.isOnline) }),
        el('div', null, [
          el('div.thread__name', null, doctorName(doctor)),
          el('div.text-xs.text-muted', null, doctorSpecialty(doctor)),
        ]),
        el('span.spacer'),
        liveButton,
        el(
          'button.action-icon',
          {
            type: 'button',
            title: t('Start a call', 'ጥሪ ጀምር'),
            'aria-label': t('Start a call', 'ጥሪ ጀምር'),
            onclick: () => navigate(`/consultation?doctor=${encodeURIComponent(doctor.id)}`),
          },
          icon('video', { size: 16 }),
        ),
      ]),

      log,

      el('div.chat-compose', null, [
        input,
        el(
          'button.ds-btn.ds-btn-primary',
          { type: 'button', 'aria-label': t('Send', 'ላክ'), onclick: send },
          icon('send', { size: 16 }),
        ),
      ]),
    )

    async function drawLog() {
      const messages = (await query('messages', (row) => row.threadId === threadId)).sort((a, b) =>
        String(a.createdAt).localeCompare(String(b.createdAt)),
      )

      if (!messages.length) {
        log.replaceChildren(
          empty(
            t('No messages yet. Say hello — describe your symptoms briefly.', 'እስካሁን መልዕክት የለም። ምልክቶችዎን በአጭሩ ይግለጹ።'),
            'message',
          ),
        )
        return
      }

      log.replaceChildren(
        ...messages.map((message) =>
          el(`div.bubble.bubble--${message.senderId === actorId() ? 'out' : 'in'}`, null, [
            el('span', null, message.body),
            el('span.bubble__time', null, formatTime(message.createdAt)),
          ]),
        ),
      )

      log.scrollTop = log.scrollHeight
    }

    async function record(body, senderId, senderName) {
      await put('messages', { id: newId(), threadId, senderId, senderName, body })
      await drawLog()
      drawThreads()
    }

    async function send() {
      const body = input.value.trim()
      if (!body) return
      input.value = ''

      await record(body, actorId(), actorName())

      // Delivered only if a live channel is open; otherwise the message waits
      // in local history, which the notice below makes explicit.
      if (connection?.open) connection.send({ body, senderName: actorName() })
    }

    /** Open a direct data channel to whoever else has this thread open. */
    async function goLive() {
      if (session) {
        dispose()
        disposed = false
        liveButton.classList.remove('is-on')
        toast(t('Live channel closed', 'ቀጥታ ግንኙነት ተዘግቷል'), 'info')
        return
      }

      liveButton.replaceChildren(icon('refresh', { size: 16 }))

      try {
        // Same first-come role claim the consultation room uses: whoever
        // arrives first listens, the second one dials.
        session = await createSession(peerIdFor(`chat-${threadId}`, 'a'))
        bindConnection()

        try {
          await session.ready
          toast(t('Waiting for the other side to join…', 'ሌላኛው ወገን እስኪቀላቀል በመጠበቅ ላይ…'))
        } catch (err) {
          if (err?.type !== 'unavailable-id') throw err
          session.destroy()
          session = await createSession(peerIdFor(`chat-${threadId}`, 'b'))
          bindConnection()
          await session.ready
          connection = session.connect(peerIdFor(`chat-${threadId}`, 'a'))
        }

        if (disposed) return
        liveButton.classList.add('is-on')
        liveButton.replaceChildren(icon('link', { size: 16 }))
      } catch (err) {
        console.error('[messaging] live channel failed', err)
        toast(err.message || t('Could not open a live channel.', 'ቀጥታ ግንኙነት መክፈት አልተቻለም።'), 'error')
        dispose()
        disposed = false
        liveButton.replaceChildren(icon('link', { size: 16 }))
      }
    }

    function bindConnection() {
      session.on('data-open', (opened) => {
        connection = opened
        toast(t('Live channel open', 'ቀጥታ ግንኙነት ተከፍቷል'), 'success')
      })

      session.on('data', ({ payload }) => {
        if (!payload?.body) return
        record(String(payload.body), doctor.id, payload.senderName || doctorName(doctor))
      })

      session.on('close', () => {
        connection = null
        liveButton.classList.remove('is-on')
      })
    }

    await drawLog()
  }

  await drawThreads()
  await openThread()
  return root
}
