/**
 * Article view.
 *
 * Replaces `src/routes/post.$postId.tsx`. The article body is stored as a
 * small Markdown subset (headings, paragraphs, list items) and rendered into
 * real elements rather than injected as HTML — the content is authored data,
 * and turning authored data into markup at runtime is how a content field
 * becomes a script injection.
 */

import { get } from '../store.js'
import { formatDate, t } from '../i18n.js'
import { copyText, el, empty, icon } from '../ui.js'
import { link } from '../router.js'
import { postTitle } from './feed.js'

/**
 * Minimal Markdown → DOM. Supports `## heading`, `- item` and blank-line
 * separated paragraphs, which is everything the seed content uses.
 */
function renderBody(markdown) {
  const nodes = []
  let list = null

  for (const block of String(markdown || '').split('\n')) {
    const line = block.trim()

    if (line.startsWith('- ')) {
      if (!list) {
        list = el('ul')
        nodes.push(list)
      }
      list.append(el('li', null, line.slice(2)))
      continue
    }

    list = null
    if (!line) continue

    if (line.startsWith('## ')) nodes.push(el('h2', null, line.slice(3)))
    else nodes.push(el('p', null, line))
  }

  return nodes
}

export async function render({ params }) {
  const post = await get('feed-posts', params.id)

  if (!post) {
    return el('div.container.section', null, [
      empty(t('That article is no longer available.', 'ይህ ጽሑፍ አልተገኘም።'), 'news'),
      el('div.center', null, link('/health-feed', { class: 'ds-btn ds-btn-quiet' }, t('Back to the feed', 'ወደ መረጃው ተመለስ'))),
    ])
  }

  // Keeps the shared link and the browser tab honest about which article this
  // is; the router only knows the generic route title.
  document.title = `${post.title} | Hakimm.com`

  const share = async () => {
    const url = location.href
    if (navigator.share) {
      try {
        await navigator.share({ title: post.title, text: post.excerpt, url })
        return
      } catch {
        /* dismissed — fall through to copy */
      }
    }
    copyText(url, t('Link copied', 'ማገናኛው ተቀድቷል'))
  }

  return el('article.container.container-narrow.section.stack', null, [
    el('div.row-wrap', null, [
      link('/health-feed', { class: 'action-icon', 'aria-label': t('Back', 'ተመለስ') }, icon('arrowLeft', { size: 16 })),
      post.category ? el('span.pill.pill--muted', null, post.category) : null,
      el('span.text-xs.text-muted', null, formatDate(post.createdAt)),
      el('span.spacer'),
      el(
        'button.action-icon',
        { type: 'button', 'aria-label': t('Share', 'አጋራ'), onclick: share },
        icon('link', { size: 16 }),
      ),
    ]),

    el('h1.page-title', null, postTitle(post)),
    post.excerpt ? el('p.page-lede', null, post.excerpt) : null,

    post.author
      ? el('div.row.text-sm.text-muted', null, [
          icon('user', { size: 14 }),
          el('span', null, post.author),
          el('span', null, '·'),
          el('span', null, t(`${post.readMinutes || 4} min read`, `${post.readMinutes || 4} ደቂቃ ንባብ`)),
        ])
      : null,

    el('div.prose', null, renderBody(post.body)),

    el('div.notice.notice--warn', null, [
      icon('alert', { size: 16 }),
      el('span', null, t(
        'General health education. It does not replace an examination — see a professional about your own situation.',
        'አጠቃላይ የጤና ትምህርት ነው። ምርመራን አይተካም — ስለ የራስዎ ሁኔታ ባለሙያ ያማክሩ።',
      )),
    ]),

    el('div.form-actions', null, [
      link('/doctors', { class: 'ds-btn ds-btn-primary' }, t('Ask a professional', 'ባለሙያ ይጠይቁ')),
      link('/health-feed', { class: 'ds-btn ds-btn-quiet' }, t('More articles', 'ተጨማሪ ጽሑፎች')),
    ]),
  ])
}
