/**
 * Static content pages — About, Privacy, Terms, Support.
 *
 * Replaces `src/routes/about.tsx`, `privacy.tsx`, `terms.tsx` and
 * `support.tsx`. The four shared one layout in the React build and share one
 * module here; the router picks between them with `props.doc`.
 *
 * The privacy, terms and support copy is the original text, both languages,
 * recovered from the shipped bundles rather than rewritten — these are the
 * clinic's published commitments and its real payment details, and paraphrasing
 * either would be a change of substance disguised as a refactor.
 *
 * About is the one exception. Its narrative, mission and three pillar bodies
 * were fetched from an admin-editable `settings` record, which is why the
 * deployed page currently renders a grey loading bar where the prose should be.
 * That record is not in the static bundle, so the prose is written out here
 * from the surrounding material. It is the only copy on these four pages that
 * is not verbatim, and an administrator changing it now means editing this
 * file.
 */

import { t } from '../i18n.js'
import { el, icon } from '../ui.js'
import { link } from '../router.js'
import { BRAND } from '../brand.js'
import { pageHead } from './_shared.js'

// Resolved on each render, never at module scope: a chunk loads once and keeps
// its bindings, so a `t()` evaluated up here would pin the page to whichever
// language happened to be active the first time it was opened.
const lastUpdated = () => t('Last updated: March 2026', 'የመጨረሻ ማሻሻያ: ማርች 2026')

export async function render({ props }) {
  const build = DOCS[props?.doc] || DOCS.about
  return build()
}

/* ============================ shared pieces ============================ */

/** Heading + paragraphs, the shape every legal section uses. */
function section(heading, ...blocks) {
  return el('section.stack-sm', null, [el('h2.section-title', null, heading), ...blocks])
}

function contactBlock(heading = t('Contact us', 'አግኙን')) {
  return section(
    heading,
    el('p.text-sm', null, [
      el('span', null, `${t('Email', 'ኢሜይል')}: `),
      el('a', { href: `mailto:${BRAND.email}` }, BRAND.email),
      el('br'),
      el('span', null, `${t('Phone', 'ስልክ')}: ${BRAND.phones.join(' / ')}`),
      el('br'),
      el('span', null, `${t('Address', 'አድራሻ')}: ${BRAND.address}`),
    ]),
  )
}

const DOCS = {
  about,
  privacy,
  terms,
  support,
}

/* ================================ about ================================ */

/**
 * The three pillars. Titles and bullet labels are verbatim from the original;
 * the bodies replace prose that used to arrive from the server.
 */
const pillars = () => [
  {
    icon: 'stethoscope',
    title: t('Core Healthcare Services', 'ዋና የጤና አገልግሎቶች'),
    body: t(
      'Consultations run over video, audio or text, whichever the patient can manage on the connection they have. A session is twenty minutes with a licensed physician, booked in advance, with prescriptions and referrals issued the same day.',
      'ምክክሮች በቪዲዮ፣ በድምጽ ወይም በጽሑፍ ይካሄዳሉ — ታካሚው በኔትወርኩ በሚችለው መንገድ። እያንዳንዱ ክፍለ ጊዜ ከፍቃድ ካለው ሐኪም ጋር ሃያ ደቂቃ ሲሆን አስቀድሞ ይያዛል፤ ማዘዣና ሪፈራል በዚያኑ ዕለት ይሰጣል።',
    ),
    points: [
      t('Digital consultation', 'ዲጂታል ምክክር'),
      t('Clinical triage', 'የሕክምና ትሪያጅ'),
      t('Specialist appointments', 'የስፔሻሊስት ቀጠሮ'),
      t('Online prescriptions', 'የኦንላይን ማዘዣ'),
    ],
  },
  {
    icon: 'users',
    title: t('Human Resources & Medical Staffing', 'የሰው ኃይል እና የሕክምና ቡድን'),
    body: t(
      'Every doctor on the platform is licensed and practising. The team covers general medicine, paediatrics and several specialties, and consults in Amharic, Tigrinya and English so that language is not one more barrier between a patient and an answer.',
      'በመድረኩ ላይ ያለ እያንዳንዱ ሐኪም ፍቃድ ያለውና በሥራ ላይ ያለ ነው። ቡድኑ አጠቃላይ ሕክምናን፣ የሕፃናት ሕክምናንና በርካታ ስፔሻሊቲዎችን የሚሸፍን ሲሆን በአማርኛ፣ በትግርኛና በእንግሊዝኛ ያማክራል — ቋንቋ በታካሚና በመልስ መካከል ተጨማሪ እንቅፋት እንዳይሆን።',
    ),
    points: [
      t('Licensed physicians', 'ፍቃድ ያላቸው ሐኪሞች'),
      t('Pediatricians', 'የሕፃናት ሐኪሞች'),
      t('Specialists', 'ስፔሻሊስቶች'),
      t('Three-language care', 'በሶስት ቋንቋ አገልግሎት'),
    ],
  },
  {
    icon: 'activity',
    title: t('Future Strategic Vision', 'የወደፊት ስትራቴጂያዊ ራዕይ'),
    body: t(
      'The direction is wider reach rather than more features: telemedicine that works across the region, follow-up that does not depend on the patient remembering, and records a patient actually controls. Anything automated stays a support to a clinician’s judgement, never a replacement for it.',
      'አቅጣጫው ተጨማሪ ባህሪያት ሳይሆን ሰፊ ተደራሽነት ነው፦ በክልሉ ሁሉ የሚሠራ ቴሌሜዲስን፣ ታካሚው እንዲያስታውስ የማይጠይቅ ክትትል፣ እና ታካሚው በእውነት የሚቆጣጠረው መዝገብ። አውቶማቲክ የሆነው ሁሉ ለሐኪሙ ውሳኔ ድጋፍ እንጂ ምትክ አይሆንም።',
    ),
    points: [
      t('AI-assisted diagnostics', 'በ AI የሚታገዝ ምርመራ'),
      t('Regional telemedicine', 'የክልል ቴሌሜዲስን'),
      t('Automated monitoring', 'አውቶማቲክ ክትትል'),
      t('Secure records', 'ደህንነቱ የተጠበቀ መዝገብ'),
    ],
  },
]

function about() {
  return el('div', null, [
    pageHead(
      `${t('About', 'ስለ')} ${BRAND.nameFull}`,
      t('Multi-specialty telehealth, built for everyone.', 'ለሁሉም የተሰራ የብዙ-ስፔሻሊቲ የኦንላይን ሕክምና።'),
    ),

    el('div.container.stack-lg', null, [
      el('div.card.stack', null, [
        el('h2.section-title', null, t('Who we are', 'እኛ ማን ነን')),
        el('p', null, t(
          'Hakimm.com is a telehealth service based in Shire, Tigray, connecting patients across Ethiopia and the diaspora with licensed physicians. It began as a health education channel and grew into consultations because the questions people were asking in the comments deserved a private answer from someone qualified to give one.',
          'ሓኪም ዶት ኮም በሽሬ፣ ትግራይ የተመሠረተ የቴሌሔልዝ አገልግሎት ሲሆን በመላው ኢትዮጵያና በዲያስፖራ ያሉ ታካሚዎችን ከፍቃድ ካላቸው ሐኪሞች ጋር ያገናኛል። ጅማሬው የጤና ትምህርት ቻናል የነበረ ሲሆን ሰዎች በአስተያየት ሳጥን ውስጥ ይጠይቁ የነበሩት ጥያቄዎች ብቁ ከሆነ ባለሙያ የግል መልስ ስለሚገባቸው ወደ ምክክር አደገ።',
        )),
      ]),

      el('div.card-grid.card-grid--wide', null, pillars().map(pillar)),

      el('section.card.stack.ds-brand-gradient', null, [
        el('h2.section-title', null, t('Our mission', 'ተልዕኮአችን')),
        el('p', null, t(
          'That distance, cost and language should stop deciding who gets seen by a doctor. A consultation that would have meant a day of travel should take twenty minutes and a phone.',
          'ርቀት፣ ወጪና ቋንቋ ማን ሐኪም እንደሚያገኝ መወሰናቸው እንዲያበቃ። የአንድ ቀን ጉዞ ይጠይቅ የነበረ ምክክር በሃያ ደቂቃና በስልክ እንዲፈጸም።',
        )),
      ]),

      el('section.card.stack.center', null, [
        el('h2.section-title', null, t('We are ready', 'ዝግጁ ነን')),
        el('p.text-muted', null, t(
          'Book an appointment with a licensed professional, or contact us directly.',
          'ከፍቃድ ካለው ባለሙያ ጋር ቀጠሮ ይያዙ ወይም በቀጥታ ያግኙን።',
        )),
        el('div.form-actions', null, [
          link('/booking', { class: 'ds-btn ds-btn-primary' }, [
            icon('calendar', { size: 16 }),
            el('span', null, t('Book an appointment', 'ቀጠሮ ይያዙ')),
          ]),
          link('/support', { class: 'ds-btn ds-btn-quiet' }, t('Contact us', 'ያግኙን')),
        ]),
        el('p.text-xs.text-muted', null, `${BRAND.email} · ${BRAND.phones.join(' · ')}`),
      ]),
    ]),
  ])
}

function pillar(entry) {
  return el('article.card.stack-sm.d3-tile', null, [
    el('span.tile__icon.ds-brand-gradient', null, icon(entry.icon, { size: 20 })),
    el('h3.section-title', null, entry.title),
    el('p.text-sm.text-muted', null, entry.body),
    el('ul.stack-sm', null, entry.points.map((point) =>
      el('li.row', null, [icon('check', { size: 14 }), el('span.text-sm', null, point)]),
    )),
  ])
}

/* =============================== privacy =============================== */

function privacy() {
  return el('div', null, [
    pageHead(t('Privacy Policy', 'የግላዊነት ፖሊሲ')),

    el('div.container.container-narrow.stack-lg', null, [
      el('p.text-sm.text-muted', null, lastUpdated()),

      el('div.card.stack-lg.prose', null, [
        section(
          t('Information We Collect', 'መረጃ መሰብሰብ'),
          el('p', null, t(
            'We collect personal information including name, email, phone number, and medical information when you register and book appointments.',
            'ምዝገባ እና ቀጠሮ ለመያዝ ስም፣ ኢሜል፣ ስልክ ቁጥር እና የሕክምና መረጃ እንሰበስባለን።',
          )),
        ),

        section(
          t('How We Use Your Information', 'መረጃ አጠቃቀም'),
          el('p', null, t(
            'Your information is used to provide medical consultation services, manage appointments, and communicate with you about your healthcare.',
            'መረጃዎ ለሕክምና ምክክር አገልግሎት ለማቅረብ፣ ቀጠሮዎችን ለማስተዳደር እና ከሕክምናዎ ጋር ለመገናኘት ይጠቅማል።',
          )),
        ),

        section(
          t('Data Security', 'የመረጃ ደህንነት'),
          el('p', null, t(
            'We implement appropriate security measures to protect your personal and medical information from unauthorized access.',
            'የእርስዎን ግላዊ እና ሕክምና መረጃ ለመጠበቅ ተገቢ የደህንነት እርምጃዎችን እንወስዳለን።',
          )),
        ),

        // Added, not inherited. This build keeps records in the browser instead
        // of on a server, which changes what the two paragraphs above mean in
        // practice — and a privacy policy that quietly omitted that would be
        // the wrong kind of faithful to the original.
        section(
          t('Where your records are kept', 'መዝገቦችዎ የት ይቀመጣሉ'),
          el('p', null, t(
            'On this version of the site, the details you enter — your account, bookings, messages and notes — are stored in your own browser and are not transmitted to us. We cannot read them, and we cannot restore them if you clear your browsing data or lose the device. Export a backup from your profile if you want a copy.',
            'በዚህ የጣቢያው ስሪት ላይ የሚያስገቡት ዝርዝሮች — መለያዎ፣ ቀጠሮዎችዎ፣ መልእክቶችዎና ማስታወሻዎችዎ — በራስዎ አሳሽ ውስጥ ይቀመጣሉ እንጂ ወደ እኛ አይተላለፉም። እኛ ልናነባቸው አንችልም፤ የአሳሽ መረጃዎን ካጸዱ ወይም መሣሪያዎን ካጡም ልንመልሳቸው አንችልም። ቅጂ ከፈለጉ ከመገለጫዎ ላይ መጠባበቂያ ያውጡ።',
          )),
          el('p', null, t(
            'What you send us by phone, email or Telegram to arrange or pay for a consultation reaches us the ordinary way and is handled as described above.',
            'ምክክር ለማዘጋጀት ወይም ለመክፈል በስልክ፣ በኢሜይል ወይም በቴሌግራም የሚልኩልን ግን በተለመደው መንገድ ይደርሰናል፤ ከላይ እንደተገለጸውም ይያዛል።',
          )),
        ),

        section(
          t('Confidentiality', 'ሚስጥራዊነት'),
          el('p', null, t(
            'All medical consultations are confidential. Your information will not be shared with third parties without your consent.',
            'ሁሉም የሕክምና ምክክሮች ሚስጥራዊ ናቸው። መረጃዎ ያለእርስዎ ፈቃድ ለሦስተኛ ወገን አይጋራም።',
          )),
        ),

        contactBlock(),
      ]),
    ]),
  ])
}

/* ================================ terms ================================ */

const fees = () => [
  t('Video Consultation: 1,000 ETB', 'የቪዲዮ ምክክር: 1,000 ብር'),
  t('Audio Consultation: 500 ETB', 'የድምጽ ምክክር: 500 ብር'),
  t('Text Consultation: 300 ETB', 'የጽሑፍ ምክክር: 300 ብር'),
]

function terms() {
  return el('div', null, [
    pageHead(t('Terms & Conditions', 'የአገልግሎት ውሎች')),

    el('div.container.container-narrow.stack-lg', null, [
      el('p.text-sm.text-muted', null, lastUpdated()),

      el('div.card.stack-lg.prose', null, [
        section(
          t('Service Description', 'የአገልግሎት ገለጻ'),
          el('p', null, t(
            'Hakimm.com provides digital medical consultation services through video, audio, and text channels.',
            'ሓኪም ዲጂታል የሕክምና ምክክር አገልግሎት ይሰጣል ቪዲዮ፣ ድምጽ እና ጽሑፍ በሚሉ ቻናሎች።',
          )),
        ),

        section(
          t('Appointments & Payment', 'ቀጠሮ እና ክፍያ'),
          el('p', null, t(
            'Consultations require advance payment via CBE Birr or TeleBirr. All sessions are strictly 20 minutes.',
            'ምክክሮች ቅድመ ክፍያ በCBE Birr ወይም TeleBirr ይጠይቃሉ። ሁሉም ክፍለ ጊዜዎች 20 ደቂቃ ናቸው።',
          )),
          el('ul', null, fees().map((fee) => el('li', null, fee))),
        ),

        section(
          t('Cancellation Policy', 'ስረዛ ፖሊሲ'),
          el('p', null, t(
            'Appointments may be cancelled up to 24 hours in advance. Late cancellations are not eligible for refunds.',
            'ቀጠሮዎችን ከ24 ሰዓት በፊት መሰረዝ ይቻላል። ዘግይቶ ስረዛ ገንዘብ ተመላሽ አያስገኝም።',
          )),
        ),

        section(
          t('Medical Disclaimer', 'የሕክምና ማስጠንቀቂያ'),
          el('div.notice.notice--danger', null, [
            icon('alert', { size: 16 }),
            el('span', null, t(
              'Digital consultations are not intended for emergency situations. For emergencies, please visit the nearest hospital.',
              'ዲጂታል ምክክር ለአደጋ ጊዜ አገልግሎት የታሰበ አይደለም። ለድንገተኛ ሁኔታ የቅርብ ሆስፒታል ይሂዱ።',
            )),
          ]),
        ),

        contactBlock(t('Contact', 'አግኙን')),
      ]),
    ]),
  ])
}

/* =============================== support =============================== */

const DONATION_ACCOUNTS = [
  { method: 'CBE Birr', holder: 'Biruk Zenebe', number: '0914557706' },
  { method: 'TeleBirr', holder: 'Biruk Zenebe', number: '0986935583' },
]

function support() {
  return el('div', null, [
    pageHead(
      t('Support & Donate', 'ድጋፍ እና ልገሳ'),
      t(
        'Support Hakimm.com Health Tips channel and help spread health education',
        'ለሓኪም የጤና ምክሮች ቻናል ይለግሱ',
      ),
    ),

    el('div.container.container-narrow.stack-lg', null, [
      el('div.card.stack.center', null, [
        el('span.tile__icon.ds-brand-gradient', null, icon('heart', { size: 22, fill: 'currentColor' })),
        el('h2.section-title', null, t('Donate for the Channel', 'ለቻናሉ ይለግሱ')),
        el('p.text-muted', null, t(
          'Your donation helps Hakimm.com continue providing free health education content. Any amount is appreciated!',
          'የእርስዎ ልገሳ ሓኪም ነፃ የጤና ትምህርት ይዘት ማቅረቡን ለመቀጠል ይረዳል። ማንኛውም መጠን ይቀበላል!',
        )),

        el('div.stat-row', null, DONATION_ACCOUNTS.map((account) =>
          el('div.stat', null, [
            el('div.stat__label', null, account.method),
            el('div.text-xs.text-muted', null, account.holder),
            el('div.stat__value.mono', null, account.number),
          ]),
        )),

        el('p.text-sm.text-muted', null, `${t('Phone', 'ስልክ')}: ${BRAND.phones.join(' / ')}`),
      ]),

      el('div.card.stack.center', null, [
        el('h2.section-title', null, t('Other Ways to Support', 'ሌላ መንገድ ይደግፉ')),
        el('div.form-actions', null, [
          el(
            'a.ds-btn.ds-btn-quiet',
            { href: BRAND.facebook, target: '_blank', rel: 'noopener noreferrer' },
            t('Follow on Facebook', 'ፌስቡክ ላይ ይከተሉ'),
          ),
          el(
            'a.ds-btn.ds-btn-quiet',
            { href: BRAND.youtube, target: '_blank', rel: 'noopener noreferrer' },
            t('Subscribe on YouTube', 'ዩቲዩብ ላይ ይመዝገቡ'),
          ),
        ]),
        link('/register', { class: 'ds-btn ds-btn-primary' }, [
          el('span', null, t('Register and become a member', 'ተመዝገቡ እና አባል ይሁኑ')),
          icon('chevronRight', { size: 16 }),
        ]),
      ]),

      contactBlock(),
    ]),
  ])
}
