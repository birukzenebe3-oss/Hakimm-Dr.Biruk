/**
 * Profile and device settings.
 *
 * Replaces `src/routes/profile.tsx` plus the account server functions. It also
 * absorbs a responsibility the React build never had to think about: when the
 * database is the browser, the user is the only backup. Export and import are
 * therefore first-class here rather than a hidden admin tool — a cleared site
 * data setting is all it takes to lose the lot, and the page says so.
 */

import { t } from '../i18n.js'
import { avatar, el, field, icon, modal, toast } from '../ui.js'
import { changePassword, currentUser, deviceId, signOut, updateProfile } from '../auth.js'
import { COLLECTIONS, all, clear, exportAll, importAll } from '../store.js'
import { link, navigate, refresh } from '../router.js'
import { pageHead, signInGate } from './_shared.js'

export async function render() {
  const user = currentUser()

  if (!user) {
    return el('div.container.section', null, [
      signInGate(t('Sign in to see your profile.', 'መገለጫዎን ለማየት ይግቡ።')),
    ])
  }

  const root = el('div')
  const body = el('div.container.stack-lg')

  root.append(
    pageHead(t('My profile', 'የእኔ መገለጫ'), t('Your details, your data, and this device.', 'ዝርዝሮችዎ፣ መረጃዎ እና ይህ መሣሪያ።')),
    body,
  )

  async function draw() {
    const me = currentUser()
    const counts = await recordCounts()

    body.replaceChildren(
      el('div.card.row-wrap', null, [
        avatar(me, { size: 'lg' }),
        el('div.stack-sm', null, [
          el('h2.doc-card__name', null, me.name),
          el('p.text-sm.text-muted', null, me.email),
          me.phone ? el('p.text-sm.text-muted', null, me.phone) : null,
        ]),
      ]),

      detailsCard(me),
      passwordCard(),
      dataCard(counts),

      el('div.form-actions', null, [
        link('/appointments', { class: 'ds-btn ds-btn-quiet' }, t('My appointments', 'ቀጠሮዎቼ')),
        link('/wallet', { class: 'ds-btn ds-btn-quiet' }, t('MedCoin wallet', 'ሜድኮይን ቦርሳ')),
        el(
          'button.ds-btn.ds-btn-quiet',
          {
            type: 'button',
            onclick: () => {
              signOut()
              toast(t('Signed out', 'ወጥተዋል'), 'success')
              navigate('/')
            },
          },
          [icon('logout', { size: 16 }), el('span', null, t('Sign out', 'ውጣ'))],
        ),
      ]),

      el('div.notice', null, [
        icon('info', { size: 16 }),
        el('span', null, t(
          `Device id ${deviceId().slice(0, 8)} — used to keep your records apart from another account on this browser. It is not sent anywhere.`,
          `የመሣሪያ መለያ ${deviceId().slice(0, 8)} — በዚህ አሳሽ ላይ ካለ ሌላ መለያ መዝገቦችዎን ለመለየት ይጠቅማል። ወደ ማንም አይላክም።`,
        )),
      ]),
    )
  }

  /* ---------- details ---------- */

  function detailsCard(me) {
    const nameInput = el('input.input', { type: 'text', value: me.name, autocomplete: 'name' })
    const phoneInput = el('input.input', { type: 'tel', value: me.phone || '', autocomplete: 'tel', placeholder: '+251…' })

    const form = el(
      'form.stack',
      {
        novalidate: true,
        onsubmit: async (event) => {
          event.preventDefault()
          try {
            await updateProfile({ name: nameInput.value.trim(), phone: phoneInput.value.trim() })
            toast(t('Profile updated', 'መገለጫው ተዘምኗል'), 'success')
            // The header shows the name and avatar, so the shell has to hear
            // about this too.
            refresh()
            draw()
          } catch (err) {
            toast(err.message || String(err), 'error')
          }
        },
      },
      [
        field({ label: t('Full name', 'ሙሉ ስም'), input: nameInput }),
        field({ label: t('Phone', 'ስልክ'), input: phoneInput }),
        el('div.form-actions', null, [
          el('button.ds-btn.ds-btn-primary', { type: 'submit' }, t('Save changes', 'ለውጦችን አስቀምጥ')),
        ]),
      ],
    )

    return el('div.card.stack', null, [el('h2.section-title', null, t('Details', 'ዝርዝሮች')), form])
  }

  /* ---------- password ---------- */

  function passwordCard() {
    const currentInput = el('input.input', { type: 'password', autocomplete: 'current-password' })
    const nextInput = el('input.input', { type: 'password', autocomplete: 'new-password', minlength: '8' })

    const form = el(
      'form.stack',
      {
        novalidate: true,
        onsubmit: async (event) => {
          event.preventDefault()
          try {
            await changePassword({ current: currentInput.value, next: nextInput.value })
            currentInput.value = ''
            nextInput.value = ''
            toast(t('Password changed', 'የይለፍ ቃሉ ተቀይሯል'), 'success')
          } catch (err) {
            toast(err.message || String(err), 'error')
          }
        },
      },
      [
        field({ label: t('Current password', 'የአሁኑ የይለፍ ቃል'), input: currentInput }),
        field({
          label: t('New password', 'አዲስ የይለፍ ቃል'),
          hint: t('At least 8 characters.', 'ቢያንስ 8 ቁምፊዎች።'),
          input: nextInput,
        }),
        el('div.form-actions', null, [
          el('button.ds-btn.ds-btn-quiet', { type: 'submit' }, t('Change password', 'የይለፍ ቃል ቀይር')),
        ]),
      ],
    )

    return el('div.card.stack', null, [el('h2.section-title', null, t('Password', 'የይለፍ ቃል')), form])
  }

  /* ---------- backup, restore, erase ---------- */

  async function recordCounts() {
    let total = 0
    for (const name of COLLECTIONS) total += (await all(name)).length
    return total
  }

  function dataCard(total) {
    const fileInput = el('input', {
      type: 'file',
      accept: 'application/json',
      style: { display: 'none' },
      onchange: async (event) => {
        const file = event.target.files?.[0]
        event.target.value = ''
        if (!file) return

        const confirmed = await modal({
          title: t('Restore from backup?', 'ከመጠባበቂያ ይመለስ?'),
          description: t(
            'Everything currently on this device is replaced by the contents of the file. This cannot be undone.',
            'በአሁኑ ጊዜ በዚህ መሣሪያ ላይ ያለው ሁሉ በፋይሉ ይዘት ይተካል። ይህ አይመለስም።',
          ),
          actions: (close) => [
            el('button.ds-btn.ds-btn-quiet', { type: 'button', onclick: () => close(false) }, t('Cancel', 'ተወው')),
            el('button.ds-btn.ds-btn-primary', { type: 'button', onclick: () => close(true) }, t('Replace and restore', 'ተካና መልስ')),
          ],
        })
        if (!confirmed) return

        try {
          await importAll(JSON.parse(await file.text()))
          toast(t('Backup restored', 'መጠባበቂያው ተመልሷል'), 'success')
          draw()
        } catch (err) {
          toast(err.message || String(err), 'error')
        }
      },
    })

    return el('div.card.stack', null, [
      el('h2.section-title', null, t('Your data', 'የእርስዎ መረጃ')),

      el('p.text-sm.text-muted', null, t(
        `${total} records are stored in this browser. Clearing site data — or using a private window — removes them permanently.`,
        `${total} መዝገቦች በዚህ አሳሽ ውስጥ ተቀምጠዋል። የጣቢያውን መረጃ ማጽዳት — ወይም የግል መስኮት መጠቀም — በቋሚነት ያስወግዳቸዋል።`,
      )),

      el('div.form-actions', null, [
        el(
          'button.ds-btn.ds-btn-primary',
          {
            type: 'button',
            onclick: async (event) => {
              const button = event.currentTarget
              button.disabled = true
              try {
                await downloadBackup()
              } catch (err) {
                toast(err.message || String(err), 'error')
              } finally {
                button.disabled = false
              }
            },
          },
          [icon('download', { size: 16 }), el('span', null, t('Download backup', 'መጠባበቂያ አውርድ'))],
        ),
        el('button.ds-btn.ds-btn-quiet', { type: 'button', onclick: () => fileInput.click() }, [
          icon('upload', { size: 16 }),
          el('span', null, t('Restore from file', 'ከፋይል መልስ')),
        ]),
        el('button.ds-btn.ds-btn-quiet', { type: 'button', onclick: eraseEverything }, [
          icon('alert', { size: 16 }),
          el('span', null, t('Erase all data', 'ሁሉንም መረጃ አጥፋ')),
        ]),
        fileInput,
      ]),
    ])
  }

  async function downloadBackup() {
    const payload = await exportAll()
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const stamp = new Date().toISOString().slice(0, 10)

    const anchor = el('a', { href: url, download: `hakimm-backup-${stamp}.json` })
    document.body.append(anchor)
    anchor.click()
    anchor.remove()

    // Give the download a tick to start before the blob is reclaimed.
    setTimeout(() => URL.revokeObjectURL(url), 10_000)
    toast(t('Backup downloaded', 'መጠባበቂያው ወርዷል'), 'success')
  }

  async function eraseEverything() {
    const typed = el('input.input', { type: 'text', placeholder: 'ERASE' })

    const confirmed = await modal({
      title: t('Erase everything on this device?', 'በዚህ መሣሪያ ላይ ያለው ሁሉ ይጥፋ?'),
      description: t(
        'Appointments, messages, ledger entries and your account are deleted. Type ERASE to confirm. Download a backup first if you might want any of it back.',
        'ቀጠሮዎች፣ መልእክቶች፣ የመዝገብ ግቤቶች እና መለያዎ ይሰረዛሉ። ለማረጋገጥ ERASE ብለው ይጻፉ። መልሰው ሊፈልጉት ከሆነ መጀመሪያ መጠባበቂያ ያውርዱ።',
      ),
      body: () => field({ label: t('Type ERASE', 'ERASE ብለው ይጻፉ'), input: typed }),
      actions: (close) => [
        el('button.ds-btn.ds-btn-quiet', { type: 'button', onclick: () => close(false) }, t('Cancel', 'ተወው')),
        el('button.ds-btn.ds-btn-primary', { type: 'button', onclick: () => close(true) }, t('Erase', 'አጥፋ')),
      ],
    })

    if (!confirmed) return

    if (typed.value.trim().toUpperCase() !== 'ERASE') {
      toast(t('Nothing was erased.', 'ምንም አልተጠፋም።'), 'info')
      return
    }

    for (const name of COLLECTIONS) await clear(name)
    signOut()
    toast(t('All data erased', 'ሁሉም መረጃ ጠፍቷል'), 'success')
    navigate('/')
  }

  await draw()
  return root
}
