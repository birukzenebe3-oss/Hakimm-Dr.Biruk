/**
 * Not found.
 *
 * Replaces `src/routes/__404.tsx`. This one earns its own module for a reason
 * specific to static hosting: GitHub Pages and Cloudflare Pages serve
 * `404.html` for any path they cannot resolve, which is how deep links reach
 * the router at all. So a genuinely unknown path and a valid deep link both
 * arrive here first — the router re-matches, and only what it still cannot
 * place ends up rendering this page.
 */

import { t } from '../i18n.js'
import { el, icon } from '../ui.js'
import { link } from '../router.js'
import { pageHead } from './_shared.js'

const SUGGESTIONS = () => [
  { to: '/doctors', label: t('Find a doctor', 'ሐኪም ያግኙ'), icon: 'stethoscope' },
  { to: '/booking', label: t('Book an appointment', 'ቀጠሮ ይያዙ'), icon: 'calendar' },
  { to: '/health-feed', label: t('Health feed', 'የጤና መረጃ'), icon: 'news' },
  { to: '/support', label: t('Contact support', 'ድጋፍ ያግኙ'), icon: 'phone' },
]

export async function render() {
  return el('div', null, [
    pageHead(
      t('Page not found', 'ገጹ አልተገኘም'),
      t(
        'The address may have changed, or the link may have been mistyped.',
        'አድራሻው ተቀይሮ ሊሆን ይችላል፣ ወይም ማገናኛው በስህተት ተጽፎ ሊሆን ይችላል።',
      ),
    ),

    el('div.container.stack-lg', null, [
      el('p.text-sm.text-muted.mono', null, location.pathname),

      el('div.card-grid', null, SUGGESTIONS().map((item) =>
        link(item.to, { class: 'tile d3-tile' }, [
          el('span.tile__icon.ds-brand-gradient', null, icon(item.icon, { size: 18 })),
          el('span.tile__label', null, item.label),
        ]),
      )),

      el('div.form-actions', null, [
        link('/', { class: 'ds-btn ds-btn-primary' }, t('Back to home', 'ወደ መነሻ ተመለስ')),
        el(
          'button.ds-btn.ds-btn-quiet',
          { type: 'button', onclick: () => history.back() },
          [icon('arrowLeft', { size: 16 }), el('span', null, t('Go back', 'ተመለስ'))],
        ),
      ]),
    ]),
  ])
}
