/**
 * Doctor directory.
 *
 * Replaces `src/routes/doctors.tsx`, which fetched an approved-doctor list
 * through a server function and cached it in `useDoctors.ts` under
 * `doctors_approved_v2` with a 15-minute TTL. Reading straight from IndexedDB
 * removes both the request and the cache-invalidation problem.
 *
 * The `?q=` parameter is preserved because the site's structured data
 * advertises `/doctors?q={search_term_string}` as its search action.
 */

import { all } from '../store.js'
import { t } from '../i18n.js'
import { el, empty, skeletonCards } from '../ui.js'
import { doctorCard, doctorName, doctorSpecialty, pageHead } from './_shared.js'

export async function render({ search }) {
  const root = el('div')

  let doctors = []
  let term = search.get('q') || ''
  let specialty = search.get('specialty') || ''

  const results = el('div.card-grid', null, skeletonCards(6, '9rem'))
  const chipRow = el('div.chips', { role: 'group', 'aria-label': t('Filter by specialty', 'በሙያ አጣራ') })
  const count = el('p.section-sub')

  const searchInput = el('input.input', {
    type: 'search',
    value: term,
    placeholder: t('Search by name or specialty…', 'በስም ወይም በሙያ ይፈልጉ…'),
    'aria-label': t('Search professionals', 'ባለሙያዎችን ይፈልጉ'),
    oninput: (event) => {
      term = event.target.value
      apply()
      syncUrl()
    },
  })

  root.append(
    pageHead(
      t('Health professionals', 'የጤና ባለሙያዎች'),
      t(
        'Verified doctors and specialists accepting online consultations.',
        'የመስመር ላይ ምክክር የሚቀበሉ የተረጋገጡ ዶክተሮች እና ባለሙያዎች።',
      ),
    ),
    el('div.container.stack', null, [searchInput, chipRow, count, results]),
  )

  /** Keeps the URL shareable without pushing a history entry per keystroke. */
  function syncUrl() {
    const params = new URLSearchParams()
    if (term) params.set('q', term)
    if (specialty) params.set('specialty', specialty)
    const query = params.toString()
    history.replaceState(history.state, '', query ? `?${query}` : location.pathname)
  }

  function apply() {
    const needle = term.trim().toLowerCase()

    const filtered = doctors.filter((doctor) => {
      if (specialty && doctor.specialization !== specialty) return false
      if (!needle) return true
      return [doctor.name, doctor.nameAm, doctor.specialization, doctor.specializationAm, doctor.bio]
        .filter(Boolean)
        .some((field) => String(field).toLowerCase().includes(needle))
    })

    count.textContent = t(
      `${filtered.length} of ${doctors.length} professionals`,
      `ከ${doctors.length} ባለሙያዎች ${filtered.length}`,
    )

    results.replaceChildren(
      ...(filtered.length
        ? filtered.map((doctor) => doctorCard(doctor))
        : [
            empty(
              t('No professionals match that search.', 'ከዚህ ፍለጋ ጋር የሚዛመድ ባለሙያ የለም።'),
              'search',
            ),
          ]),
    )
  }

  function buildChips() {
    // Specialties come from the records themselves rather than a fixed list,
    // so adding a doctor to seed.json adds their filter with no code change.
    const specialties = [...new Set(doctors.map((doctor) => doctor.specialization).filter(Boolean))].sort()

    const chip = (value, label) =>
      el(
        'button.chip',
        {
          type: 'button',
          'aria-pressed': specialty === value ? 'true' : 'false',
          onclick: () => {
            specialty = specialty === value ? '' : value
            buildChips()
            apply()
            syncUrl()
          },
        },
        label,
      )

    chipRow.replaceChildren(
      chip('', t('All', 'ሁሉም')),
      ...specialties.map((value) => {
        const sample = doctors.find((doctor) => doctor.specialization === value)
        return chip(value, doctorSpecialty(sample))
      }),
    )
  }

  try {
    doctors = await all('doctors')
    doctors.sort((a, b) => Number(b.isOnline) - Number(a.isOnline) || doctorName(a).localeCompare(doctorName(b)))
    buildChips()
    apply()
  } catch (err) {
    console.error('[doctors] load failed', err)
    results.replaceChildren(empty(t('Could not load the directory.', 'ዝርዝሩን መጫን አልተቻለም።'), 'alert'))
  }

  return root
}
