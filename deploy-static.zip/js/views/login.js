/**
 * Sign in.
 *
 * Replaces `src/routes/login.tsx`, which posted to a server function that
 * signed a JWT with `jsonwebtoken`. Verification now happens in the browser
 * against a PBKDF2 hash held in IndexedDB — see the header of `js/auth.js` for
 * why that is a convenience feature and not an authorisation boundary, and why
 * the admin console is deliberately absent from this build.
 */

import { t } from '../i18n.js'
import { el, field, icon, toast } from '../ui.js'
import { isSignedIn, signIn } from '../auth.js'
import { link, navigate } from '../router.js'

export async function render({ search }) {
  const next = search.get('next') || '/profile'

  if (isSignedIn()) {
    navigate(next)
    return el('div')
  }

  const emailInput = el('input.input', {
    type: 'email',
    required: true,
    autocomplete: 'email',
    autocapitalize: 'off',
    spellcheck: false,
  })
  const passwordInput = el('input.input', { type: 'password', required: true, autocomplete: 'current-password' })
  const error = el('div')

  const form = el(
    'form.card.stack',
    {
      novalidate: true,
      onsubmit: async (event) => {
        event.preventDefault()
        const button = form.querySelector('button[type=submit]')
        button.disabled = true
        error.replaceChildren()

        try {
          const user = await signIn({ email: emailInput.value, password: passwordInput.value })
          toast(t(`Welcome back, ${user.name.split(' ')[0]}`, `እንኳን ደህና መጡ፣ ${user.name.split(' ')[0]}`), 'success')
          navigate(next)
        } catch (err) {
          error.replaceChildren(
            el('div.notice.notice--danger', null, [icon('alert', { size: 16 }), el('span', null, err.message || String(err))]),
          )
          button.disabled = false
          passwordInput.focus()
        }
      },
    },
    [
      field({ label: t('Email', 'ኢሜይል'), input: emailInput }),
      field({ label: t('Password', 'የይለፍ ቃል'), input: passwordInput }),
      error,
      el('div.form-actions', null, [
        el('button.ds-btn.ds-btn-primary.ds-btn--block', { type: 'submit' }, t('Sign in', 'ግባ')),
      ]),
    ],
  )

  return el('div.container.container-narrow.section.stack', null, [
    el('div.stack-sm', null, [
      el('h1.page-title', null, t('Sign in', 'ግባ')),
      el('p.page-lede', null, t(
        'Your account is stored on this device so your bookings and messages stay together.',
        'መለያዎ በዚህ መሣሪያ ላይ ስለሚቀመጥ ቀጠሮዎችዎ እና መልእክቶችዎ አብረው ይቆያሉ።',
      )),
    ]),

    form,

    el('div.notice', null, [
      icon('info', { size: 16 }),
      el('span', null, t(
        'Accounts are per-device. Signing in on another phone or browser will not carry your history across — export it from your profile first.',
        'መለያዎች ለእያንዳንዱ መሣሪያ የተለዩ ናቸው። በሌላ ስልክ ወይም አሳሽ መግባት ታሪክዎን አያመጣም — መጀመሪያ ከመገለጫዎ ላይ ያውጡት።',
      )),
    ]),

    el('p.center.text-sm', null, [
      el('span', null, t('No account yet? ', 'መለያ የለዎትም? ')),
      link(`/register?next=${encodeURIComponent(next)}`, null, t('Create one', 'ይፍጠሩ')),
    ]),
  ])
}
