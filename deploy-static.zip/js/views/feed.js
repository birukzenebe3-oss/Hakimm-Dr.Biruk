/**
 * Health feed.
 *
 * Replaces `src/routes/health-feed.tsx` and the `feed-posts` / `social` blob
 * stores behind it. Articles ship in `data/seed.json`; likes and saves are
 * local flags rather than shared counters, because a counter that only this
 * browser can increment would be a lie told with a number.
 */

import { all, prefs } from '../store.js'
import { formatDate, t } from '../i18n.js'
import { el, empty, icon, skeletonCards } from '../ui.js'
import { link } from '../router.js'
import { pageHead, sectionHead } from './_shared.js'

const LIKES_KEY = 'liked-posts'

export function likedPosts() {
  return new Set(prefs.get(LIKES_KEY, []))
}

function toggleLike(id) {
  const liked = likedPosts()
  liked.has(id) ? liked.delete(id) : liked.add(id)
  prefs.set(LIKES_KEY, [...liked])
  return liked.has(id)
}

export function postTitle(post) {
  return t(post.title, post.titleAm || post.title)
}

export async function render({ search }) {
  const root = el('div')
  const list = el('div.feed-list', null, skeletonCards(4, '8rem'))
  const chipRow = el('div.chips', { role: 'group', 'aria-label': t('Filter by category', 'በምድብ አጣራ') })

  let category = search.get('category') || ''
  let posts = []

  root.append(
    pageHead(
      t('Health feed', 'የጤና መረጃ'),
      t(
        'Practical guidance written by the professionals on the platform.',
        'በመድረኩ ላይ ባሉ ባለሙያዎች የተጻፈ ተግባራዊ መመሪያ።',
      ),
    ),
    el('div.container.stack', null, [chipRow, list]),
  )

  function apply() {
    const filtered = category ? posts.filter((post) => post.category === category) : posts

    list.replaceChildren(
      ...(filtered.length
        ? filtered.map(postCard)
        : [empty(t('Nothing in this category yet.', 'በዚህ ምድብ ውስጥ እስካሁን ምንም የለም።'), 'news')]),
    )
  }

  function buildChips() {
    const categories = [...new Set(posts.map((post) => post.category).filter(Boolean))].sort()

    const chip = (value, label) =>
      el(
        'button.chip',
        {
          type: 'button',
          'aria-pressed': category === value ? 'true' : 'false',
          onclick: () => {
            category = category === value ? '' : value
            buildChips()
            apply()
            history.replaceState(history.state, '', category ? `?category=${encodeURIComponent(category)}` : location.pathname)
          },
        },
        label,
      )

    chipRow.replaceChildren(chip('', t('All', 'ሁሉም')), ...categories.map((value) => chip(value, value)))
  }

  try {
    posts = (await all('feed-posts')).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))
    buildChips()
    apply()
  } catch (err) {
    console.error('[feed] load failed', err)
    list.replaceChildren(empty(t('Could not load the feed.', 'መረጃውን መጫን አልተቻለም።'), 'alert'))
  }

  return root
}

/** Card used both here and by the home page preview. */
export function postCard(post) {
  const liked = likedPosts().has(post.id)

  const likeButton = el(
    'button',
    {
      type: 'button',
      class: liked ? 'is-on' : '',
      'aria-pressed': liked ? 'true' : 'false',
      onclick: (event) => {
        event.preventDefault()
        event.stopPropagation()
        const now = toggleLike(post.id)
        likeButton.classList.toggle('is-on', now)
        likeButton.setAttribute('aria-pressed', now ? 'true' : 'false')
      },
    },
    [icon('heart', { size: 14, fill: liked ? 'currentColor' : 'none' }), el('span', null, t('Save', 'አስቀምጥ'))],
  )

  return el('article.post', null, [
    link(`/post/${encodeURIComponent(post.id)}`, { class: 'post__body' }, [
      el('h2.post__title', null, postTitle(post)),
      el('p.post__excerpt', null, post.excerpt || ''),
    ]),

    el('div.post__foot', null, [
      post.category ? el('span.pill.pill--muted', null, post.category) : null,
      el('span', null, t(`${post.readMinutes || 4} min read`, `${post.readMinutes || 4} ደቂቃ ንባብ`)),
      el('span.spacer'),
      el('span', null, formatDate(post.createdAt)),
      likeButton,
    ]),
  ])
}

/** Compact list used by other views that want a few recent articles. */
export function recentPosts(posts, limit = 3) {
  return el('section.container.section', null, [
    sectionHead(t('From the health feed', 'ከጤና መረጃው'), { more: '/health-feed' }),
    el('div.feed-list', null, posts.slice(0, limit).map(postCard)),
  ])
}
