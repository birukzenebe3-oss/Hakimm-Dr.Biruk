/**
 * Browser-native persistence layer.
 *
 * The React build kept every mutable record in Netlify Blobs behind ~380
 * TanStack Start server functions — 42 named stores (`medcoin`, `doctors`,
 * `appointments`, …), each reached over an authenticated `POST /_serverFn/*`
 * round-trip. None of that can exist in a static bundle, so the same store
 * model is reproduced here directly on IndexedDB: one object store per
 * collection, keyed by record id, with the same "read the collection, mutate,
 * write it back" shape the server helpers used.
 *
 * IndexedDB rather than `localStorage` because the collections that matter
 * (chat history, feed posts, ledger entries) are unbounded and localStorage's
 * ~5 MB synchronous budget is shared with everything else on the origin.
 * `localStorage` is still used, via `prefs`, for the handful of small values
 * that must be readable synchronously during the first paint — language and
 * session — so the header does not flash the wrong state.
 */

const DB_NAME = 'hakimm'
const DB_VERSION = 1

/**
 * Collections. Mirrors the blob-store names the server functions used so a
 * record exported from the old backend drops straight in.
 */
export const COLLECTIONS = [
  'doctors',
  'patients',
  'appointments',
  'chats',
  'messages',
  'feed-posts',
  'videos',
  'notifications',
  'medcoin',
  'medcoin-tx',
  'p2p-orders',
  'reviews',
  'settings',
]

let dbPromise = null

function openDb() {
  if (dbPromise) return dbPromise

  dbPromise = new Promise((resolve, reject) => {
    // Private-mode Safari and hardened browser profiles can refuse to open a
    // database at all. Callers get a rejected promise and fall back to the
    // seeded read-only view rather than a broken page.
    let request
    try {
      request = indexedDB.open(DB_NAME, DB_VERSION)
    } catch (err) {
      reject(err)
      return
    }

    request.onupgradeneeded = () => {
      const db = request.result
      for (const name of COLLECTIONS) {
        if (!db.objectStoreNames.contains(name)) {
          db.createObjectStore(name, { keyPath: 'id' })
        }
      }
    }

    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error)
    request.onblocked = () => reject(new Error('IndexedDB upgrade blocked by another tab'))
  })

  return dbPromise
}

function tx(collection, mode, run) {
  return openDb().then(
    (db) =>
      new Promise((resolve, reject) => {
        const transaction = db.transaction(collection, mode)
        const store = transaction.objectStore(collection)
        let result
        try {
          result = run(store)
        } catch (err) {
          reject(err)
          return
        }
        transaction.oncomplete = () => resolve(result && result.value !== undefined ? result.value : result)
        transaction.onerror = () => reject(transaction.error)
        transaction.onabort = () => reject(transaction.error)
      }),
  )
}

/** Wrap an IDBRequest so the enclosing transaction promise can read its result. */
function box(request) {
  const holder = { value: undefined }
  request.onsuccess = () => {
    holder.value = request.result
  }
  return holder
}

/* ============================ CRUD ============================ */

/** Every record in a collection. */
export async function all(collection) {
  try {
    return (await tx(collection, 'readonly', (store) => box(store.getAll()))) || []
  } catch {
    return []
  }
}

/** One record by id, or `null`. */
export async function get(collection, id) {
  try {
    return (await tx(collection, 'readonly', (store) => box(store.get(id)))) || null
  } catch {
    return null
  }
}

/**
 * Insert or replace. Generates an id and `createdAt` when absent so callers can
 * hand over a bare object the way they did with the server helpers.
 */
export async function put(collection, record) {
  const row = {
    ...record,
    id: record.id || newId(),
    createdAt: record.createdAt || new Date().toISOString(),
  }
  await tx(collection, 'readwrite', (store) => store.put(row))
  return row
}

/** Shallow-merge a patch into an existing record. No-op if it is gone. */
export async function patch(collection, id, changes) {
  const current = await get(collection, id)
  if (!current) return null
  return put(collection, { ...current, ...changes, id })
}

export async function remove(collection, id) {
  await tx(collection, 'readwrite', (store) => store.delete(id))
}

export async function clear(collection) {
  await tx(collection, 'readwrite', (store) => store.clear())
}

/** Records matching a predicate, newest first. */
export async function query(collection, predicate) {
  const rows = await all(collection)
  const matched = predicate ? rows.filter(predicate) : rows
  return matched.sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')))
}

/* ============================ IDS ============================ */

/**
 * Collision-resistant id. `crypto.randomUUID` is the browser's own — this is
 * deliberately not Node's `crypto` module, which the static build must not
 * reference. Older WebViews (a meaningful slice of this audience) lack
 * `randomUUID` but do have `getRandomValues`.
 */
export function newId() {
  if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID()
  if (globalThis.crypto?.getRandomValues) {
    const bytes = globalThis.crypto.getRandomValues(new Uint8Array(16))
    return Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('')
  }
  return `id-${Date.now().toString(36)}-${Math.floor(Math.random() * 1e9).toString(36)}`
}

/* ============================ PREFS ============================ */

const PREFIX = 'hakimm:'

/**
 * Small synchronous values (language, session, dismissed banners). Wrapped
 * because `localStorage` throws outright in some privacy modes, and a throwing
 * preference read must not take the whole app down.
 */
export const prefs = {
  get(key, fallback = null) {
    try {
      const raw = localStorage.getItem(PREFIX + key)
      return raw === null ? fallback : JSON.parse(raw)
    } catch {
      return fallback
    }
  },
  set(key, value) {
    try {
      localStorage.setItem(PREFIX + key, JSON.stringify(value))
      return true
    } catch {
      return false
    }
  },
  remove(key) {
    try {
      localStorage.removeItem(PREFIX + key)
    } catch {
      /* storage unavailable — nothing to remove */
    }
  },
}

/* ============================ SEEDING ============================ */

/**
 * Load `data/seed.json` into empty collections on first run.
 *
 * Only empty ones: a returning visitor's own appointments and messages must
 * survive a deploy that ships new seed content. The version marker lets new
 * seed collections be introduced later without wiping what is already there.
 */
export async function seedOnce() {
  const SEED_KEY = 'seed-version'
  let seed
  try {
    const response = await fetch('data/seed.json', { cache: 'no-cache' })
    if (!response.ok) throw new Error(`seed fetch failed: ${response.status}`)
    seed = await response.json()
  } catch (err) {
    console.warn('[store] seed data unavailable', err)
    return false
  }

  const applied = prefs.get(SEED_KEY)
  if (applied === seed.version) return false

  for (const [collection, rows] of Object.entries(seed.collections || {})) {
    if (!COLLECTIONS.includes(collection)) continue
    const existing = await all(collection)
    if (existing.length > 0) continue
    for (const row of rows) await put(collection, row)
  }

  prefs.set(SEED_KEY, seed.version)
  return true
}

/**
 * Export every collection as one JSON blob — the static replacement for the
 * old `db-backup` Netlify Function. Data that lives only in the browser needs
 * a way out of it, or a cleared cache is permanent loss.
 */
export async function exportAll() {
  const collections = {}
  for (const name of COLLECTIONS) collections[name] = await all(name)
  return { version: 1, exportedAt: new Date().toISOString(), collections }
}

/** Restore an `exportAll()` payload, replacing whatever is stored now. */
export async function importAll(payload) {
  if (!payload || typeof payload !== 'object' || !payload.collections) {
    throw new Error('Not a valid Hakimm backup file')
  }
  for (const [collection, rows] of Object.entries(payload.collections)) {
    if (!COLLECTIONS.includes(collection) || !Array.isArray(rows)) continue
    await clear(collection)
    for (const row of rows) await put(collection, row)
  }
}
