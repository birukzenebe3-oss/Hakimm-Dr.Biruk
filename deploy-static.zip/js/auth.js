/**
 * Client-side session.
 *
 * The React build signed a JWT server-side with `jsonwebtoken` and a
 * `JWT_SECRET` env var, and `src/lib/auth.server.ts` additionally carried a
 * hard-coded admin email/password pair as a fallback. Neither can survive into
 * a static bundle: anything shipped to the browser is readable, so a secret
 * that lives here is not a secret, and a credential check that runs here is
 * not an authorisation decision.
 *
 * What replaces it is deliberately scoped down. Accounts live in IndexedDB on
 * the device, passwords are stored as PBKDF2-SHA-256 hashes derived with
 * `crypto.subtle` (the Web Crypto API — not Node's `crypto` module), and the
 * session is a local record. That is enough to personalise the app, keep a
 * patient's own appointments and messages together, and gate the profile UI.
 *
 * It is NOT an authorisation boundary. There is no server to enforce one, so
 * nothing sensitive to another party is stored or granted here. The admin
 * console the old build gated behind this check is not part of the static app
 * for exactly that reason — see `results.md`.
 */

import { get, patch, prefs, put, query, newId } from './store.js'

const SESSION_KEY = 'session'
const PBKDF2_ITERATIONS = 210000

const listeners = new Set()

/** Current session, read synchronously so the first paint is already correct. */
let session = prefs.get(SESSION_KEY)

export function currentUser() {
  return session
}

export function isSignedIn() {
  return Boolean(session)
}

export function onAuthChange(fn) {
  listeners.add(fn)
  return () => listeners.delete(fn)
}

function setSession(next) {
  session = next
  if (next) prefs.set(SESSION_KEY, next)
  else prefs.remove(SESSION_KEY)
  for (const fn of listeners) fn(next)
}

/* ============================ PASSWORD HASHING ============================ */

const encoder = new TextEncoder()

function toHex(buffer) {
  return Array.from(new Uint8Array(buffer), (b) => b.toString(16).padStart(2, '0')).join('')
}

/**
 * PBKDF2-SHA-256 with a per-account random salt.
 *
 * The old server used a hand-rolled 32-bit string hash (`hashPassword` in
 * `auth.server.ts`) which is trivially reversible by brute force. Since these
 * hashes now sit in the user's own IndexedDB where a shared-device attacker
 * can read them, the derivation needs a real work factor, not a weaker one.
 */
async function hashPassword(password, saltHex) {
  if (!globalThis.crypto?.subtle) {
    throw new Error('This browser cannot hash passwords securely (Web Crypto unavailable).')
  }

  const salt = saltHex
    ? Uint8Array.from(saltHex.match(/.{2}/g).map((byte) => parseInt(byte, 16)))
    : globalThis.crypto.getRandomValues(new Uint8Array(16))

  const key = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits'])
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' },
    key,
    256,
  )

  return { hash: toHex(bits), salt: toHex(salt.buffer ? salt : new Uint8Array(salt)) }
}

/** Constant-time-ish comparison so a timing signal doesn't leak the hash. */
function equalHex(a, b) {
  if (a.length !== b.length) return false
  let diff = 0
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i)
  return diff === 0
}

/* ============================ ACCOUNTS ============================ */

function normaliseEmail(email) {
  return String(email || '').trim().toLowerCase()
}

/** Public shape — never carries the hash or salt. */
function publicUser(record) {
  return {
    id: record.id,
    name: record.name,
    email: record.email,
    phone: record.phone || null,
    role: record.role || 'patient',
    profilePicture: record.profilePicture || null,
    createdAt: record.createdAt,
  }
}

export async function register({ name, email, password, phone }) {
  const cleanEmail = normaliseEmail(email)
  if (!name?.trim()) throw new Error('Please enter your full name.')
  if (!cleanEmail.includes('@')) throw new Error('Please enter a valid email address.')
  if (!password || password.length < 8) throw new Error('Password must be at least 8 characters.')

  const existing = await query('patients', (row) => row.email === cleanEmail)
  if (existing.length) throw new Error('An account with that email already exists on this device.')

  const { hash, salt } = await hashPassword(password)
  const record = await put('patients', {
    id: newId(),
    name: name.trim(),
    email: cleanEmail,
    phone: phone?.trim() || null,
    role: 'patient',
    passwordHash: hash,
    passwordSalt: salt,
  })

  setSession(publicUser(record))
  return currentUser()
}

export async function signIn({ email, password }) {
  const cleanEmail = normaliseEmail(email)
  const [record] = await query('patients', (row) => row.email === cleanEmail)

  // Same message either way — telling an attacker which half was wrong turns
  // the form into an account-enumeration oracle.
  const failure = new Error('Email or password is incorrect.')
  if (!record?.passwordSalt) throw failure

  const { hash } = await hashPassword(password, record.passwordSalt)
  if (!equalHex(hash, record.passwordHash)) throw failure

  setSession(publicUser(record))
  return currentUser()
}

export function signOut() {
  setSession(null)
}

/** Update the signed-in account's own profile fields. */
export async function updateProfile(changes) {
  if (!session) throw new Error('Not signed in.')

  const allowed = ['name', 'phone', 'profilePicture']
  const patchBody = {}
  for (const key of allowed) {
    if (changes[key] !== undefined) patchBody[key] = changes[key]
  }

  const updated = await patch('patients', session.id, patchBody)
  if (!updated) throw new Error('Account not found on this device.')

  setSession(publicUser(updated))
  return currentUser()
}

export async function changePassword({ current, next }) {
  if (!session) throw new Error('Not signed in.')
  if (!next || next.length < 8) throw new Error('New password must be at least 8 characters.')

  const record = await get('patients', session.id)
  if (!record) throw new Error('Account not found on this device.')

  const { hash: currentHash } = await hashPassword(current, record.passwordSalt)
  if (!equalHex(currentHash, record.passwordHash)) throw new Error('Current password is incorrect.')

  const { hash, salt } = await hashPassword(next)
  await patch('patients', session.id, { passwordHash: hash, passwordSalt: salt })
}

/**
 * Stable per-device id for visitors who have not signed in, so a guest's
 * booking draft and chat peer id survive a reload.
 */
export function deviceId() {
  let id = prefs.get('device-id')
  if (!id) {
    id = newId()
    prefs.set('device-id', id)
  }
  return id
}

/** Session id if signed in, device id otherwise — used as the peer identity. */
export function actorId() {
  return session?.id || deviceId()
}

export function actorName() {
  return session?.name || 'Guest'
}
