/**
 * Brand and contact constants.
 *
 * The React build read these from the `settings` blob store at runtime
 * (`assets/brand-*.js` merged an admin-edited record over a set of defaults) so
 * an administrator could change the phone number without a deploy. With no
 * backend there is nobody to serve that record, so the defaults it fell back to
 * become the values themselves — copied verbatim from the shipped bundle rather
 * than reinvented, because these are real contact details people rely on.
 *
 * Changing any of them is now a one-line edit and a redeploy, which for a
 * handful of numbers that change once a year is the better trade.
 */

export const BRAND = {
  name: 'Hakimm.com',
  nameGeez: 'ሓኪም',
  nameFull: 'Hakimm.com (ሓኪም)',
  email: 'hakimm.doctor@gmail.com',
  phones: ['+251 914 557 706', '+251 986 935 583'],
  whatsapp: '251914557706',
  telegram: 'hakimmdoctor',
  telegramCommunity: 'hakimmcommunity',
  facebook: 'https://facebook.com/hakimmdotcom',
  youtube: 'https://youtube.com/@hakimmdotcom',
  tiktok: 'https://tiktok.com/@hakimmdotcom',
  address: 'Shire, Tigray, Ethiopia',
}

/** `https://t.me/<handle>`, optionally with a prefilled message. */
export function telegramLink(text = '') {
  const base = `https://t.me/${BRAND.telegram}`
  return text ? `${base}?text=${encodeURIComponent(text)}` : base
}
