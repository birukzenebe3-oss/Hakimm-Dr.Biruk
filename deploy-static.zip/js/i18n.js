/**
 * Bilingual (English / አማርኛ) string helper.
 *
 * The React app used a context provider around `useI18n()`, and every call
 * site passed the pair inline as `t('Book', 'ቀጠሮ ይያዙ')` rather than looking a
 * key up in a catalogue. That call shape is kept, so strings lifted out of the
 * old components need no rewriting — only the provider is gone, replaced by a
 * module-level value plus a subscription the shell uses to re-render.
 *
 * The language is read synchronously from `localStorage` before first paint,
 * so an Amharic visitor never sees a flash of English.
 */

import { prefs } from './store.js'

const STORAGE_KEY = 'lang'
const SUPPORTED = ['en', 'am']

const listeners = new Set()

/** Default to Amharic when the browser asks for it, otherwise English. */
function detect() {
  const saved = prefs.get(STORAGE_KEY)
  if (SUPPORTED.includes(saved)) return saved
  const nav = (navigator.language || 'en').toLowerCase()
  return nav.startsWith('am') || nav.startsWith('ti') ? 'am' : 'en'
}

let lang = detect()

export function getLang() {
  return lang
}

export function setLang(next) {
  if (!SUPPORTED.includes(next) || next === lang) return
  lang = next
  prefs.set(STORAGE_KEY, next)
  document.documentElement.lang = next
  for (const fn of listeners) fn(next)
}

export function toggleLang() {
  setLang(lang === 'en' ? 'am' : 'en')
}

/** Subscribe to language changes. Returns an unsubscribe function. */
export function onLangChange(fn) {
  listeners.add(fn)
  return () => listeners.delete(fn)
}

/** Pick the active language's string. Falls back to English if no Amharic. */
export function t(en, am) {
  return lang === 'am' && am ? am : en
}

/** Locale-aware date formatting; Amharic falls back to the Ethiopian locale. */
export function formatDate(value, options = { dateStyle: 'medium' }) {
  const date = value instanceof Date ? value : new Date(value)
  if (Number.isNaN(date.getTime())) return ''
  try {
    return new Intl.DateTimeFormat(lang === 'am' ? 'am-ET' : 'en-GB', options).format(date)
  } catch {
    return date.toLocaleDateString()
  }
}

export function formatTime(value) {
  return formatDate(value, { hour: '2-digit', minute: '2-digit' })
}

/** "3 hours ago" / relative labels for feed and chat timestamps. */
export function formatRelative(value) {
  const date = value instanceof Date ? value : new Date(value)
  if (Number.isNaN(date.getTime())) return ''

  const seconds = Math.round((date.getTime() - Date.now()) / 1000)
  const units = [
    ['year', 31536000],
    ['month', 2592000],
    ['week', 604800],
    ['day', 86400],
    ['hour', 3600],
    ['minute', 60],
  ]

  try {
    const rtf = new Intl.RelativeTimeFormat(lang === 'am' ? 'am' : 'en', { numeric: 'auto' })
    for (const [unit, size] of units) {
      if (Math.abs(seconds) >= size) return rtf.format(Math.round(seconds / size), unit)
    }
    return rtf.format(seconds, 'second')
  } catch {
    return formatDate(date)
  }
}

/** Birr amounts, the platform's display currency. */
export function formatBirr(amount) {
  const value = Number(amount) || 0
  return `${value.toLocaleString(lang === 'am' ? 'am-ET' : 'en-GB', {
    maximumFractionDigits: 2,
  })} ${t('ETB', 'ብር')}`
}
